
let args = 
  match Sys.argv with
      [| |] | [| _ |] -> [| |]
    | ar -> Array.sub ar 1 (Array.length ar - 1) in
Unix.execvp "micmatch_pcre.top" 
  (Array.append 
    [| "micmatch_pcre.top"; 
       "-I"; "/home/martin/godi/lib/ocaml/pkg-lib/pcre";
       "-I"; "/home/martin/godi/lib/ocaml/site-lib/micmatch_pcre" |] 
    args)
