open Printf
open Scanf

let ( += ) r x = r := !r +. x

type normal = { field : float }

type tag x = [ `X | `Y | `Z ]

module Date = 
struct
  type t = int * int
  let of_string s =
    sscanf s "%i-%i" (fun m y -> (m, y))
  let to_string (m, y) =
    sprintf "%02i-%i" m y
  let compare = compare
end


type col testing = { id : string;
		     name;
		     date1 : Date;
		     date2 : Date;
		     setx : bool = false;
		     test : float option = None;
		     mutable score : float = 0.;
		     mutable remark "bla bla" : string option;
		     kind : [ `Apple | `Orange ] = `Apple;
		     kind2 : [ `Apple | `Banana ] = `Banana }

class mega_obj ~kind =
object
  inherit Testing.OO.t ~id:"mega" ~name:"Sponge" 
    ~date1:(2,2000) ~date2:(3,2000) 
    ~remark:(Some "this is an inherited class") 
    ~kind ()
  method hello = print_endline "Hello!"; flush stdout
end

let _ =
  let item1 = Testing.create 
		~id:"a"
		~name:"Martin"
		~date1:(1, 2006)
		~date2:(6, 2006)
		~score:1.0
		~remark:None () in
  let item2 = Testing.create
		~id:"b" 
		~date1:(10, 1977)
		~date2:(3, 1990)
		~remark:(Some "record 2")
		~name:"Joe" () in
  let l1 = [item1; item2; { item2 with id = "A" } ] in
  Testing.save_csv "test1.csv" l1;
  let l2 = Testing.load_csv "test1.csv" in
  let cmp = Testing.compare_fields [ `Custom (fun a b -> 0);
				     `Down "score";
				     `Up "name";
				     `Up "id" ] in
  Testing.save_csv "test2.csv" (List.sort cmp l2);

  let l2_obj = List.map Testing.OO.of_record l2 in
  let item3 = Testing.OO.of_record item2 in
  item3#set_score 99.;
  item3#set_remark (Some "object derived from record2");
  let item4 = new mega_obj ~kind:`Orange in
  item4#set_score (item3#score +. 1.);
  Testing.OO.save_csv ~sep:' ' ~noheader:true "test3.dat" 
    (l2_obj @ [item3; (item4 :> Testing.OO.t) ])

module Test_predef =
struct
  open Unix
  type tag file_kind = predefined (* note the special order used for sorting *)
    | S_CHR
    | S_BLK
    | S_FIFO
    | S_SOCK
    | S_DIR
    | S_LNK
    | S_REG

  type col stats = predefined {
    st_dev : int;
    st_ino : int;
    st_kind : File_kind (*Unix.file_kind*);
    st_perm : int (*Unix.file_perm*);
    st_nlink : int;
    st_uid : int;
    st_gid : int;
    st_rdev : int;
    st_size : int;
    st_atime : float;
    st_mtime : float;
    st_ctime : float;
  }

  let print_row (file, stats) = 
    print_endline
      (String.concat " " (file :: Array.to_list (Stats.to_array stats)))
  let dir = match Sys.argv with
      [| _; dir |] -> dir
    | _ -> Sys.getcwd ()
  let files = Array.to_list (Sys.readdir dir)
  let stats = 
    List.map (fun file -> (file, stat (Filename.concat dir file))) files
  let cmp = Stats.compare_fields [`Up "st_kind"; `Down "st_size"]
  let sorted =
    List.sort (fun (file1, stat1) (file2, stat2) ->
		 let c = cmp stat1 stat2 in
		 if c <> 0 then c else String.compare file1 file2)
      stats
  let _ = List.iter print_row sorted
end 
