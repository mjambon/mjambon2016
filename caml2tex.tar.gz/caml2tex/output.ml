(**********************************************************************)
(*                                                                    *)
(*         caml2tex : convert ml files to LaTeX2e documents           *)
(*                                                                    *)
(*                           P.E. Meunier                             *)
(*                                                                    *)
(*            Adapted from caml2html by Sebastien Ailleret            *)
(*                                                                    *)
(* This file is distributed under the terms of the GNU Public License *)
(* http://www.gnu.org/licenses/gpl.txt                                *)
(**********************************************************************)

open Types

(* Remplace les caractères spéciaux de TeX *)
let subst_char=function
  | ' ' -> "\\ "
  | '\\' -> "\\bs{}"
  | '$' -> "\\$"
  | '&' -> "\\&"
  | '%' -> "\\%"
  | '#' -> "\\#"
  | '_' -> "\\_"
  | '{' -> "\\{"
  | '}' -> "\\}"
  | '^' -> "\\pow{}"
  | '|' -> "$|$"
  | '>' -> "$>$"
  | '<' -> "$<$"
  | c -> String.make 1 c;;

let subst_char_string s=
  let s_result=ref "" in
  for i=0 to (String.length s)-1 do
    s_result:=(!s_result)^(subst_char (s.[i]));
  done;
    !s_result;;

(* donne du style a un texte *)
let donne_style buf (couleur, classe) s =
  if classe="Ccomment" then
    Printf.bprintf buf "\\%s{\\textit{%s}}" couleur s
  else
    Printf.bprintf buf "\\%s{%s}" couleur s;;

(* transforme une suite d'elements en chaine html coloree *)
let rec add_tab buf nb=
  if nb=0 then () else begin
  Buffer.add_string buf "\\indent ";
  add_tab buf (nb-1)
  end;;
let functions=ref [];;
let rec is_in_list a l=match l with
  |[]->false;
  |h::t when h=a->true
  |h::t->is_in_list a t;;
let rec make_body buf line = function
  | [] -> ()
  | Tstring s :: l ->
      manage_need_cut buf line l s string_color
  | Ttoken " "::Ttoken "=" :: l -> (* deux conversions pour éviter que les keywords de déclaration de fonction soient bluffés *)
      make_body buf line (Ttoken " =":: l)
  | Ttoken a::Ttoken " "::l when a="=" || a=" ="->
      make_body buf line (Ttoken  (a^" ")::l)
  | Ttoken c :: l ->
      if (is_in_list c (!functions)) then begin
	donne_style buf ("Varfunction","Cvarfunction") (subst_char_string c);
	Buffer.add_char buf ' '
      end
      else
	Buffer.add_string buf (subst_char_string c);
      make_body buf line l
  | Tcomment c :: l ->
      manage_need_cut buf line l c comment_color
  | Tconstruct c :: (Ttoken ".")::(Ttoken a)::l -> (* Fonctions des modules de OCaml *)
      donne_style buf construct_color (subst_char_string c);
      Buffer.add_char buf '.';
      donne_style buf ("Varfunction","Cvarfunction") (subst_char_string a);
      make_body buf line l
  | Tconstruct c :: l ->
      donne_style buf construct_color (subst_char_string c);
      make_body buf line l
(* Définition de variables fonctionnelles non récursives *)
  | Tkeyword (k, c)::Ttoken " "::(Ttoken f)::(Ttoken " ")::(Ttoken arg1)::l when arg1.[0]<>' ' && arg1.[0]<>'=' && ((snd c)="Clet" || (snd c)="Cand")->
      donne_style buf c (subst_char_string k);
      Buffer.add_string buf " ";
      donne_style buf ("Varfunction","Cvarfunction") (subst_char_string f);
      Buffer.add_string buf " ";
      functions:=f::(!functions);
      make_body buf line ((Ttoken arg1)::l)
(* Définition de variables fonctionnelles récursives *)
  | (Tkeyword (k, c)) :: (Ttoken " ") :: (Ttoken f) :: l when (snd c)="Crec"->
      donne_style buf c (subst_char_string k);
      Buffer.add_string buf " ";
      donne_style buf ("Varfunction","Cvarfunction") (subst_char_string f);
      functions:=f::(!functions);
      make_body buf line l
(* Pour les fonctions définies avec function, le cas où il y a plus d'un paramètre est déjà traité. Il reste le cas let f=function...*)
  | (Tkeyword (k, c))::(Ttoken " ")::(Ttoken f)::(Ttoken a)::(Tkeyword (k2,c2)):: l when k2="function"->
      donne_style buf c (subst_char_string k);
      Buffer.add_string buf " ";      
      donne_style buf ("Varfunction","Cvarfunction") (subst_char_string f);
      Buffer.add_string buf a;
      functions:=f::(!functions);
      make_body buf line (Tkeyword (k2,c2) :: l)
  | Tkeyword (k, c) :: l ->
      donne_style buf c (subst_char_string k);
      make_body buf line l
  | Tnewline :: l ->
      Buffer.add_string buf "\\ \\newline \n";
      make_body buf (line+1) l
  | Ttab :: l ->
      if !tab_size = -1
      then Buffer.add_string buf "\\indent "
      else add_tab buf !tab_size;
      make_body buf line l
(* decoupe les commentaires pour numeroter les lignes *)
and manage_need_cut buf line list comment color =
  try
    let pos = String.index comment '\n' in
    let c1 = String.sub comment 0 (pos+1) in
    let c2 = String.sub comment (pos+1) ((String.length comment)-pos-1) in
    donne_style buf color c1;
    manage_need_cut buf (line+1) list c2 color
  with _ ->
    donne_style buf color (subst_char_string comment);
    make_body buf line list

(* transforme une suite d'elements en page html *)
let html_of_element_list buf file lst =
  (* calcule le contenu du body *)
  let body = make_body buf 2 lst in
    Buffer.add_string buf "\n";;
