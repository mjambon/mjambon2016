(**********************************************************************)
(*                                                                    *)
(*         caml2tex : convert ml files to LaTeX2e documents           *)
(*                                                                    *)
(*                           P.E. Meunier                             *)
(*                                                                    *)
(*            Adapted from caml2html by Sebastien Ailleret            *)
(*                                                                    *)
(* This file is distributed under the terms of the GNU Public License *)
(* http://www.gnu.org/licenses/gpl.txt                                *)
(**********************************************************************)

let version = "caml2html 1.1"

(*** infos de parametrages ***)
(* faut-il numeroter les lignes *)
let line_number = ref false
(* faut-il ajouter un titre *)
let add_title = ref false
(* faut-il remplacer les tabulations par des espaces *)
let tab_size = ref (-1)
(* faut-il ajouter un pied de page *)
let footnotes = ref true

(*** type utilise pour decrire une page ***)
(* elements de base lors de la lecture d'un fichier *)
type element =
  | Tcomment of string            (* commentaire *)
  | Tstring of string             (* chaine de caractere ou caractere seul *)
  | Tconstruct of string          (* Constructeur *)
  | Tkeyword of string * (string * string)
                    (* mot cle avec sa couleur d'affichage et classe css *)
  | Ttoken of string              (* element non identifie *)
  | Tnewline                      (* nouvelle ligne *)
  | Ttab                          (* tabulation *)


(* definition des differentes couleurs *)
let maxkw=8;;
let kw=Array.create (maxkw+1) "";;
let kw_colors=Array.create (maxkw+1) "";;
kw.(0)<-"KWLanguage";;kw_colors.(0)<-"{0,0.5,0}";;
kw.(1)<-"KWStructure";;kw_colors.(1)<-"{0.5,0.6,0.6}";;
kw.(2)<-"KWModule";;kw_colors.(2)<-"{0.8,0.6,0}";;
kw.(3)<-"KWSubprog";;kw_colors.(3)<-"{0.6,0,0.6}";;
kw.(4)<-"KWException";;kw_colors.(4)<-"{0.8,0,0}";;

kw.(5)<-"Constructor";;kw_colors.(5)<-"{0,0,0.7}";;
kw.(6)<-"Comment";;kw_colors.(6)<-"{0.6,0,0}";;
kw.(7)<-"String";;kw_colors.(7)<-"{0.6,0.5,0.5}";;
kw.(8)<-"Varfunction";;kw_colors.(8)<-"{0.2,0.2,0.8}";;

let construct_color = (kw.(5), "Cconstructor")
let comment_color = (kw.(6), "Ccomment")
let string_color = (kw.(7), "Cstring")
let bar_color = (kw.(1), "Cbar")

(* association entre les mot cles et les couleurs *)
let key_color =
  [
   "and", (kw.(0), "Cand");
   "as", (kw.(0), "Cas");
   "class", (kw.(0), "Cclass");
   "constraint", (kw.(0), "Cconstraint");
   "exception", (kw.(0), "Cexception");
   "external", (kw.(0), "Cexternal");
   "fun", (kw.(0), "Cfun");
   "function", (kw.(0), "Cfunction");
   "functor", (kw.(0), "Cfunctor");
   "in", (kw.(0), "Cin");
   "inherit", (kw.(0), "Cinherit");
   "initializer", (kw.(0), "Cinitializer");
   "let", (kw.(0), "Clet");
   "method", (kw.(0), "Cmethod");
   "module", (kw.(0), "Cmodule");
   "mutable", (kw.(0), "Cmutable");
   "of", (kw.(0), "Cof");
   "private", (kw.(0), "Cprivate");
   "rec", (kw.(0), "Crec");
   "type", (kw.(0), "Ctype");
   "val", (kw.(0), "Cval");
   "virtual", (kw.(0), "Cvirtual");

   "do", (kw.(1), "Cdo");
   "done", (kw.(1), "Cdone");
   "downto", (kw.(1), "Cdownto");
   "else", (kw.(1), "Celse");
   "for", (kw.(1), "Cfor");
   "if", (kw.(1), "Cif");
   "lazy", (kw.(1), "Clazy");
   "match", (kw.(1), "Cmatch");
   "new", (kw.(1), "Cnew");
   "or", (kw.(1), "Cor");
   "then", (kw.(1), "Cthen");
   "to", (kw.(1), "Cto");
   "try", (kw.(1), "Ctry");
   "when", (kw.(1), "Cwhen");
   "while", (kw.(1), "Cwhile");
   "with", (kw.(1), "Cwith");

   "assert", (kw.(2), "Cassert");
   "include", (kw.(2), "Cinclude");
   "open", (kw.(2), "Copen");

   "begin", (kw.(3), "Cbegin");
   "end", (kw.(3), "Cend");
   "object", (kw.(3), "Cobject");
   "sig", (kw.(3), "Csig");
   "struct", (kw.(3), "Cstruct");

   "raise", (kw.(4), "Craise")
 ]
