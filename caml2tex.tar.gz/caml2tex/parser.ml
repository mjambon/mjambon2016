type token =
  | COMMENT of (string)
  | STRING of (string)
  | TOKEN of (string)
  | CONSTRUCTOR of (string)
  | KEYWORD of (string * (string * string))
  | NEWLINE
  | TAB
  | EOF

open Parsing;;
# 1 "parser.mly"

(**********************************************************************)
(*                                                                    *)
(*         caml2tex : convert ml files to LaTeX2e documents           *)
(*                                                                    *)
(*                           P.E. Meunier                             *)
(*                                                                    *)
(*            Adapted from caml2html by Sebastien Ailleret            *)
(*                                                                    *)
(* This file is distributed under the terms of the GNU Public License *)
(* http://www.gnu.org/licenses/gpl.txt                                *)
(**********************************************************************)

open Types

# 29 "parser.ml"
let yytransl_const = [|
  262 (* NEWLINE *);
  263 (* TAB *);
    0 (* EOF *);
    0|]

let yytransl_block = [|
  257 (* COMMENT *);
  258 (* STRING *);
  259 (* TOKEN *);
  260 (* CONSTRUCTOR *);
  261 (* KEYWORD *);
    0|]

let yylhs = "\255\255\
\001\000\002\000\002\000\003\000\003\000\003\000\003\000\003\000\
\003\000\003\000\000\000"

let yylen = "\002\000\
\002\000\000\000\002\000\001\000\001\000\001\000\001\000\001\000\
\001\000\001\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\004\000\005\000\006\000\007\000\008\000\009\000\
\010\000\011\000\000\000\000\000\001\000\003\000"

let yydgoto = "\002\000\
\010\000\011\000\012\000"

let yysindex = "\006\000\
\255\254\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\008\000\255\254\000\000\000\000"

let yyrindex = "\000\000\
\009\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\009\000\000\000\000\000"

let yygindex = "\000\000\
\000\000\254\255\000\000"

let yytablesize = 10
let yytable = "\003\000\
\004\000\005\000\006\000\007\000\008\000\009\000\001\000\013\000\
\002\000\014\000"

let yycheck = "\001\001\
\002\001\003\001\004\001\005\001\006\001\007\001\001\000\000\000\
\000\000\012\000"

let yynames_const = "\
  NEWLINE\000\
  TAB\000\
  EOF\000\
  "

let yynames_block = "\
  COMMENT\000\
  STRING\000\
  TOKEN\000\
  CONSTRUCTOR\000\
  KEYWORD\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun parser_env ->
    let _1 = (peek_val parser_env 1 : 'tok_list) in
    Obj.repr(
# 40 "parser.mly"
    ( _1 )
# 100 "parser.ml"
               : Types.element list))
; (fun parser_env ->
    Obj.repr(
# 44 "parser.mly"
    ( [] )
# 106 "parser.ml"
               : 'tok_list))
; (fun parser_env ->
    let _1 = (peek_val parser_env 1 : 'tok) in
    let _2 = (peek_val parser_env 0 : 'tok_list) in
    Obj.repr(
# 46 "parser.mly"
    ( _1 :: _2 )
# 114 "parser.ml"
               : 'tok_list))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : string) in
    Obj.repr(
# 50 "parser.mly"
    ( Tcomment _1 )
# 121 "parser.ml"
               : 'tok))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : string) in
    Obj.repr(
# 52 "parser.mly"
    ( Tstring _1 )
# 128 "parser.ml"
               : 'tok))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : string) in
    Obj.repr(
# 54 "parser.mly"
    ( Ttoken _1 )
# 135 "parser.ml"
               : 'tok))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : string) in
    Obj.repr(
# 56 "parser.mly"
    ( Tconstruct _1 )
# 142 "parser.ml"
               : 'tok))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : string * (string * string)) in
    Obj.repr(
# 58 "parser.mly"
    ( let k, c = _1 in Tkeyword (k, c) )
# 149 "parser.ml"
               : 'tok))
; (fun parser_env ->
    Obj.repr(
# 60 "parser.mly"
    ( Tnewline )
# 155 "parser.ml"
               : 'tok))
; (fun parser_env ->
    Obj.repr(
# 62 "parser.mly"
    ( Ttab )
# 161 "parser.ml"
               : 'tok))
(* Entry file *)
; (fun parser_env -> raise (YYexit (peek_val parser_env 0)))
|]
let yytables =
  { actions=yyact;
    transl_const=yytransl_const;
    transl_block=yytransl_block;
    lhs=yylhs;
    len=yylen;
    defred=yydefred;
    dgoto=yydgoto;
    sindex=yysindex;
    rindex=yyrindex;
    gindex=yygindex;
    tablesize=yytablesize;
    table=yytable;
    check=yycheck;
    error_function=parse_error;
    names_const=yynames_const;
    names_block=yynames_block }
let file (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (yyparse yytables 1 lexfun lexbuf : Types.element list)
