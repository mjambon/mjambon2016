(* Documentation for the col package: a syntax extension of OCaml
   for the safe manipulation of flat records and their conversion
   from and to text files (CSV), tuples, objects and raw string arrays.

   The advantages over using a syntax extension are the following:
   - records can be defined with default values
   - a "create" function is automatically defined; its arguments are labeled,
     and the ones with default values are optional.
   - the equivalent functions are provided for objects and tuples and one can 
     convert one type into another.
   - record fields of the same type can be selected at runtime.
     For instance, the following "get" function takes a record and 
     returns a float although the record contains fields of types 
     other than float:
        let get = type_float_field (if cond then "x" else "y")
   - a list of records/objects/tuples can be read safely from CSV files with
     a header, even if the columns are in any order and if unknown columns
     are present.
   - if the CSV file has no header, the columns are assumed to be in the order
     of the type definition. Additional columns are ignored.
   - plain English names can be given to columns labels, so that the CSV
     files are ready for being manipulated in your favorite spreadsheet 
     or plotting program.
   - conversion of polymorphic variants without argument to and from strings
     is fully automatic

   Below (file <a href="#doc.ml">doc.ml</a>) is a sample of code using the syntax extension.
   <a href="#doc.mli">doc.mli</a> shows all the type definitions, submodules
   and functions that are created. 
   <a href="#doc.ppo">doc.ppo</a> is the same code, after expansion by camlp4
   into regular OCaml.


   Compile with:
   ocamlfind ocamlopt -c yourprogram.ml -syntax camlp4o -package col
*)


(* We define a custom type that we will use in record fields
   (no syntax novelty here) *)
module Date = 
struct
  type t = int * int
  let of_string s = Scanf.sscanf s "%i-%i" (fun m y -> (m, y))
  let to_string (m, y) = Printf.sprintf "%02i-%i" m y
end

(* A special syntax for defining a module which has the same structure
   as the Date module above. See <a href="#doc.mli">doc.mli</a>. *)
type tag fruit = [ `Apple | `Orange | `Banana | `Passion "Passion fruit" ]

(* The main syntax extension: it defines a record type of the same name,
   plus the equivalent tuple and object types, and functions to manipulate
   them. See <a href="#doc.mli">doc.mli</a> for the interface
   and <a href="#doc.ppo">doc.ppo</a> for the expanded OCaml code. *)
type col example = {
  alpha; (* field type defaults to string (builtin type) *)
  bravo "Bravo!"; (* use another label in data files *)
  charlie = "empty"; (* default value *)
  delta : string; (* field type specification *)
  echo "echo echo" : string = "nothing"; (* combining the previous features *)
  foxtrot : int; (* another builtin type *)
  golf : int option;
  hotel : int option = Some 123;
  india : float; (* another builtin type *)
  juliet : float option;
  kilo : bool; (* another builtin type *)
  lima : bool option;
  mike "date (mm-yyyy)" : Date; (* a custom type given as a module *)
  november : Date option = None;
  oscar : [ `Apple | `Orange ]; (* inline tag definition *)
  papa : [ `Apple | `Banana ] = `Banana;
  quebec : Fruit = `Passion; (* external tag definition *)
  mutable romeo : int; (* mutable for records and objects, not tuples *)
  (* sierra
     tango
     uniform
     victor
     whisky
     x-ray
     yankee
     zulu *)
}
