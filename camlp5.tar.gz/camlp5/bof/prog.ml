let _ =
  Printf.printf "Version: %s\n" version
