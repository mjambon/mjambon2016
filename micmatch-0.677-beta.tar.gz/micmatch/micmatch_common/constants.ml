(*pp camlp4o q_MLast.cmo *)

let dummy_loc = Declare_once.dummy_loc

let debug = false
let reserved_prefix = if debug then "_" else "__micmatch_"
let uppercase_prefix = "C" ^ reserved_prefix

let mod_runtime = ref ""
let mod_runtime_mt = ref ""

let exn_exit = "Micmatch_exit"

let any_exn = reserved_prefix ^ "any_exn"
let any_target = reserved_prefix ^ "any_target"
let any_result = reserved_prefix ^ "any_result"

let expr_exit loc =
  <:expr< $uid: !mod_runtime$.$uid:exn_exit$ >>

let raise_exit loc =
  <:expr< raise $expr_exit loc$ >>

let patt_exit loc =
  <:patt< $uid: !mod_runtime$.$uid:exn_exit$ >>
