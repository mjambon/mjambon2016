(*pp camlp4o q_MLast.cmo *)


let _ =
  Constants.mod_runtime := "Run_micmatch_str";
  Constants.mod_runtime_mt := "Run_micmatch_str_mt"

let str_mutex = "str_mutex"


(* Emacs/Str syntax for regular expressions *)

open Printf

open Regexp_ast

let special_regexps = 
  let loc = Constants.dummy_loc in
  [ "bol", Special (loc, "^"); (* beginning of line *)
    "eol", Special (loc, "$"); (* end of line *)
    "bnd", Special (loc, "\\b"); (* word boundary *)
    "any", Special (loc, "."); (* any character except newline *) ]

(*
  Note that the usual regexp special characters are not special inside
  a character set. A completely different set of special characters exists
  inside character sets: `]', `-' and `^'.

  To include a `]' in a character set, you must make it the first
  character. For example, `[]a]' matches `]' or `a'. To include a `-',
  write `-' as the first or last character of the set, or put it after
  a range. Thus, `[]-]' matches both `]' and `-'. 

  To include `^', make it other than the first character in the set.
*)

let string c = String.make 1 c

let quote_char = function
    '[' | ']' | '*' | '.' | '\\' | '?' | '+' | '^' | '$' as c ->
      let s = String.create 2 in
      s.[0] <- '\\'; s.[1] <- c; s
  | c -> string c


let reorder_charset l =
  if l = [] then
    invalid_arg "reorder_charset";
  List.sort 
    (fun c1 c2 ->
       if c1 = c2 then invalid_arg "reorder_charset: repeated char"
       else if c1 = ']' then -1
       else if c2 = ']' then 1
       else if c1 = '-' then 1
       else if c2 = '-' then -1
       else if c1 = '^' then 1
       else if c2 = '^' then -1
       else Char.compare c1 c2)
    l

let compact l =
  let finish first last =
    match Char.code last - Char.code first with
	0 -> string first
      | 1 -> string first ^ string last
      | _ -> string first ^ "-" ^ string last in

  let rec extend first last = 
    function 
	[] -> [finish first last]
      | c :: rest -> 
	  if Char.code c = Char.code last + 1 then 
	    extend first c rest
	  else
	    finish first last :: extend c c rest in

  match l with
      [] -> []
    | hd :: tl -> extend hd hd tl


let compact_charset l =
  let rbracket = ref false
  and dash = ref false
  and caret = ref false in
  let normal = 
    List.filter (function
		     ']' -> rbracket := true; false
		   | '-' -> dash := true; false
		   | '^' -> caret := true; false
		   | _ -> true) l in
  let sorted = List.sort Char.compare normal in
  let special_tail = 
    let tail = if !dash then ["-"] else [] in
    if !caret then "^" :: tail else tail in
  let tail = compact sorted @ special_tail in
  if !rbracket then "]" :: tail else tail


let rec rm_closed = function Closed ast -> rm_closed ast | ast -> ast

let rec to_string ?(top = false) ((last_group, named_groups) as groups) buf = 
  function
      Epsilon loc -> groups
    | Special (loc, s) -> Buffer.add_string buf s; groups
    | Characters (loc, set) -> 
	let l = Charset.list set in
	(match l with
	     [] -> groups
	   | [c] ->
	       Buffer.add_string buf (quote_char c); 
	       groups
	   | _ ->
	       Buffer.add_string buf "[";
	       List.iter (Buffer.add_string buf) (compact_charset l);
	       Buffer.add_string buf "]";
	       groups)
	  
    | Sequence (loc, re1, re2) ->
	let groups = to_string groups buf re1 in
	to_string groups buf re2
	  
    | Alternative (loc, re, Epsilon _, _) ->

	let must_group = 
	  not top && 
	  match rm_closed re with
	      Characters _ | Special _ | Bind _ | Alternative _ -> false
	    | _ -> true in
	let last_group = if must_group then succ last_group else last_group in
	if must_group then Buffer.add_string buf "\\(";
	let (last_group, named_groups) as groups = 
	  to_string (last_group, named_groups) buf re in
	if must_group then Buffer.add_string buf "\\)";
	Buffer.add_string buf "?";
	groups

    | Alternative (loc, re1, re2, _) ->

	let must_group = not top in
	let last_group = if must_group then succ last_group else last_group in
	if must_group then Buffer.add_string buf "\\(";
	let (last_group, named_groups1) = 
	  to_string (last_group, named_groups) buf re1 in
	Buffer.add_string buf "\\|";

	let (last_group, named_groups2) = 
	  to_string (last_group, named_groups) buf re2 in
	if must_group then Buffer.add_string buf "\\)";

	if not (Named_groups.equal named_groups1 named_groups2) then
	  (let missing = 
	     S.diff 
	       (Named_groups.union named_groups1 named_groups2) 
	       (Named_groups.inter named_groups1 named_groups2) in
	   Messages.unbalanced_bindings loc (list_named_groups missing));

	(last_group, merge named_groups1 named_groups2)
	  
    | Repetition (loc, (Star, true), 
		  (Repetition (_, (Star, true), _) as re)) -> 
	to_string ~top groups buf re

    | Repetition (loc, kind, re) ->
	let must_group =
	  not top && 
	  match rm_closed re with
	      Characters _ | Special _ | Bind _ | Alternative _ -> false
	    | _ -> true in
	let last_group =
	  if must_group then
	    (Buffer.add_string buf "\\(";
	     succ last_group)
	  else last_group in
	let groups = to_string (last_group, named_groups) buf re in
	if must_group then
	  Buffer.add_string buf "\\)";
	let op = 
	  match kind with
	      (Star, true) -> "*"
	    | (Plus, true) -> "+"
	    | (Option, true) -> "?"
	    | _ -> assert false in
	Buffer.add_string buf op;
	groups

    | Bind (loc, re, name) -> 
	let last_group = succ last_group in
	let named_groups = add_new loc name last_group named_groups in
	Buffer.add_string buf "\\(";
	let groups = to_string (last_group, named_groups) buf re in
	Buffer.add_string buf "\\)";
	groups

    | Backref (loc, name) ->
	(try
	   match Named_groups.find name named_groups with
	       [] -> Messages.invalid_backref loc name
	     | [(_, n)] -> bprintf buf "\\%i" n; groups
	     | l -> 
		 bprintf buf "\\(%s\\)" 
		   (String.concat "\\|"
		      (List.map (fun (_, n) -> sprintf "\\%i" n) l));
		 (succ last_group, named_groups)
	 with Not_found -> Messages.invalid_backref loc name)
	    
    | Closed ast -> 
	let saved_named_groups = named_groups in
	let (last_group, named_groups) = to_string groups buf ast in
	(last_group, saved_named_groups)

    | Possessive _ -> assert false


let process_regexp loc re =
  let buf = Buffer.create 1000 in
  let (last_group, named_groups) = 
    to_string ~top:true (0, Named_groups.empty) buf re in
  let re_string = Buffer.contents buf in
  (re_string, named_groups)


(* Syntax expanders *)

open Constants

let expr_mutex loc = <:expr< $uid: !mod_runtime_mt$.$lid:str_mutex$ >>

let unlock loc =
  <:expr< Mutex.unlock $expr_mutex loc$ >>

let lock loc =
  <:expr< Mutex.lock $expr_mutex loc$ >>

let lock_unlock e =
  let loc = MLast.loc_of_expr e in
  <:expr< do { $lock loc$; 
	       try let x = $e$ in do { $unlock loc$; x }
               with [ exn -> do { $unlock loc$; raise exn } ] } >>

let unlock_lock e =
  let loc = MLast.loc_of_expr e in
  <:expr< do { $unlock loc$; 
	       try let x = $e$ in do { $lock loc$; x }
               with [ exn -> do { $lock loc$; raise exn } ] } >>

let string_match loc re target pos =
  <:expr< Str.string_match $lid:re$ $target$ $int:string_of_int pos$ >>

let matched_group loc n target =
    <:expr< Str.matched_group $int:string_of_int n$ $target$ >>


let compile_regexp loc re_string =
  <:expr< Str.regexp $str:String.escaped re_string$ >>


let insert_bindings loc target set e =
  Named_groups.fold
    (fun name l e -> 
       match l with
	   [] -> assert false
	 | (loc, _) :: _ ->
	     let find_it =
	       List.fold_right 
		 (fun (loc, n) accu ->
		    let expr = matched_group loc n target in
		    match accu with
			None -> Some expr
		      | Some e ->
			  Some <:expr< 
			  try $expr$ with [ Not_found -> $e$ ] >>)
		 l
		 None in
	     let result =
	       match find_it with
		   None -> assert false 
		 | Some e -> e in
	     <:expr< let $lid:name$ = $result$ in $e$ >>)
    set
    e
    

let match_and_bind loc re_name target named_groups success failure =
  <:expr< 
  if $string_match loc re_name target 0$
  then $insert_bindings loc target named_groups success$
  else $failure$ >>


let macro_replace loc re_name target_name named_groups expr =
  let target = <:expr< $lid:target_name$ >> in
  <:expr<
  fun $lid:target_name$ ->
    Str.global_substitute $lid:re_name$ 
    (fun _ -> $insert_bindings loc target named_groups expr$)
    $target$ >>


open Select_lib

let lib = { predefined_regexps = special_regexps;
	    unfold_range = true;
	    process_regexp = process_regexp;
	    compile_regexp_match = compile_regexp;
	    compile_regexp_search = compile_regexp;
	    match_and_bind = match_and_bind;
	    wrap_match = (fun e -> e);
	    wrap_user_case = (fun e -> e);
	    really_wrap_match = false;
	    really_wrap_user_case = false }

let lib_mt = { predefined_regexps = special_regexps;
	       unfold_range = true;
	       process_regexp = process_regexp;
	       compile_regexp_match = compile_regexp;
	       compile_regexp_search = compile_regexp;
	       match_and_bind = match_and_bind;
	       wrap_match = lock_unlock;
	       wrap_user_case = unlock_lock;
	       really_wrap_match = true;
	       really_wrap_user_case = true }
