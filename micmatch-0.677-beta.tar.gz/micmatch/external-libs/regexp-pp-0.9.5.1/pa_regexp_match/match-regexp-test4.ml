#load "./pa_regexp_match.cma";;

let _ =
  begin
    match with_regexp "" with
      "AB" -> ()
    | _ -> ()
  end;
  begin
    let module M = struct
      let v () = 
	begin
	  match with_regexp "" with
	    "AB" -> ()
	  | _ -> ()
	end;
    end
    in M.v ()
  end

let _ =
  begin
    match with_regexp "" with
      "AB" -> ()
    | _ -> ()
  end
