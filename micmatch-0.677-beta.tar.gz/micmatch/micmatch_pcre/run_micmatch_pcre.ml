exception Micmatch_exit

open Pcre

let irflags = rflags []

external make_substrings : string * int array -> substrings = "%identity"

let search rex f ?(pos = 0) subj =
  let subgroup_offsets, offset_vector = make_ovector rex in
  let substrings = make_substrings (subj, offset_vector) in
  let rec loop cur_pos =
    if 
      try
	unsafe_pcre_exec 
	  irflags rex cur_pos subj subgroup_offsets offset_vector None; true
      with Not_found -> false
    then
      (f substrings;
       let last = offset_vector.(1) in
       loop last) in
  loop pos

let scan ~full rex pos ~ftext ~fmatch subj =
  let subgroup_offsets, offset_vector = make_ovector rex in
  let substrings = make_substrings (subj, offset_vector) in
  let rec loop cur_pos =
    if 
      try
	unsafe_pcre_exec 
	  irflags rex cur_pos subj subgroup_offsets offset_vector None; true
      with Not_found -> 
	let last = String.length subj in
	if full || last > cur_pos then
	  ftext (String.sub subj cur_pos (last - cur_pos));
	false
    then
      (let first = offset_vector.(0) in
       let last = offset_vector.(1) in
       if full || first > pos then
	 ftext (String.sub subj cur_pos (first - cur_pos));
       fmatch substrings;
       loop last) in
  loop pos

let map rex f ?(pos = 0) ?(full = true) subj =
  let l = ref [] in
  let ftext s = l := `Text s :: !l
  and fmatch substrings = l := f substrings :: !l in
  scan ~full rex pos ~ftext ~fmatch subj;
  List.rev !l

let collect rex f ?(pos = 0) subj =
  let l = ref [] in
  let f substrings = l := f substrings :: !l in
  search rex f ~pos subj;
  List.rev !l

let split rex ?(full = false) ?(pos = 0) subj =
  let l = ref [] in
  let ftext s = l := s :: !l
  and fmatch substrings = () in
  scan ~full rex pos ~ftext ~fmatch subj;
  List.rev !l

