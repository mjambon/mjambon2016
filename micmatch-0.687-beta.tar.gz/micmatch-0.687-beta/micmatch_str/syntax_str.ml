(*pp ocamlrun ./version_filter -pp "camlp4o pa_extend.cmo q_MLast.cmo -loc loc -impl" *)

open Syntax_common
open Select_lib

let extend_common () =
EXTEND
  Pcaml.expr: [
    [ "RE_STR"; re = regexp -> 
	Regexp_ast.warnings re;
	let (s, named_groups, postbindings) =
	  Str_lib.lib.process_regexp loc re "" in
	
	<:expr< ( $str:String.escaped s$, 
		  $pp_named_groups loc named_groups$ ) >> ]
  ];

  Syntax_common.regexp: LEVEL "simple" [
    [ "_" -> Regexp_ast.Characters (loc, Charset.full) ]
  ];

END;;

let extend_regular () = extend_common ()
let extend_revised () = extend_common ()

let _ =
  select_lib Str_lib.lib;

  Pcaml.add_option "-thread" 
    (Arg.Unit (fun () -> select_lib Str_lib.lib_mt))
    " use the Str library in a multithreaded program";

  (match !Pcaml.syntax_name with
       "OCaml" -> extend_regular ()
     | _ -> extend_revised ())
