open Printf
open Arg

let sources = ref []
let parse_only = ref false
let ocaml = ref "ocaml unix.cma"
let tmpfile = "/tmp/camlremix_tmp.ml"
let outfile = ref None

let options = [
  "-c",
  Set parse_only,
  " only generate .ml file";
  
  "-e",
  Set_string ocaml,
  "<ocaml>  specify ocaml executable";

  "-o",
  String (fun s -> outfile := Some s),
  "<file>  specify an output file"
]

let add_source s = sources := s :: !sources

let usage_msg = "Usage: camlremix [options] file1 file2 ..."

let process_file in_file =
  let ic = open_in_bin in_file in
  let oc = open_out_gen [Open_wronly ; Open_append ;Open_creat ;Open_binary ] 0o666 tmpfile in
  Lexer.newfile ();
  let lexbuf = Lexing.from_channel ic in
  let top = 
    try Parser.top Lexer.token lexbuf 
    with Parsing.Parse_error -> 
      failwith (sprintf "File %S, line %d, characters 1-%d : meta-syntax error\n" 
		  in_file !Lexer.line !Lexer.char)
  in

  let rec gen_code code =
    if code = [] then fprintf oc "\"\""
    else (
      List.iter 
	(function
	     `str (line, char, s) -> 
	       fprintf oc "\n# %i %S\n%s%s" line in_file (String.make (char - 1) ' ') s;
	   | `escstr e -> 
	       gen_str e;
	) code;
    )
  and gen_str embstr =
    if embstr = [] then fprintf oc "\"\""
    else (
      fprintf oc "(let __camlremix_buf = Buffer.create 0 in\n";
      List.iter 
	(function
	     `str (line, char, s) ->
	       fprintf oc "(*gs1*)Buffer.add_string __camlremix_buf %S;\n" s;
	   | `esccode c ->
	       fprintf oc "(*gs2*)Buffer.add_string __camlremix_buf (\n";
	       gen_code c;
	       fprintf oc ");\n";
	) embstr;
      fprintf oc "Buffer.contents __camlremix_buf)"
    )
  in	     
  List.iter 
    (function
	 `str (line, char, s) ->
	   fprintf oc "let () = print_string %S\n" s;
       | `codetop code ->
	   if code <> [] then (
	     fprintf oc "let () = ();;\n";
	     gen_code code
	   )
       | `codestr code ->
	   fprintf oc "let () = print_string (";
	   gen_code code;
	   fprintf oc ")\n"
    ) top;
  close_out oc 

let mypath =
  let prg = Sys.argv.(0) in
  let pathprg = Filename.dirname prg in
  if Filename.is_relative pathprg then
    Filename.concat (Sys.getcwd ()) pathprg
  else pathprg

let () =
  parse options add_source usage_msg;
  ocaml := !ocaml ^ " -I " ^ mypath;
  (try Unix.unlink tmpfile with _ -> ());
  List.iter process_file (List.rev !sources);
  if !parse_only then 
    printf "Successfully produced %s .\n" tmpfile
  else (
    let rescompil = Sys.command (!ocaml ^ " " ^ tmpfile ^ 
				 (match !outfile with 
				    None -> ""
				  | Some s -> "> " ^ s)) in
    if rescompil <> 0 then (
      (match !outfile with 
	 None -> ()
       | Some s -> (try Unix.unlink s with _ -> ()));
      exit rescompil
    )
  )
    
