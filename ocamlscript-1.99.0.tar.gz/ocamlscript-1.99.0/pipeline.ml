(*pp $PP *)

open Printf
open Unix

(* 
   - input: list of files which are copied from the base directory 
   to a temporary directory
   - output: list of files which are copied from the temporary directory
   to the base directory
   - the current directory is set to the temporary directory during
   the execution of the pipeline
*)

type pipeline = { input : string list;
		  output : string list;
		  commands : string list }

let ( // ) = Filename.concat
let ( @@ ) a b = if Filename.is_relative b then a // b else b

let prng = Random.State.make_self_init ();;

let temporary_directory =
  match Sys.os_type with
    "Unix" | "Cygwin" -> (try Sys.getenv "TMPDIR" with Not_found -> "/tmp")
  | "Win32" -> (try Sys.getenv "TEMP" with Not_found -> ".")
  | _ -> assert false

let temp_file_name prefix suffix =
  let rnd = (Random.State.bits prng) land 0xFFFFFF in
  temporary_directory // (sprintf "%s%06x%s" prefix rnd suffix)

let temp_dir prefix suffix =
  let rec try_name counter =
    let name = temp_file_name prefix suffix in
    try
      mkdir name 0o700;
      name
    with Unix_error _ as e ->
      if counter >= 1000 then raise e else try_name (counter + 1)
  in try_name 0

(* rm -rf *)
let rec remove ?log file = 
  try
    let st = stat file in
    match st.st_kind with
	S_DIR -> 
	  Array.iter (fun name -> remove (file // name)) (Sys.readdir file);
	  log ?? fprintf log "remove directory %S\n%!" file;
	  rmdir file
      | S_REG 
      | S_CHR
      | S_BLK
      | S_LNK 
      | S_FIFO
      | S_SOCK -> 
	  log ?? fprintf log "remove file %S\n%!" file;
	  Sys.remove file
  with e -> ()


let exec ?log s = 
  log ?? fprintf log "%s\n%!" s;
  let status = Sys.command s in 
  log ?? fprintf log "exit status %i\n%!" status;
  status

let copy_file ?log src dst =
  log ?? fprintf log "copy %S to %S\n%!" src dst;
  let ic = open_in_bin src in
  try
    let oc = open_out_bin dst in
    try 
      try
	while true do
	  output_char oc (input_char ic)
	done
      with End_of_file -> ()
    finally
      close_out_noerr oc;
      let perm = (stat src).st_perm in
      chmod dst perm
  finally
    close_in_noerr ic

let copy_files ?log src dst l =
  List.iter 
    (fun (src_name, dst_name) -> 
	    copy_file ?log (src @@ src_name) (dst @@ dst_name))
    l

let match_files names settings =
  let tbl = Hashtbl.create 10 in
  List.iter (fun id -> Hashtbl.replace tbl id None) names;
  List.iter (fun (id, s) -> Hashtbl.replace tbl id (Some s)) settings;
  let pairs =
    Hashtbl.fold (fun id opt l -> 
		    let x = 
		      match opt with
			  None -> (id, id)
			| Some s -> (id, s) in
		    x :: l) tbl [] in
  pairs

let flip (a, b) = (b, a)

let run ?log ?(input = []) ?(output = []) p =
  let rec loop l =
    match l with
	[] -> 0
      | cmd :: rest ->
	  try 
	    let status = exec ?log cmd in
	    if status = 0 then loop rest
	    else status
	  with _ -> 127 in
  let dir = temp_dir "ocamlpipeline" "" in
  try
    let base = Sys.getcwd () in
    log ?? fprintf log "change directory %S\n%!" dir;
    Sys.chdir dir;
    copy_files ?log base dir (List.map flip (match_files p.input input));
    let status = loop p.commands in
    log ?? fprintf log "change directory %S\n%!" base;
    Sys.chdir base;
    log ?? fprintf log "command pipeline exits with status %i\n%!" status;
    if status = 0 then
      copy_files ?log dir base (match_files p.output output);
    status
  finally remove ?log dir
