(* We create an iter operator which will be used instead of List.iter *)
OPERATOR "iter"
  LEVEL ":="
  VALUE fun l f -> List.iter f l (* iter is not a keyword yet *)
END
;;

(* Now iter is a reserved keyword, so we can't use List.iter anymore! *)
let _ =
  [1;2;3] iter print_int;
  print_newline ()
