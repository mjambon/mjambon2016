let mem = String.make 30000 (Char.chr 0)
let p = ref 0
let print () = print_char mem.[!p]; flush stdout
let () =
  mem.[!p] <- Char.chr (Char.code mem.[!p] + 10);
  while Char.code mem.[!p] > 0 do
    p := !p + 1;
    mem.[!p] <- Char.chr (Char.code mem.[!p] + 7);
    p := !p + 1;
    mem.[!p] <- Char.chr (Char.code mem.[!p] + 10);
    p := !p + 1;
    mem.[!p] <- Char.chr (Char.code mem.[!p] + 3);
    p := !p + 1;
    mem.[!p] <- Char.chr (Char.code mem.[!p] + 1);
    p := !p - 4;
    mem.[!p] <- Char.chr (Char.code mem.[!p] - 1)
  done;
  p := !p + 1;
  mem.[!p] <- Char.chr (Char.code mem.[!p] + 2);
  print ();
  p := !p + 1;
  mem.[!p] <- Char.chr (Char.code mem.[!p] + 1);
  print ();
  mem.[!p] <- Char.chr (Char.code mem.[!p] + 7);
  for i = 1 to 2 do print () done;
  mem.[!p] <- Char.chr (Char.code mem.[!p] + 3);
  print ();
  p := !p + 1;
  mem.[!p] <- Char.chr (Char.code mem.[!p] + 2);
  print ();
  p := !p - 2;
  mem.[!p] <- Char.chr (Char.code mem.[!p] + 15);
  print ();
  p := !p + 1;
  print ();
  mem.[!p] <- Char.chr (Char.code mem.[!p] + 3);
  print ();
  mem.[!p] <- Char.chr (Char.code mem.[!p] - 6);
  print ();
  mem.[!p] <- Char.chr (Char.code mem.[!p] - 8);
  print ();
  p := !p + 1;
  mem.[!p] <- Char.chr (Char.code mem.[!p] + 1);
  print ();
  p := !p + 1;
  print ()
