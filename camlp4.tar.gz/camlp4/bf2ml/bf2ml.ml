(* 
                       bf2ml: A Brainfuck to OCaml converter

   Camlp4 is used for creating and pretty-printing
   an OCaml syntax tree.
   Parsing is performed independently from Camlp4.

   The compiler can be compiled into a native code executable
   with the following command:
   
   ocamlopt -o bf2ml -pp 'camlp4o q_MLast.cmo -loc loc' -I +camlp4 camlp4.cmxa pr_o.cmx bf2ml.ml 

   Usage: bf2ml hello.bf > hello.ml
*)

open Printf

(* The internal representation of a Brainfuck program *)
type bytecode =
    Greater of int * bytecode
  | Plus of int * bytecode
  | Dot of int * bytecode
  | Comma of int * bytecode
  | Loop of bytecode * bytecode
  | End


(* Parsing the Brainfuck syntax (with whitespace and # end-of-line comments) *)

let rec delimit_block n accu = function
    ']' :: l when n = 0 -> List.rev accu, l
  | ']' :: l -> delimit_block (n - 1) (']' :: accu) l
  | '[' :: l -> delimit_block (n + 1) ('[' :: accu) l
  | c :: l -> delimit_block n (c :: accu) l
  | [] -> failwith "missing ]"

let rec read_block = function
    '>' :: l -> Greater (1, (read_block l))
  | '<' :: l -> Greater (-1, (read_block l))
  | '+' :: l -> Plus (1, (read_block l))
  | '-' :: l -> Plus (-1, (read_block l))
  | '.' :: l -> Dot (1, (read_block l))
  | ',' :: l -> Comma (1, (read_block l))
  | '[' :: l -> 
      let l1, l2 = delimit_block 0 [] l in
      Loop (read_block l1, read_block l2)
  | ']' :: _ -> failwith "misplaced ]"
  | (' ' | '\n' | '\r' | '\t') :: l -> read_block l
  | '#' :: l -> next_line l
  | c :: _ -> failwith (sprintf "invalid character %c" c)
  | [] -> End

and next_line = function
    ('\n' | '\r') :: l -> read_block l
  | _ :: l -> next_line l
  | l -> read_block l

(* Compaction of the sequences of repeated commands *)

let rec simplify x =
  match x with
      Greater _ -> simplify_greater 0 x
    | Plus _ -> simplify_plus 0 x
    | Dot _ -> simplify_dot 0 x
    | Comma _ -> simplify_comma 0 x
    | Loop (a, b) -> Loop (simplify a, simplify b)
    | End -> End
  
and simplify_greater n = function
    Greater (i, x) -> simplify_greater (n + i) x
  | x -> 
      if n = 0 then simplify x
      else Greater (n, simplify x)

and simplify_plus n = function
    Plus (i, x) -> simplify_plus (n + i) x
  | x -> 
      if n = 0 then simplify x
      else Plus (n, simplify x)

and simplify_dot n = function
    Dot (i, x) -> simplify_dot (n + i) x
  | x -> Dot (n, simplify x)

and simplify_comma n = function
    Comma (i, x) -> simplify_comma (n + i) x
  | x -> Comma (n, simplify x)


let compile program =
  let accu = ref [] in
  for i = 0 to String.length program - 1 do
    accu := program.[i] :: !accu
  done;
  let l = List.rev !accu in
  simplify (read_block l)


(* Code generator *)

let make_camlp4_ast compiled_program =
  let loc = (Lexing.dummy_pos, Lexing.dummy_pos) in
  let sequence loc l = <:expr< do { $list:l$ } >> in

  let rec convert x =
    match x with
	Greater (n, x) -> 
	  (if n < 0 then
	     <:expr< p.val := p.val - $int:string_of_int (-n)$ >>
	   else
	     <:expr< p.val := p.val + $int:string_of_int n$ >>) 
	  :: convert x
      | Plus (n, x) -> 
	  (if n < 0 then
	     <:expr< mem.[p.val] := 
	        Char.chr (Char.code mem.[p.val] - $int:string_of_int (-n)$) >>
	   else
	     <:expr< mem.[p.val] := 
	        Char.chr (Char.code mem.[p.val] + $int:string_of_int n$) >>)
	  :: convert x
      | Dot (n, x) ->
	  let e = 
	    match n with
		1 -> <:expr< do { print () } >>
	      | _ -> 
		  <:expr< 
		  for i = 1 to $int:string_of_int n$ do  {
		    print ()
		  } >> in
	  e :: convert x

      | Comma (n, x) -> 
	  let e = 
	    match n with
		1 -> <:expr< mem.[p.val] := input_char stdin >>
	      | _ -> 
		  <:expr< 
		  for i = 1 to $int:string_of_int n$ do {
		    mem.[p.val] := input_char stdin
		  } >> in
	  e :: convert x

      | Loop (loop, x) ->
	  <:expr< 
	  while Char.code mem.[p.val] > 0 do {
	    $sequence loc (convert loop)$
	  } >> :: convert x

      | End -> [] in

  let main = sequence loc (convert compiled_program) in
  let implem =
    [ <:str_item< value mem = String.make 30_000 (Char.chr 0) >>, loc;
      <:str_item< value p = ref 0 >>, loc;
      <:str_item< value print () = 
                   do { print_char mem.[p.val]; flush stdout } >>, loc;
      <:str_item< value () = $main$ >>, loc ] in
  implem


let file_contents file =
  let ic = open_in file in
  let buf = Buffer.create 1000 in
  (try
     while true do 
       Buffer.add_char buf (input_char ic)
     done
   with End_of_file -> ());
  close_in ic;
  Buffer.contents buf

let _ =
  if not !Sys.interactive then
    let usage () = failwith "Usage: bf2ml file" in
    let program =
      match Sys.argv with
	  [| _; file |] -> (try file_contents file 
			    with _ -> usage ())
	| _ -> usage () in
    let bytecode = compile program in
    let ast = make_camlp4_ast bytecode in
    !Pcaml.print_implem ast
