let expr_list loc l =
  List.fold_right 
    (fun head tail -> <:expr< [ $head$ :: $tail$ ] >>)
    l
    <:expr< [] >>

RE lident = [lower '_'][alnum '_']*

let subst_string loc s =
  (* we find the identifiers written as $id or ${id} using a micmatch macro *)
  let map =
    MAP "$" ( ("$" as x)
	    | (lident as x)
	    | "{" space* (lident as x) space* "}") ->
      if x = "$" then `Text x
      else `Ident x in
  let pieces = map ~full:false s in
  let rec compact = function
      `Ident _ as head :: tail -> head :: compact tail
    | `Text "" :: tail -> compact tail
    | `Text a :: `Text b :: tail -> compact (`Text (a ^ b) :: tail)
    | head :: tail -> head :: compact tail
    | [] -> [] in
  let make_expr = function
      `Ident s -> <:expr< $lid:s$ >>
    | `Text s -> <:expr< $str: String.escaped s$ >> in
  match compact pieces with
      [] -> <:expr< "" >>
    | [a] -> make_expr a
    | [a; b] -> <:expr< $make_expr a$ ^ $make_expr b$ >>
    | l -> 
	<:expr< String.concat "" $expr_list loc (List.map make_expr l)$ >>

let _ = 
  (* the try-with around DELETE_RULE is important if other versions of Camlp4
     do not have the same exact rule in the same entry *)
  (try DELETE_RULE Pcaml.expr: STRING END with Not_found -> ());

  EXTEND
    Pcaml.expr: LEVEL "simple" [
      [ s = STRING -> subst_string loc (Token.eval_string loc s) ]
    ];
  END
