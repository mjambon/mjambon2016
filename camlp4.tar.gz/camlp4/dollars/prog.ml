let x = "abc" in
let y = String.uppercase x in
print_endline "${x}def$y"
