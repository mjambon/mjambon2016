open Printf
open Pipeline

let camlp4o = ref "camlp4o"
let camlp4r = ref "camlp4r"
let ocamllex = ref "ocamllex"
let ocamlc = ref "ocamlc"
let ocamlopt = ref "ocamlopt"
let ocamlfind = ref "ocamlfind"

let packs = ref []         (* findlib packages *)
let use_ocamllex = ref false (* preprocess with ocamllex before camlp4 *)
let use_camlp4 = ref true  (* by default camlp4 is used *)
let use_ocamlc = ref false (* by default we want native code *)
let use_ocamlfind = ref false (* used only if necessary *)
let revised = ref false    (* use this to use the revised syntax *)
let ocamlflags = Common.extra_args    
		           (* any options that you may want to pass
                              to ocamlopt *)
let ppopt = ref []         (* any options that you may want to pass
                              to camlp4o or camlp4r *)


let exe s =
  match Sys.os_type with
      "Win32" | "Cygwin"-> 
	if Filename.check_suffix s ".exe" then s
	else s ^ ".exe"
    | "Unix" | _ -> s

let ocamllex_command input =
  if !use_ocamllex then
    Some (new_cmd [!ocamllex; input; "-o"; "ocamllex_out.ml"; "-q"], 
	  "ocamllex_out.ml")
  else None

let ocaml_command input =
  let really_use_ocamlfind =
    match !use_ocamlfind, !packs with
	true, _ | _, _ :: _ -> true
      | _ -> false in
  let compiler =
    if really_use_ocamlfind then
      if !use_ocamlc then [!ocamlfind; "ocamlc"]
      else [!ocamlfind; "ocamlopt"]
    else
      if !use_ocamlc then [!ocamlc]
      else [!ocamlopt] in
      
  let flags = !ocamlflags in
  let camlp4_stuff =
    if !use_camlp4 then
      let syntax, camlp4 =
	if !revised then "camlp4r", !camlp4r
	else "camlp4o", !camlp4o in
      let ppoptions = 
	if !ppopt = [] then []
	else 
	  if really_use_ocamlfind then
	    List.flatten (List.map (fun s -> ["-ppopt"; s]) !ppopt)
	  else !ppopt in
      if really_use_ocamlfind then
	"-syntax" :: syntax :: ppoptions
      else 
	let space = function "" -> "" | s -> " " ^ s in
	["-pp"; sprintf "'%s%s'" camlp4 (space (String.concat " " ppoptions))]
    else [] in
  let packages =
    if really_use_ocamlfind then
      ["-linkpkg"; "-package";
       String.concat "," 
	 (if !use_camlp4 && not (List.mem "camlp4" !packs) then
	    "camlp4" :: !packs
	  else !packs) ]
    else [] in
  
  let args = compiler @ "-o" :: "prog" :: 
	       flags @ camlp4_stuff @ packages @ [input] in
  Some (new_cmd args, exe "prog")

let combine input l =
  let commands, output =
    List.fold_left 
      (fun ((l, input) as x) f -> 
	 match f input with
	     None -> x
	   | Some (cmd, new_input) -> (cmd :: l, new_input))
      ([], input) l in
  (List.rev commands, output)

let compile source result = 
  let internal_input = "main.ml" in
  let commands, internal_output =
    combine internal_input [ ocamllex_command; ocaml_command ] in
  let input = [internal_input, source] in
  let output = [internal_output, exe result] in
  let log = if !Common.verbose then Some stdout else None in
  run ?log ~input ~output
    { input = [internal_input];
      output = [internal_output];
      commands = commands }
