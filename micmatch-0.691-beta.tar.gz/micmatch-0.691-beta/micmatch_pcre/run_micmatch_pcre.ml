exception Micmatch_exit

open Pcre

let irflags = rflags []

external make_substrings : string * int array -> substrings = "%identity"

let search rex f ?(pos = 0) subj =
  let subgroup_offsets, offset_vector = make_ovector rex in
  let substrings = make_substrings (subj, offset_vector) in
  let subj_len = String.length subj in
  let rec loop cur_pos =
    if 
      try
	unsafe_pcre_exec 
	  irflags rex cur_pos subj subgroup_offsets offset_vector None; true
      with Not_found -> false
    then
      (f substrings;
       let first = offset_vector.(0) in
       let last = offset_vector.(1) in
       if first < subj_len then
	 loop (max (first + 1) last)) in
  loop pos

let scan ~full rex pos ~ftext ~fmatch subj =
  let subgroup_offsets, offset_vector = make_ovector rex in
  let substrings = make_substrings (subj, offset_vector) in
  let subj_len = String.length subj in
  let rec loop previous_last cur_pos =
    if 
      try
	unsafe_pcre_exec 
	  irflags rex cur_pos subj subgroup_offsets offset_vector None; true
      with Not_found -> 
	let last = String.length subj in
	if full || last > cur_pos then
	  ftext (String.sub subj cur_pos (last - cur_pos));
	false
    then
      (let first = offset_vector.(0) in
       let last = offset_vector.(1) in
       if full || first > pos then
	 ftext (String.sub subj previous_last (first - previous_last));
       fmatch substrings;
       if first < subj_len then
	 loop last (max (first + 1) last)
       else if full then
	 ftext "") in
  loop pos pos

let map rex f ?(pos = 0) ?(full = true) subj =
  let l = ref [] in
  let ftext s = l := `Text s :: !l
  and fmatch substrings = l := f substrings :: !l in
  scan ~full rex pos ~ftext ~fmatch subj;
  List.rev !l

let collect rex f ?(pos = 0) subj =
  let l = ref [] in
  let f substrings = l := f substrings :: !l in
  search rex f ~pos subj;
  List.rev !l

let split rex ?(full = false) ?(pos = 0) subj =
  let l = ref [] in
  let ftext s = l := s :: !l
  and fmatch substrings = () in
  scan ~full rex pos ~ftext ~fmatch subj;
  List.rev !l

