(* micmatch shootout.ml 1000 < Input *)

(* Implementation of the regexp matching problem of the Great Computer 
   Language Shootout (originally implemented by Markus Mottl with
   the OCaml-PCRE library).
   See http://shootout.alioth.debian.org/bench/regexmatch *)

RE d = ['0'-'9']
RE phone = (bos | _#'('#d) ("(" (d{3} as area) ")" | (d{3} as area))
	     " " (d{3} as exchange) [' ''-'] (d{4} as last) (eos | _#d)

let check_phone cnt must_print line =
  try (SEARCH_FIRST phone -> 
	 if must_print then 
	   (incr cnt;
	    Printf.printf "%d: (%s) %s-%s\n" !cnt area exchange last)) line
  with Not_found -> ()

let phones = Text.lines_of_channel stdin

let n = if Array.length Sys.argv > 1 then int_of_string Sys.argv.(1) else 1;;
for i = 2 to n do
  List.iter (check_phone (ref 0) false) phones
done;
List.iter (check_phone (ref 0) true) phones
