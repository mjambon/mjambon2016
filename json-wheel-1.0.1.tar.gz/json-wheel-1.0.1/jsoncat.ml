open Printf
open Arg
open Json_type
open Json_type.Build


let example ~compact () =
  let deep = 
    Json_io.json_of_string 
      "[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[ \"Hi!\"
       ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]" in
  let s = String.make 1_000_000 'x' in
  for i = 0 to 127 do
    s.[i] <- char_of_int i
  done;
  let x = 
    objekt [ "array", array (Array.to_list (Array.init 100_000 int));
	     "string", string s;
	     "int", int max_int;
	     "float", float 1e255;
	     "deep_array", array (Array.to_list (Array.make 1000 deep)) ] in
  print_endline (Json_io.string_of_json ~compact x)


let main () =
  let usage = "usage: jsoncat [-c] [-b] file" in
  let big_int_mode = ref false in
  let allow_comments = ref false in
  let compact = ref false in
  let file_name = ref None in
  let make_example = ref false in
  Arg.parse [
    "-b", Arg.Set big_int_mode, 
    "whether to accept large ints and represent them as strings";
    
    "-c", Arg.Set allow_comments, 
    "whether to allow C-style comments";
    
    "-compact", Arg.Set compact,
    "minimize the size of the output";
    
    "-x", Arg.Set make_example, 
    "generate a big sample file, for benchmarking purposes";
  ]
    (fun f -> file_name := Some f)
    usage;
  
  if !make_example then example ~compact:!compact ()
  else
    let fn = 
      match !file_name with 
	  None -> eprintf "%s\n%!" usage; exit 1
	| Some fn -> fn
    in
    let j = 
      try
	Json_io.load_json
	  ~allow_comments: !allow_comments 
	  ~big_int_mode: !big_int_mode 
	  fn
      with
	  Json_error s -> eprintf "%s\n%!" s; exit 1
	| e -> raise e in
    print_endline (Json_io.string_of_json ~compact:!compact j)

let _ = 
  if not !Sys.interactive then
    main ()
