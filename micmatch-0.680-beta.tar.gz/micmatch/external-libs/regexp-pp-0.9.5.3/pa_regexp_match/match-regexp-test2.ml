#load "./pa_regexp_match.cma";;

let _ =
  Regexp.match Sys.argv.(1) with
  | [] "^(\d+)? (\d+)?$" as c > (int_of_string) = 5, d : Int64.t option when true ->
      let d = match d with Some d -> d | None -> Int64.zero in
      Printf.printf "case B: %d %Ld\n" c d
