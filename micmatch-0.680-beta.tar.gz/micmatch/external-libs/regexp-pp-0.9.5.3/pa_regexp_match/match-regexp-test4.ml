#load "./pa_regexp_match.cma";;

let _ =
  begin
    Regexp.match "" with
      "AB" -> ()
    | _ -> ()
  end;
  begin
    let module M = struct
      let v () = 
	begin
	  Regexp.match "" with
	    "AB" -> ()
	  | _ -> ()
	end;
    end
    in M.v ()
  end

let _ =
  begin
    Regexp.match "" with
      "AB" -> ()
    | _ -> ()
  end
