open Printf

let _ =
  (* Load existing cache or create one *)
  let file = "store_demo.tbl" in
  let cache = Store.load file in

  (* Our test data f and g *)

  let x = "Hello" in
  let f () = (* returns a string *)
    printf "!!! Computing f()\n";
    x ^ "!" in

  let g () = (* returns an int *)
    printf "!!! Computing g()\n";
    1 + 1 in


  (* The same cache is used for f and g although they have different types. *)
  printf "Retrieving f()\n";
  printf "f() = %S\n" (Store.get cache f);
  printf "Retrieving f()\n";
  printf "f() = %S\n" (Store.get cache f);
  printf "Retrieving g()\n";
  printf "g() = %i\n" (Store.get cache g);
  printf "Retrieving g()\n";
  printf "g() = %i\n" (Store.get cache g);

  printf "Saving cache as %S\n" file;
  Store.save cache
