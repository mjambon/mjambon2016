open Printf

(* Printing functions.
   Important: (x, y) is a single function argument, and so is (a, b, c)! *)

let string_of_point (x, y) =
  sprintf "(%i, %i)" x y

let string_of_triangle (a, b, c) =
  sprintf "(%s, %s, %s)" 
    (string_of_point a)
    (string_of_point b)
    (string_of_point c) 


(* Functions that compute a point or a triangle.
   Important: note the extra () argument. *)

let point x y () = 
  let p = (x, y) in
  printf "Computed point %s\n" (string_of_point p);
  p

let triangle a b c () = 
  let t = (a, b, c) in
  printf "Computed triangle %s\n" (string_of_triangle t);
  t


(* Computations start here *)

let _ =
  let tbl = Store.load "triangle.tbl" in
  let a = Store.get tbl (point 1 2) in
  let b = Store.get tbl (point 3 4) in
  let c = Store.get tbl (point 5 6) in
  let the_triangle = Store.get tbl (triangle a b c) in
  printf "Triangle: %s\n" (string_of_triangle the_triangle);
  Store.save tbl
