(* Implementation of a polymorphic persistent cache for OCaml. *)

type t = { file : string;
	   tbl : (string, string) Hashtbl.t }

let get_key x = Marshal.to_string x [Marshal.Closures]
		  
let get t x =
  let tbl = t.tbl in
  let key = get_key x in
  try Marshal.from_string (Hashtbl.find tbl key) 0
  with Not_found ->
    let data = x () in
    Hashtbl.add tbl key (Marshal.to_string data [Marshal.Closures]);
    data
      
let store t x = ignore (get t x)

let load file =
  if Sys.file_exists file then
    let ic = open_in_bin file in
    let tbl = Marshal.from_channel ic in
    close_in ic;
    { tbl = tbl;
      file = file }
  else
    { tbl = Hashtbl.create 1000;
      file = file }

let save t =
  let oc = open_out t.file in
  Marshal.to_channel oc t.tbl [];
  close_out oc
