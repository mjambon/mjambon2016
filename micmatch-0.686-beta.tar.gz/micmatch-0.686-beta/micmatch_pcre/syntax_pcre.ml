(*pp ocamlrun ./version_filter -pp "camlp4o pa_extend.cmo q_MLast.cmo -loc loc -impl" *)

open Printf

open Regexp_ast
open Syntax_common
open Select_lib

let expand_macro ?(anchored = false) loc re e f =
  let (num, re_name) = new_regexp () in
  let var_name = var_of_regexp re_name in
  let (re_string, named_groups, postbindings) = 
    (!lib).process_regexp loc re re_name in
  add_compiled_regexp ~anchored postbindings
    loc re_name num re_string named_groups;
  
  !(lib).wrap_match 
    (f loc re_name var_name named_groups
       ((!lib).wrap_user_case e))

let check_assertion lookahead positive re =
  let rec check = function
      Bind (loc, e, name) -> check e
    | Bind_pos (loc, _) -> 0
    | Epsilon _ -> 0
    | Characters _ -> 1
    | Special (loc, s, (name, Some len)) -> len
    | Special (loc, s, (name, None)) -> 
	if not lookahead then
	  Messages.invalid_lookbehind loc
	    (sprintf "These patterns (%s)" name) ""
	else 0
    | Backref (loc, _) ->
	if not lookahead then
	  Messages.invalid_lookbehind loc "Backreferences" ""
	else 0
    | Sequence (loc, e1, e2) -> check e1 + check e2
    | Alternative (loc, e1, e2, _, _) -> 
	let len1 = check e1 in
	let len2 = check e2 in
	if not lookahead && len1 <> len2 then
	    Messages.invalid_lookbehind loc 
	      "Alternatives of different length" ""
	else max len1 len2
    | Repetition (loc, (kind, greediness), e) ->
	(match kind with
	     Range (x, None) -> x * check e
	   | _ -> 
	       if not lookahead then
		 Messages.invalid_lookbehind loc 
		   "Repetitions of variable length" ""
	       else check e)
    | Lookahead (loc, _, e) 
    | Lookbehind (loc, _, e) -> check e
    | Possessive (_, e)
    | Closed e -> check e in
  
  ignore (check re)


  

let lookahead loc bopt re =
  let positive = bopt = None in
  check_assertion true positive re;
  Lookahead (loc, positive, if positive then re else Closed re)

let lookbehind loc bopt re =
  let positive = bopt = None in
  check_assertion false positive re;
  Lookbehind (loc, positive, if positive then re else Closed re)

let extend_common () =
EXTEND
  Pcaml.expr: [
    [ UIDENT "RE_PCRE"; re = regexp -> 
	let (s, named_groups, postbindings) = 
	  Pcre_lib.lib.process_regexp loc re "" in
	
	<:expr< ( $str:String.escaped s$, 
		  $pp_named_groups loc named_groups$ ) >>

    | UIDENT "REPLACE"; re = regexp; "->"; e = Pcaml.expr ->
	expand_macro loc re e Pcre_lib.macro_replace

    | UIDENT "SEARCH"; re = regexp; "->"; e = Pcaml.expr ->
	expand_macro loc re e Pcre_lib.macro_search

    | UIDENT "MAP"; re = regexp; "->"; e = Pcaml.expr ->
	expand_macro loc re e Pcre_lib.macro_map

    | UIDENT "COLLECT"; re = regexp; "->"; e = Pcaml.expr ->
	expand_macro loc re e Pcre_lib.macro_collect

    | UIDENT "SPLIT"; re = regexp ->
	expand_macro loc re <:expr< () >> Pcre_lib.macro_split

    | UIDENT "REPLACE_FIRST"; re = regexp; "->"; e = Pcaml.expr ->
	expand_macro loc re e Pcre_lib.macro_replace_first

    | UIDENT "SEARCH_FIRST"; re = regexp; "->"; e = Pcaml.expr ->
	expand_macro loc re e Pcre_lib.macro_search_first

    | UIDENT "MATCH"; re = regexp; "->"; e = Pcaml.expr ->
	expand_macro ~anchored:true loc re e Pcre_lib.macro_match
    ]
  ];

  regexp: LEVEL "postop" [
    [ re = regexp; "*"; UIDENT "Lazy" -> 
	Repetition (loc, (Star, false), Closed re)
    | re = regexp; "+"; UIDENT "Lazy" ->
	Repetition (loc, (Plus, false), Closed re)
    | re = regexp; "?"; UIDENT "Lazy" ->
	Repetition (loc, (Option, false), Closed re)
    | r = regexp; "{"; (rng, rng_loc) = range; "}"; UIDENT "Lazy" -> 
	Repetition (loc, (Range rng, false), Closed r)
    | re = regexp; UIDENT "Possessive" ->
	Possessive (loc, re) ]
  ];

  regexp: LEVEL "simple" [
    [ "_" -> Characters (loc, Charset.full)
    | "<";
      x = OPT [ b1 = OPT "Not"; re1 = regexp -> (b1, re1) ]; 
      y = OPT [ "."; 
		r2 = OPT [ b2 = OPT "Not"; 
			   re2 = regexp -> (b2, re2) ] -> r2 ];
      ">" ->
	match x, y with
	    None, None
	  | None, Some None -> Epsilon loc
	  | None, Some (Some (b2, re2)) -> lookahead loc b2 re2
	  | Some (b1, re1), None -> lookahead loc b1 re1
	  | Some (b1, re1), Some None -> lookbehind loc b1 re1
	  | Some (b1, re1), Some (Some (b2, re2)) ->
	      Sequence (loc, lookbehind loc b1 re1, lookahead loc b2 re2) ]
  ];

END;;

let extend_regular () = extend_common ()
let extend_revised () = extend_common ()

let _ =
  select_lib Pcre_lib.lib;

  (match !Pcaml.syntax_name with
       "OCaml" -> extend_regular ()
     | _ -> extend_revised ())
