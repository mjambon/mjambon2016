(*pp camlp4o -I . *)
#load "pa_once.cma";;

module A = 
  struct
    let f () = once 1
    let f () = once 2
    module B = 
      struct
	let _ = once 3
	let f () = once 4
	let f () = once 5
      end
    let module C = 
      struct
	let _ = once 6
	let f () = once 7
	let f () = once 8
      end in
	()
  end

