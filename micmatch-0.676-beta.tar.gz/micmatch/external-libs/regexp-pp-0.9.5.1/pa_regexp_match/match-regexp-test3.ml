#load "../pa_pragma/pa_pragma.cmo";;
#load "./pa_regexp_match.cma";;
#pragma "no-shared-precompile";;

module type T = sig end
module A : T = 
  struct
    let f () = 
      Regexp.match "abc" with
	".*" -> "abc"
      |	"A.*" -> "abc"
      |	_ -> "def"
    let f () = 
      Regexp.match "abc" with
	".*" -> "abc"
      |	"A.*" -> "abc"
      |	_ -> "def"
    module B = 
      struct
	let f () = 
	  Regexp.match "abc" with
	    ".*" -> "abc"
	  |	"B.*" -> "abc"
	  |	_ -> "def"
	let f () = 
	  Regexp.match "abc" with
	    ".*" -> "abc"
	  |	"C.*" -> "abc"
	  |	_ -> "def"
      end
    let module C = 
      struct
	let f () = 
	  Regexp.match "abc" with
	    ".*" -> "abc"
	  |	"D.*" -> "abc"
	  |	_ -> "def"
	let f () = 
	  Regexp.match "abc" with
	    ".*" -> "abc"
	  |	"E.*" -> "abc"
	  |	_ -> "def"
      end in
	()
  end

let f () = 
  Regexp.match "abc" with
    ".*" -> "abc"
  | "D.*" -> "abc"
  | _ -> "def"
	
