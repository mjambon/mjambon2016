(*pp ocamlrun ./version_filter -pp "camlp4o pa_extend.cmo q_MLast.cmo -impl" *)

open Printf

open Regexp_ast
open Constants
open Select_lib

type re_match = { rem_loc : MLast.loc;
		  rem_re_name : string;
		  rem_num : int;
		  rem_re_string : string;
		  rem_groups : named_groups }

module Lids = Set.Make (struct
			  type t = MLast.loc * string
			  let compare (_, s1) (_, s2) = String.compare s1 s2
			end)

let lids_elements set =
  let strings = List.map snd (Lids.elements set) in
  List.sort String.compare strings

type special_patt = 
    { spe_patt : MLast.patt;
      spe_lids : Lids.t;
      spe_rem : re_match list;
      spe_sub : (string * special_patt) list }


(* Options *)
let lib = ref Select_lib.dummy
let tailrec = ref true


let has_prefix ~prefix s =
  String.length s >= String.length prefix &&
  String.sub s 0 (String.length prefix) = prefix

let match_suffix ~suffix s =
  let len = String.length s in
  let slen = String.length suffix in
  if len >= slen &&
    String.sub s (len - slen) slen = suffix then 
      String.sub s 0 (len - slen)
  else 
    invalid_arg "match_suffix"
  

let is_reserved s =
  has_prefix ~prefix:reserved_prefix s

let regexp_of_var var_name =
  match_suffix ~suffix:"_target" var_name

let var_of_regexp re_name =
  re_name ^ "_target"

let posix_regexps =
  List.map 
    (fun (name, set) -> (name, Characters (dummy_loc, set)))
    Charset.Posix.all

let named_regexps =
  (Hashtbl.create 13 : (string, Regexp_ast.ast) Hashtbl.t)

let fill_tbl tbl l =
  List.iter 
    (fun (key, data) -> Hashtbl.add tbl key data)
    l

let init_named_regexps () =
  fill_tbl named_regexps posix_regexps;
  fill_tbl named_regexps !(lib).predefined_regexps

let reset_named_regexps () =
  Hashtbl.clear named_regexps;
  fill_tbl named_regexps posix_regexps;
  fill_tbl named_regexps !(lib).predefined_regexps

let select_lib x =
  lib := x;
  reset_named_regexps ()


let new_regexp =
  let r = ref 0 in
  fun () -> incr r; (!r, reserved_prefix ^ string_of_int !r)

let new_target =
  let r = ref 0 in
  fun () -> incr r; reserved_prefix ^ "match_target_" ^ string_of_int !r

let new_subpatt =
  let r = ref 0 in
  fun () -> incr r; reserved_prefix ^ "subpatt_" ^ string_of_int !r

let compiled_regexps = Hashtbl.create 100

let add_compiled_regexp ~anchored
  loc name num re_string named_groups =
  let expr = 
    let f =
      if anchored then (!lib).compile_regexp_match
      else (!lib).compile_regexp_search in
    f dummy_loc re_string in
  Declare_once.declare ~package:"mj" name (Declare_once.Expr expr);
  Hashtbl.add compiled_regexps 
    name
    { rem_loc = loc;
      rem_num = num;
      rem_re_name = name;
      rem_re_string = re_string;
      rem_groups = named_groups }

let find_compiled_regexp loc name =
  try Hashtbl.find compiled_regexps name
  with Not_found -> 
    Stdpp.raise_with_loc loc 
    (Invalid_argument ("find_compiled_regexp: " ^ name))


let bind_target ?(force_string = false) loc target =
  match target with
      <:expr< ( $list:el$ ) >> ->
		 let ids = List.map (fun _ -> new_target ()) el in
		 let idl = List.map 
			     (fun s -> <:expr< $lid:s$ >>)
			     ids in
		 let target = <:expr< ( $list:idl$ ) >> in
		 let make_target e =
		   List.fold_right2 
		     (fun x id e ->
			<:expr< let $lid:id$ = $x$ in $e$ >>)
		     el
		     ids
		     e in
		   
		 (make_target, target)
    | x ->
	let id = new_target () in
	let target = <:expr< $lid:id$ >> in
	let make_target = 
	  if force_string then 
	    fun e -> <:expr< let $lid:id$ = ($x$ : string) in $e$ >>
	  else 
	    fun e -> <:expr< let $lid:id$ = $x$ in $e$ >> in
	(make_target, target)
		     


let match_failure loc =
  <:expr< match () with [] >>

(*
let output_regmatch loc target_expr cases =
  let (make_target, target) = bind_target ~force_string:true loc target_expr in
  let e =
    List.fold_right 
      (fun (loc, re, e) other ->
	 let (num, name) = new_regexp () in
	 let (re_string, named_groups) = (!lib).process_regexp loc name re in
	 add_compiled_regexp loc name num re_string named_groups;
	 let success = !(lib).wrap_user_case e in
	 (!lib).match_and_bind loc name target named_groups success other)
      cases 
      (!(lib).wrap_user_case (match_failure loc)) in

  make_target (!(lib).wrap_match e)
*)

let check_same_ids loc e1 e2 =
  if not (Lids.equal e1 e2) then
    let diff_elements = 
      lids_elements (Lids.diff (Lids.union e1 e2) (Lids.inter e1 e2)) in
    Messages.unbalanced_bindings loc diff_elements


let check_different_ids loc e1 e2 =
  let inter = Lids.inter e1 e2 in
  if not (Lids.equal inter Lids.empty) then
    Messages.multiple_binding loc (lids_elements inter)

 
let add_new loc set x =
  if Lids.mem x set then
    Messages.multiple_binding loc [(snd x)];
  Lids.add x set

let add_if_needed loc set x = Lids.add x set


let keep patt = 
  let subpatt = { spe_patt = patt;
		  spe_lids = Lids.empty;
		  spe_rem = [];
		  spe_sub = [] } in
  (Lids.empty, false, `Normal, subpatt)

let sum_kind kind1 kind2 =
  if kind1 = `Special || kind2 = `Special then `Special
  else `Normal


let lids_from_list lids loc l get =
  List.fold_right
    (fun x (set, has_re, kind, spatts, subpatts, rems) ->
       let p = get x in
       let (local_set, local_has_re, local_kind, subpatt) = lids p in
       check_different_ids loc local_set set;
       (Lids.union local_set set, 
	(has_re || local_has_re),
	sum_kind kind local_kind,
	subpatt.spe_patt :: spatts, 
	subpatt.spe_sub @ subpatts,
	subpatt.spe_rem @ rems))
    l
    (Lids.empty, false, `Normal, [], [], [])
    
let rec lids patt =
  let loc = MLast.loc_of_patt patt in
  match patt with
    | <:patt< $lid:id$ >> ->

      if is_reserved id then
	let re_name = regexp_of_var id in
	let rem = find_compiled_regexp loc re_name in
	let set = 
	  Named_groups.fold 
	    (fun group_name _ accu ->
	       add_new loc accu (loc, group_name))
	    rem.rem_groups
	    Lids.empty in
	let subpatt = { spe_patt = patt;
			spe_lids = set;
			spe_rem = [rem];
			spe_sub = [] } in
	(set, true, `Special, subpatt)
      else
	let set = Lids.singleton (loc, id) in
	let subpatt = { spe_patt = patt;
			spe_lids = set;
			spe_rem = [];
			spe_sub = [] } in
	(set, false, `Normal, subpatt)
      
    | <:patt< $anti:e$ >> -> lids e
      
    | <:patt< $p1$ . $p2$ >> -> (recons_patt2 loc p1 p2 
				   (fun p1 p2 -> <:patt< $p1$ . $p2$ >>))
    | <:patt< $p1$ .. $p2$ >> -> (recons_patt2 loc p1 p2 
				   (fun p1 p2 -> <:patt< $p1$ .. $p2$ >>))
    | <:patt< $p1$ $p2$ >> -> (recons_patt2 loc p1 p2 
				   (fun p1 p2 -> <:patt< $p1$ $p2$ >>))
    | <:patt< ( $p1$ as $p2$ ) >> -> (recons_patt2 loc p1 p2 
					(fun p1 p2 -> 
					   <:patt< ( $p1$ as $p2$ ) >>))


    | <:patt< $p1$ | $p2$ >> -> 
      let (set1, has_re1, kind1, subpatt1) = lids p1 in
      let (set2, has_re2, kind2, subpatt2) = lids p2 in
      check_same_ids loc set1 set2;
      let subpatt =
	if kind1 = `Special || kind2 = `Special then
	  let var_name = new_subpatt () in
	  let spatt = <:patt< $lid:var_name$ >> in
	  { spe_patt = spatt;
	    spe_lids = set1;
	    spe_rem = [];
	    spe_sub = [var_name, subpatt1; var_name, subpatt2] }
	else
	  { spe_patt = <:patt< $subpatt1.spe_patt$ | $subpatt2.spe_patt$ >>;
	    spe_lids = subpatt1.spe_lids;
	    spe_rem = [];
	    spe_sub = subpatt1.spe_sub @ subpatt2.spe_sub } in
      (set1, (has_re1 || has_re2), `Special, subpatt)
	
    | <:patt< { $list:ppl$ } >> -> 
      let (set, has_re, kind, spatts, l, rems) = 
	lids_from_list lids loc ppl snd in
      let fields = 
	List.map2 (fun (p1, p2) spatt -> (p1, spatt)) ppl spatts in
      let subpatt = 
	{ spe_patt = <:patt< { $list:fields$ } >>;
	  spe_lids = set;
	  spe_rem = rems;
	  spe_sub = l } in
      (set, has_re, kind, subpatt)
	
    | <:patt< [| $list:pl$ |] >> -> 
      let (set, has_re, kind, spatts, l, rems) = 
	lids_from_list lids loc pl (fun x -> x) in
      let subpatt = 
	{ spe_patt = <:patt< [| $list:spatts$ |] >>;
	  spe_lids = set;
	  spe_rem = rems;
	  spe_sub = l } in
      (set, has_re, kind, subpatt)

    | <:patt< ( $list:pl$ ) >> -> 
      let (set, has_re, kind, spatts, l, rems) = 
	lids_from_list lids loc pl (fun x -> x) in
      let subpatt = 
	{ spe_patt = <:patt< ( $list:spatts$ ) >>;
	  spe_lids = set;
	  spe_rem = rems;
	  spe_sub = l } in
      (set, has_re, kind, subpatt)

      
    | <:patt< ( $p$ : $t$ ) >> -> 
      recons_patt1 loc p (fun p -> <:patt< ( $p$ : $t$ ) >>)
     
    | <:patt< $chr:_$ >>
    | <:patt< $int:_$ >>
    | <:patt< $str:_$ >>
    | <:patt< $uid:_$ >>
    | <:patt< $flo:_$ >>
    | <:patt< _ >> -> keep patt

    | MLast.PaNativeInt (_, _) 
    | MLast.PaInt64 (_, _) 
    | MLast.PaInt32 (_, _) -> keep patt

    | MLast.PaVrn (_, _) 
    | MLast.PaTyp (_, _) -> keep patt

    | MLast.PaOlb _    (* optional label *)
    | MLast.PaLab _ -> (* label *)
	Messages.invalid_pattern loc keep patt

and recons_patt1 loc p1 f =
  let (set1, has_re1, kind1, 
       { spe_patt = spatt1; spe_rem = rems1; spe_sub = l1 }) = lids p1 in
  let spatt = f spatt1 in
  let subpatt = { spe_patt = spatt;
		  spe_lids = set1;
		  spe_rem = rems1;
		  spe_sub = l1 } in
  (set1, has_re1, kind1, subpatt)

and recons_patt2 loc p1 p2 f =
  let (set1, has_re1, kind1, 
       { spe_patt = spatt1; spe_rem = rems1; spe_sub = l1 }) = lids p1 in
  let (set2, has_re2, kind2, 
       { spe_patt = spatt2; spe_rem = rems2; spe_sub = l2 }) = lids p2 in
  check_different_ids loc set1 set2;
  let kind = sum_kind kind1 kind2 in
  let spatt = f spatt1 spatt2 in
  let set = Lids.union set1 set2 in
  let subpatt = { spe_patt = spatt;
		  spe_lids = set;
		  spe_rem = rems1 @ rems2;
		  spe_sub = l1 @ l2 } in
  (set, (has_re1 || has_re2), kind, subpatt)


let id_list set = 
  List.sort (fun (_, a) (_, b) -> String.compare a b) (Lids.elements set)

let expr_id_list l =
  List.map (fun (loc, s) -> <:expr< $lid:s$ >>) l

let patt_id_list l =
  List.map (fun (loc, s) -> <:patt< $lid:s$ >>) l

let expr_is_lid = function
    <:expr< $lid:_$ >> -> true
  | _ -> false

let patt_is_lid = function
    <:patt< $lid:_$ >> -> true
  | _ -> false


let simplify_match loc target l default = 
  (* target is an expr that should not compute anything *)
  (* user-defined but unused expressions are kept for the type checker *)
  (* default normally raises a match_failure or reraises an exception *)
  match l with
      [] -> default
    | [(<:patt< _ >> , (None | Some <:expr< True >>), e)] -> e
    | [(<:patt< $lid:id$ >>, (None | Some <:expr< True >>), e)]
	when expr_is_lid target ->
	<:expr< let $lid:id$ = $target$ in $e$ >>
    | _ ->
	let l' = l @ [<:patt< _ >>, None, default] in
	<:expr< match $target$ with [ $list:l'$ ] >>

let match_one_case loc target patt success failure =
  match patt with
      <:patt< _ >> -> (success, false)
    | <:patt< $lid:_$ >> -> 
      (<:expr< let $patt$ = $target$ in $success$ >>, false)
    | _ ->
	(<:expr< match $target$ with 
	     [ $patt$ when True -> $success$
	     | _ -> $failure$ ] >>,
	 true)

let re_match rem_list expr = 
  let result =
    List.fold_right
      (fun { rem_loc = loc;
	     rem_re_name = re_name;
	     rem_groups = named_groups } success ->
	 let var_name = var_of_regexp re_name in
	 let target = <:expr< $lid:var_name$ >> in
	 let failure = raise_exit loc in
	 (!lib).match_and_bind 
	   loc re_name target named_groups success failure)
      rem_list
      expr in
  let may_fail = rem_list <> [] in
  (result, may_fail)

let expand_subpatt loc l after_success =
  match l with
      [] ->
	(* This case never raises Exit *)
	(after_success, false)

    | (_, { spe_lids = set }) :: _ ->
	let vars = id_list set in
	let subresult = 
	  match vars with
	      [] -> <:expr< () >>
	    | [loc,s] -> <:expr< $lid:s$ >>
	    | _ -> <:expr< ( $list:expr_id_list vars$ ) >> in
	let rec expand loc l =
	  match l with
	      [] -> subresult
	    | _ ->
		match
		  List.fold_right
		    (fun (var, subpatt) rest -> 
		       let patt = subpatt.spe_patt in
		       let l = subpatt.spe_sub in
		       let rem_list = subpatt.spe_rem in
		       let (success, may_fail1) = 
			 re_match rem_list (expand loc l) in
		       let failure = <:expr< raise $expr_exit loc$ >> in
		       let target = <:expr< $lid:var$ >> in
		       let (match_expr, may_fail2) = 
			 match_one_case loc
			   target patt success failure in
		       match rest with
			   None -> 
			     (* succeed or raise Exit, which is a failure *)
			     Some match_expr

			 | Some real_rest ->
			     (* catch Exit and try the next alternative *)
			     Some (if may_fail1 || may_fail2 then <:expr<
				     try $match_expr$
				     with [ $patt_exit loc$ -> $real_rest$ ] >>
				   else match_expr))
		    l
		    None
		with 
		    None -> subresult
		  | Some e -> e in

	let result_expr =
	  match vars with
	      [] -> <:expr< do { $expand loc l$; $after_success$ } >>
            | _ ->
		let p = 
		  match vars with 
		      [loc,s] -> <:patt< $lid:s$ >>
		    | _ -> <:patt< ( $list:patt_id_list vars$ ) >> in
		
		<:expr< let $p$ = $expand loc l$ in $after_success$ >> in

        (* This whole expression raises Exit if the test fails *)
        (result_expr, true)
	

let extract_re cases =
  List.fold_right
    (fun (loc, patt, w, e) (has_re1, accu) ->
       let (all_names, has_re2, kind, subpatt) = lids patt in
       let more_cases = accu <> [] in
       ((has_re1 || has_re2),
	(loc, subpatt, w, e, has_re2, more_cases) ::
	  accu))
    cases
    (false, [])



let force_when patt when_opt =
  let loc = MLast.loc_of_patt patt in
  match when_opt with
      None -> Some <:expr< True >>
    | _ -> when_opt

let output_special_match loc target_expr cases_with_re default_action =
  let wrap_all = !(lib).wrap_match in
  let wrap = !(lib).wrap_user_case in
  let really_wrap = !(lib).really_wrap_user_case in
  let (clo, app) =
    if !tailrec then 
      (fun e -> let loc = MLast.loc_of_expr e in <:expr< fun [ () -> $e$ ] >>),
      (fun e -> let loc = MLast.loc_of_expr e in <:expr< $e$ () >>)
    else
      (fun e -> e),
      (fun e -> e) in
  
  let (make_target, target) = bind_target loc target_expr in
  (*let failure_case = 
    (loc, <:patt< _ >>, None, wrap default_action, [], false) in*)
  let raise_exit = <:expr< raise $expr_exit loc$ >> in
  let (cases_without_regexp, final_expr) = 
    List.fold_right 
      (fun (_, subpatt, when_opt, user_expr, has_re, more_cases) 
	   (cases_without_regexp, match_next) ->
	     let patt = subpatt.spe_patt in
	     let subpatts = subpatt.spe_sub in
	     match has_re, when_opt, subpatts with

		 false, (None | Some <:expr< True >>), [] -> 

		   (((patt, force_when patt when_opt, wrap (clo user_expr)) :: 
			 cases_without_regexp), 
		      match_next)

	       | false, Some guard, [] when not really_wrap ->

		   (((patt, force_when patt when_opt, clo user_expr) :: 
			 cases_without_regexp), 
		      match_next)

	       | _ ->
		   let e4 =
		     match when_opt with
			 None -> clo user_expr
		       | Some cond -> 
			   <:expr<
			   if $cond$ then $clo user_expr$ 
			   else $raise_exit$ >> in
		   let e3 = wrap e4 in
		   let (e2, may_fail1) = re_match subpatt.spe_rem e3 in
		   let (e1, subpatt_may_fail) =
		     expand_subpatt loc subpatts e2 in
		   let success = e1 in
		   let failure = raise_exit in
		   let (this_match, may_fail2) =
		     match_one_case loc target patt success failure in
		   let rematch =
		     simplify_match 
		       loc target cases_without_regexp match_next in
		   let e =
		     if may_fail1 || may_fail2 || subpatt_may_fail 
		     then <:expr< 
		       try $this_match$
		       with [ $patt_exit loc$ -> $rematch$ ] >>
		     else this_match in
		   ([], e))
      cases_with_re
      ([], (wrap (clo default_action))) in
  
  let full_expr =
    simplify_match loc target cases_without_regexp final_expr in
  make_target (app (wrap_all full_expr))

let unloc l = List.map (fun (loc, a, b, c) -> (a, b, c)) l

let output_match loc target_expr cases =
  match extract_re cases with
      false, _ -> (* change nothing *)
	<:expr< match $target_expr$ with [ $list:unloc cases$ ] >>

    | true, cases_with_re -> 
	output_special_match loc target_expr cases_with_re (match_failure loc)
	

let output_try loc e cases =
  match extract_re cases with
      false, _ -> (* change nothing *)
	<:expr< try $e$ with [ $list:unloc cases$ ] >>
    | true, cases_with_re -> 
	let exn = <:expr< $lid:any_exn$ >> in
	let default_action = <:expr< raise $exn$ >> in
	<:expr<
	try $e$ 
	with [ $lid:any_exn$ -> 
	       $output_special_match loc exn cases_with_re default_action$ ] >>

let output_function loc cases =
  match extract_re cases with
      false, _ -> (* change nothing *)
	<:expr< fun [ $list:unloc cases$ ] >>
    | true, cases_with_re -> 
	let target = <:expr< $lid:any_target$ >> in
	<:expr<
	fun $lid:any_target$ ->
	  $output_special_match loc 
	  target cases_with_re (match_failure loc)$ >>


let pp_named_groups loc named_groups =
  let l = Named_groups.list named_groups in
  List.fold_right
    (fun (name, il) e -> 
       let el = 
	 List.fold_right
	   (fun (loc, i) e -> 
	      <:expr< [ $int:string_of_int i$ :: $e$ ] >>) 
	   il
	   <:expr< [ ] >> in
       <:expr< [ ( $str:String.escaped name$, $el$ ) :: $e$ ] >>)
    l
    <:expr< [ ] >>


let regexp = Grammar.Entry.create Pcaml.gram "regexp";;
let regexp_match_case = Grammar.Entry.create Pcaml.gram "regexp";;
let range = Grammar.Entry.create Pcaml.gram "range";;

let eval_string loc s =
#if 3.06 | 3.07pre | 3.07 | 3.07_5
  Token.eval_string s
#else
  Token.eval_string loc s

let find_named_regexp loc name =
  try Hashtbl.find named_regexps name
  with Not_found ->
    Stdpp.raise_with_loc loc
    (Failure ("Unbound regular expression " ^ name))

let extend_common () =
EXTEND
  GLOBAL: regexp regexp_match_case range;

  Pcaml.str_item: [
    [ "RE"; name = LIDENT; "="; re = regexp -> 
	Hashtbl.add named_regexps name re;
      <:str_item< declare end >> ]
  ];

  Pcaml.patt: LEVEL "simple" [
    [ "RE"; re = regexp -> 
	let (num, re_name) = new_regexp () in
	let var_name = var_of_regexp re_name in
	let (re_string, named_groups) = (!lib).process_regexp loc re in
	add_compiled_regexp ~anchored:true
	  loc re_name num re_string named_groups;
	<:patt< $lid:var_name$ >> ]
  ];

  regexp_match_case: [ 
    [ x1 = Pcaml.patt; 
      w = OPT [ "when"; e = Pcaml.expr -> e ]; "->"; 
      x2 = Pcaml.expr ->
        (loc, x1, w, x2) ]
  ];

  regexp: [
    [ r = regexp; "as"; i = LIDENT -> Bind (loc, r, i) ]
  | [ r1 = regexp; "|"; r2 = regexp -> alternative loc r1 r2 ]
  | [ r1 = regexp; r2 = regexp -> Sequence (loc, r1, r2) ]

  | "postop" NONA
      [ r = regexp; "*" -> Repetition (loc, (Star, true), Closed r)
      | r = regexp; "+" -> Repetition (loc, (Plus, true), Closed r)
      | r = regexp; "?" -> Repetition (loc, (Option, true), Closed r)
      | r = regexp; "~" -> nocase r
      | r = regexp; "{"; (rng, rng_loc) = range; "}" -> 
	  if !(lib).unfold_range then repeat rng_loc (Closed r) rng
	  else Repetition (loc, (Range rng, true), Closed r) ]

  | "binop" LEFTA 
      [ r1 = regexp; "#"; r2 = regexp ->
	  let msg = " term is not a set of characters" in
	  let set1 = Regexp_ast.as_charset loc ("left" ^ msg) r1 in
	  let set2 = Regexp_ast.as_charset loc ("right" ^ msg) r2 in
	  Characters (loc, Charset.diff set1 set2) ]

  | "preop" NONA [ "!"; ident = LIDENT -> Backref (loc, ident) ]

  | "simple" NONA 
      [ "["; set = charset; "]" -> Characters (loc, set)
      | s = string -> s
      | name = LIDENT -> find_named_regexp loc name
      | "("; r = regexp; ")" -> r
      ]
  ];

  string: [
    [ s = STRING -> Regexp_ast.of_string loc (eval_string loc s) ]
  | [ c = CHAR -> Characters (loc, Charset.singleton (Token.eval_char c)) ]
  ];

  charset: [
    [ "^"; x = charset -> Charset.complement x ]
  | [ c1 = CHAR; "-"; c2 = CHAR -> 
	Charset.range (Token.eval_char c1) (Token.eval_char c2) 

    | c = CHAR -> Charset.singleton (Token.eval_char c)
    | s = STRING -> Charset.of_string (eval_string loc s)
    | name = LIDENT -> 
	Regexp_ast.as_charset loc "not a set of characters" 
	  (find_named_regexp loc name)
    | set1 = charset; set2 = charset -> Charset.union set1 set2
    ]
  ];

  range: [
    [ mini = INT;
      maxi = 
	OPT ["-"; maxi = 
	       OPT [ maxi = INT -> int_of_string maxi ] -> maxi] -> 
	  let mini = int_of_string mini in
	  (mini, maxi), loc
    | mini = INT; "+" -> (int_of_string mini, Some None), loc ]
  ];

END;;

let extend_regular () =
  extend_common ();

  EXTEND
  Pcaml.expr: LEVEL "expr1" [
    [ "match"; target = Pcaml.expr; "with"; OPT "|";
      cases = LIST1 regexp_match_case SEP "|" -> 
	output_match loc target cases
    | "try"; e = Pcaml.expr; "with"; OPT "|";
      cases = LIST1 regexp_match_case SEP "|" -> 
	output_try loc e cases
    | "function"; OPT "|"; cases = LIST1 regexp_match_case SEP "|" ->
        output_function loc cases ]
  ];

  END


let extend_revised () =
  extend_common ();

  EXTEND
  Pcaml.expr: LEVEL "top" [
    [ "match"; target = Pcaml.expr; "with"; "[";
      cases = LIST1 regexp_match_case SEP "|"; "]" -> 
	output_match loc target cases
    | "try"; e = Pcaml.expr; "with"; "[";
      cases = LIST1 regexp_match_case SEP "|"; "]" -> 
	output_try loc e cases
    | "fun"; "["; cases = LIST1 regexp_match_case SEP "|"; "]" ->
        output_function loc cases ]
  ];

  END


let () =
  init_named_regexps ();

  Pcaml.add_option "-tailrec" 
    (Arg.Set tailrec)
    " produce code that preserves tail-recursivity (default)";

  Pcaml.add_option "-direct" 
    (Arg.Clear tailrec)
    " produce code that does not try to preserve tail-recursivity";

  (match !Pcaml.syntax_name with
       "OCaml" -> extend_regular ()
     | _ -> extend_revised ())
