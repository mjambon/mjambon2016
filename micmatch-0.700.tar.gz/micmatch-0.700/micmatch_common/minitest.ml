RE x = "OK"*

let f = function RE x as x -> x | _ -> "Failed"
let _ = print_endline (f "OK")
