let str_mutex = Mutex.create ()
