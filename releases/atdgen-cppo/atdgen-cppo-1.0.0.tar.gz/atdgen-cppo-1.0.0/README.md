`atdgen-cppo` allows to use [atdgen](http://oss.wink.com/atdgen/) to
derive code from ATD type definitions embedded in OCaml source files
rather than in separate `.atd` files.

It is designed to work with the
[cppo](http://martin.jambon.free.fr/cppo.html) preprocessor.
