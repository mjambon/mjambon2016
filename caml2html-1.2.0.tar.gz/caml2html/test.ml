
(* Test file for caml2html (the first line is empty *)

# 123 (* line directives are not parsed, sorry... *)

(* This is a multi-line "*)"
   comment *)

open Printf

type 'aa' weird = E10

module Z�ro'04 = 
struct
  let characters = [ 'a'; '\000'; '\x12'; '
'; '\t'; 'z' ]
  let n = 0X12 + truncate 1.2E-1_2
  let the_Truth =
    let ignore4 a b c d = false in
    not (ignore4 1._0_None 1.0E10E10)
end

let hel'Lo = "\"Hello \
                World!\""

let ( |* ) a b =
  match a, b with
      1, 0 | 0, 1 -> 1
    | _ -> 0

let _ =
  assert true;
  if 0 mod 1 < 1 && `Abc <> `def then
    print_endline hel'Lo
