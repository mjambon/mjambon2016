(* 
   Copyright 2002-2004 S�bastien Ailleret
   Copyright 2004 Martin Jambon
   
   This file is distributed under the terms of the GNU Public License
   http://www.gnu.org/licenses/gpl.txt
*)

open Output

let line_numbers = ref default_param.line_numbers
let title = ref default_param.title
let tab_size = ref default_param.tab_size
let footnote = ref default_param.footnote
let css = ref default_param.css
let css_url = ref default_param.css_url

let get_param () =
  { line_numbers = !line_numbers; 
    title = !title;
    tab_size = !tab_size;
    footnote = !footnote;
    css = !css;
    css_url = !css_url }


(* output file *)
let res_file = ref ""
(* output directory *)
let res_dir = ref ""


let usage = 
  "Usage: " ^ (Filename.basename Sys.argv.(0)) ^ " [options] file1 ... fileN
Options:"


let speclist =
  [
   ("-css", Arg.Unit (fun () -> css := true),
    ": use css for choosing style");
   ("-cssurl", Arg.String (fun s -> css_url := s),
    "url : specify the url of the css to use (style.css by default)");
   ("-ln", Arg.Unit (fun () -> line_numbers := true),
    ": add line number at the beginning of each line");
   ("-t", Arg.Unit (fun () -> title := true),
    ": add a title to the html page");
   ("-nf", Arg.Unit (fun () -> footnote := false),
    ": do not add footnotes to the html page");
   ("-notab", Arg.Unit (fun () -> tab_size := -1),
    ": do not replace tabs by spaces");
   ("-tab", Arg.Set_int tab_size,
    "n : replace tab by n spaces (default = 8)");
   ("-d", Arg.String (fun s -> res_dir := s),
    "dir : generate files in directory dir, rather than in current directory");
   ("-o", Arg.String (fun s -> res_file := s),
    "file : output file");
   ("-v", Arg.Unit (fun () -> Printf.printf "%s\n" version; exit 1),
    ": show version number");
   ("-make-css", Arg.String (fun s -> Output.make_css s),
    "file : create CSS file")
 ]



let handle_stdin_to_stdout param =
  let buf = Buffer.create 8192 in
  let l = Input.channel stdin in
  begin_document ~param buf [];
  Output.ocaml_file ~param buf l;
  end_document ~param buf;
  Buffer.output_buffer stdout buf

let manage_files param files =
  if !res_file = ""
  then
    (* handles files separately *)
    (let manage_one file =
      let buf = Buffer.create 8192 in
      begin_document ~param buf [file];
      handle_file ~param buf file;
      end_document ~param buf;
      save_file buf (file ^ ".html") in
    List.iter manage_one files)
  else
    (* groups all files into one *)
    ocaml_document ~param ~dir: !res_dir files !res_file


let () =
  let files = ref [] in
  Arg.parse
    speclist
    (fun x -> files := x :: !files)
    usage;
  if !res_file = "" && !files = [] then
    (title := false;
     handle_stdin_to_stdout (get_param ()))
  else
    (if !res_file <> "" && ((List.length !files) >= 2) then 
       title := true;
     (manage_files (get_param ())) (List.rev !files))
