type t = Json_type.t
open Json_type


(*** Parsing ***)

let check_string_is_utf8 s =
  let encoding =
    if String.length s < 4 then `UTF8
    else Json_lexer.detect_encoding s.[0] s.[1] s.[2] s.[3] in
  if encoding <> `UTF8 then
    json_error "Only UTF-8 encoding is supported" 

let filter_result x =
  Browse.assert_object_or_array x;
  x

let json_of_string ?(allow_comments = false) ?(big_int_mode = false) s = 
  check_string_is_utf8 s;
  filter_result (Json_parser.main 
		   (Json_lexer.token allow_comments big_int_mode)
		   (Lexing.from_string s))


let check_channel_is_utf8 ic =
  let start = pos_in ic in
  let encoding =
    try
      let c1 = input_char ic in
      let c2 = input_char ic in
      let c3 = input_char ic in
      let c4 = input_char ic in
      Json_lexer.detect_encoding c1 c2 c3 c4
    with End_of_file -> `UTF8 in
  if encoding <> `UTF8 then
    json_error "Only UTF-8 encoding is supported";
  (try seek_in ic start
   with _ -> json_error "Not a regular file")

(* from_channel and from_channel4 work 
   only on seekable devices (regular files) *)
let from_channel allow_comments big_int_mode file ic = 
  check_channel_is_utf8 ic;
  let lexbuf = Lexing.from_channel ic in
  Json_lexer.set_file_name lexbuf file;
  filter_result (Json_parser.main
		   (Json_lexer.token allow_comments big_int_mode)
		   lexbuf)


let load_json ?(allow_comments = false) ?(big_int_mode = false) file = 
  let ic = open_in file in
  let x =
    try `Result (from_channel allow_comments big_int_mode file ic)
    with e -> `Exn e in
  close_in ic;
  match x with
      `Result x -> x
    | `Exn e -> raise e


(*** Printing ***)

(* JSON does not allow rendering floats with a trailing dot: that is,
   1234. is not allowed, but 1234.0 is ok.  here, we add a '0' if
   string_of_int result in a trailing dot *)
let fprint_float fmt f =
  let s = string_of_float f in
  Format.fprintf fmt "%s" s;
  let s_len = String.length s in
  if s.[ s_len - 1 ] = '.' then
    Format.fprintf fmt "0"

let escape_json_string s =
  let buf = Buffer.create (String.length s) in
  String.iter (
    fun c -> 
      match c with 
	| '"'    -> Buffer.add_string buf "\\\""
	| '\t'   -> Buffer.add_string buf "\\t"
	| '\r'   -> Buffer.add_string buf "\\r"
	| '\b'   -> Buffer.add_string buf "\\b"
	| '\n'   -> Buffer.add_string buf "\\n"
	| '\012' -> Buffer.add_string buf "\\f"
	| '\\'   -> Buffer.add_string buf "\\\\"
     (* | '/'    -> "\\/" *) (* Forward slash can be escaped 
				but doesn't have to *)
	| '\x00'..'\x1F' (* Control characters that must be escaped *)
	| '\x7F' (* DEL *) -> 
	    Printf.bprintf buf "\\u%04X" (int_of_char c)
	| _      -> 
	    (* Don't bother detecting or escaping multibyte chars *)
	    Buffer.add_char buf c
  ) s;
  Buffer.contents buf

let quote_json_string fmt s =
  Format.fprintf fmt "\"%s\"" (escape_json_string s)


module Compact =
struct
  open Format

  let rec fprint_json fmt = function
      Object o -> 
	pp_print_string fmt "{";
	fprint_object fmt o;
	pp_print_string fmt "}"
    | Array a -> 
	pp_print_string fmt "[";
	fprint_list fmt a;
	pp_print_string fmt "]"
    | Bool b -> 
	pp_print_string fmt (if b then "true" else "false")
    | Null -> 
	pp_print_string fmt "null"
    | Int i -> pp_print_string fmt (string_of_int i)
    | Float f -> pp_print_string fmt (string_of_json_float f)
    | String s -> quote_json_string fmt s
	
  and fprint_list fmt = function
      [] -> ()
    | [x] -> fprint_json fmt x
    | x :: tl -> 
	fprint_json fmt x;
	List.iter (fun x -> pp_print_string fmt ","; fprint_json fmt x) tl
	  
  and fprint_object fmt = function
      [] -> ()
    | [x] -> fprint_pair fmt x
    | x :: tl -> 
	fprint_pair fmt x;
	List.iter (fun x -> pp_print_string fmt ","; fprint_pair fmt x) tl

  and fprint_pair fmt (key, x) =
    fprintf fmt "%a:%a" 
      quote_json_string key
      fprint_json x

  (* json does not allow rendering floats with a trailing dot: that is,
     1234. is not allowed, but 1234.0 is ok.  here, we add a '0' if
     string_of_int result in a trailing dot *)
  and string_of_json_float f =
    let s = string_of_float f in
    let s_len = String.length s in
    if s.[ s_len - 1 ] = '.' then
      s ^ "0"
    else
      s

  let print fmt x =
    Browse.assert_object_or_array x;
    fprint_json fmt x
end



(*** Pretty printing ***)

module Pretty =
struct
  open Format
    
  let rec fprint_json fmt = function
      Object o -> 
	fprintf fmt "{@;<1 2>@[%a@]@;<1 0>}" fprint_object o
    | Array a -> 
	fprintf fmt "[@;<1 2>@[%a@]@;<1 0>]" fprint_list a
    | Bool b -> 
	fprintf fmt "%s" (if b then "true" else "false")
    | Null -> fprintf fmt "null"
    | Int i -> fprintf fmt "%i" i
    | Float f -> fprint_float fmt f
    | String s -> quote_json_string fmt s
	
  and fprint_list fmt = function
      [] -> ()
    | [x] -> fprint_json fmt x
    | x :: tl -> 
	fprint_json fmt x;
	List.iter (fun x ->
		     fprintf fmt ","; 
		     pp_force_newline fmt ();
		     fprint_json fmt x) tl
	  
  and fprint_object fmt = function
      [] -> ()
    | [x] -> fprint_pair fmt x
    | x :: tl -> 
	fprint_pair fmt x;
	List.iter (fun x ->
		     fprintf fmt ","; 
		     pp_force_newline fmt ();
		     fprint_pair fmt x) tl
	  
  and fprint_pair fmt (key, x) =
    fprintf fmt "@[%a:@;<1 2>@[%a@]@]" quote_json_string key fprint_json x

  let print fmt x =
    Browse.assert_object_or_array x;
    fprint_json fmt x
end


let string_of_json ?(compact = false) x =
  let buf = Buffer.create 2000 in
  let fmt = Format.formatter_of_buffer buf in
  let fprint = 
    if compact then Compact.fprint_json
    else Pretty.fprint_json in
  fprint fmt x;
  Format.pp_print_flush fmt ();
  Buffer.contents buf

let save_json ?(compact = false) file x =
  let oc = open_out file in
  let print = 
    if compact then Compact.print
    else Pretty.print in
  let fmt = Format.formatter_of_out_channel oc in
  try
    print fmt x;
    Format.pp_print_flush fmt ();
    close_out oc
  with e -> 
    close_out_noerr oc;
    raise e
