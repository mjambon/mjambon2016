(*pp ocamlrun ./version_filter -pp "camlp4o pa_extend.cmo q_MLast.cmo -impl" *)

open Regexp_ast
open Syntax_common
open Select_lib

let expand_macro ?(anchored = false) loc re e f =
  let (num, re_name) = new_regexp () in
  let var_name = var_of_regexp re_name in
  let (re_string, named_groups, postbindings) = 
    (!lib).process_regexp loc re re_name in
  add_compiled_regexp ~anchored postbindings
    loc re_name num re_string named_groups;
  
  !(lib).wrap_match 
    (f loc re_name var_name named_groups
       ((!lib).wrap_user_case e))

let extend_common () =
EXTEND
  Pcaml.expr: [
    [ UIDENT "RE_PCRE"; re = regexp -> 
	let (s, named_groups, postbindings) = 
	  Pcre_lib.lib.process_regexp loc re "" in
	
	<:expr< ( $str:String.escaped s$, 
		  $pp_named_groups loc named_groups$ ) >>

    | UIDENT "REPLACE"; re = regexp; "->"; e = Pcaml.expr ->
	expand_macro loc re e Pcre_lib.macro_replace

    | UIDENT "SEARCH"; re = regexp; "->"; e = Pcaml.expr ->
	expand_macro loc re e Pcre_lib.macro_search

    | UIDENT "MAP"; re = regexp; "->"; e = Pcaml.expr ->
	expand_macro loc re e Pcre_lib.macro_map

    | UIDENT "COLLECT"; re = regexp; "->"; e = Pcaml.expr ->
	expand_macro loc re e Pcre_lib.macro_collect

    | UIDENT "SPLIT"; re = regexp ->
	expand_macro loc re <:expr< () >> Pcre_lib.macro_split

    | UIDENT "REPLACE_FIRST"; re = regexp; "->"; e = Pcaml.expr ->
	expand_macro loc re e Pcre_lib.macro_replace_first

    | UIDENT "SEARCH_FIRST"; re = regexp; "->"; e = Pcaml.expr ->
	expand_macro loc re e Pcre_lib.macro_search_first

    | UIDENT "MATCH"; re = regexp; "->"; e = Pcaml.expr ->
	expand_macro ~anchored:true loc re e Pcre_lib.macro_match
    ]
  ];

  regexp: LEVEL "postop" [
    [ re = regexp; "*"; UIDENT "Lazy" -> 
	Repetition (loc, (Star, false), Closed re)
    | re = regexp; "+"; UIDENT "Lazy" ->
	Repetition (loc, (Plus, false), Closed re)
    | re = regexp; "?"; UIDENT "Lazy" ->
	Repetition (loc, (Option, false), Closed re)
    | r = regexp; "{"; (rng, rng_loc) = range; "}"; UIDENT "Lazy" -> 
	Repetition (loc, (Range rng, false), Closed r)
    | re = regexp; UIDENT "Possessive" ->
	Possessive (loc, re) ]
  ];

  regexp: LEVEL "simple" [
    [ "_" -> Characters (loc, Charset.full) ]
  ];

END;;

let extend_regular () = extend_common ()
let extend_revised () = extend_common ()

let _ =
  select_lib Pcre_lib.lib;

  (match !Pcaml.syntax_name with
       "OCaml" -> extend_regular ()
     | _ -> extend_revised ())
