open Printf
open Genlex
open Parser_directive

let lexer = make_lexer [ ";"; "include"; "skip" ]

let get_token stream =
  fun _ ->
    try 
      match Stream.next stream with
	  String s -> STRING s
	| Int i -> INT i
	| Float f -> FLOAT f
	| Char c -> CHAR c
	| Ident s -> IDENT s
	| Kwd ";" -> SEP
	| Kwd "include" -> INCLUDE
	| Kwd "skip" -> SKIP
	| Kwd _ -> invalid_arg "Directive.get_token"
    with _ -> EOF
      
(* Adapted from String.index *)

let rec index_rec s lim i c =
  if i >= lim then raise Not_found else
    let cur = s.[i] in
  if cur = c then
    i 
  else if cur = ' ' || cur = '\n' || cur = '\t' || cur = '\r' then 
    index_rec s lim (i+1) c
  else 
    raise Not_found

let index s c = index_rec s (String.length s) 0 c

(* *)

let find_directives (source, line, char) s =
  try 
    let pos = index s '@' + 1 in
    let code = String.sub s pos (String.length s - pos) in
    let char_stream = Stream.of_string code in
    let token_stream = lexer char_stream in
    let result = directive_list
		   (get_token token_stream) 
		   (Lexing.from_string "") in
    Some result
  with
      Not_found -> None
    | e ->
	eprintf "File %S, line %i, characters %i-%i:\nBad directives\n"
	  source line (char - 1) (char - 1 + String.length s);
	flush stderr;
	raise e
