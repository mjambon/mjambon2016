open Printf
open Arg

let sources = ref []
let parse_only = ref false
let clean = ref false
let ocaml = ref "ocaml"
let stdout_file = ref None
let remix = ref false

let usage_msg = "\
Usage: camlmix [options] file1 file2 ... fileN

A temporary file \"fileN.ml\" is created and then executed
with ocaml.

Options:"

let options = [
  "-c",
  Set parse_only,
  " only generate the .ml file";
  
  "-clean",
  Set clean,
  " remove the temporary .ml file after execution";
  
  "-e",
  Set_string ocaml,
  "<ocaml>  specify ocaml executable";

  "-o",
  String (fun s -> stdout_file := Some s),
  "<file>  specify an output file";

  "-remix",
  Set remix,
  " try a conversion to the camlremix syntax";

  "-version",
  Unit (fun () -> print_endline Version.version; exit 0),
  "  prints the version of Camlmix and exits";
]

let add_source s = sources := s :: !sources

let camlmix_hooks oc =
  fprintf oc "\
module Camlmix =
struct
  let printer = ref (fun s -> print_string s; flush stdout)
  let print_with f =
    let saved_printer = !printer in
    printer := (fun s -> f s; printer := saved_printer)
  let print_if test =
    if not test then print_with ignore
end
"

let process_file oc in_file =
  let ic = open_in_bin in_file in
  let lexbuf = Lexing.from_channel ic in
  let list = Lexer.get lexbuf in
  close_in ic;

  List.iter 
    (function
	 `Text s -> 
	   fprintf oc "\nlet _ =\n  !Camlmix.printer %S;;\n" s
       | `Code s ->
	   fprintf oc "%s" s
       | `Location (line, char) ->
	   fprintf oc "# %i %S\n%s" line in_file
	     (String.make (char - 1) ' '))
    list


let protect_remix oc s =
  String.iter
    (function
	 '#' -> output_string oc "##"
       | '~' -> output_string oc "~~"
       | c -> output_char oc c)
    s

let remix_file in_file =
  let out_file = in_file ^ ".remix" in
  let oc = open_out out_file in
  let ic = open_in_bin in_file in
  let lexbuf = Lexing.from_channel ic in
  let list = Lexer.get lexbuf in
  close_in ic;

  List.iter 
    (function
	 `Text s -> protect_remix oc s
       | `Code s -> fprintf oc "#(%a)#" protect_remix s
       | `Location (line, char) -> ())
    list;

  close_out oc;
  printf "Wrote %s\n" out_file



let exec_ocaml out_file ml_file =
  let buf = Buffer.create 1000 in
  let ic = Unix.open_process_in (sprintf "%s %s" !ocaml ml_file) in
  (try
     while true do
       Buffer.add_char buf (input_char ic)
     done
   with End_of_file ->
     let finish () = if !clean then Sys.remove ml_file in
     match Unix.close_process_in ic with
	 Unix.WEXITED 0 -> finish ()
       | Unix.WEXITED n -> finish (); exit n
       | _ -> finish (); exit 2);

  match out_file with
      None -> Buffer.output_buffer stdout buf
    | Some file -> 
	let oc = open_out file in
	Buffer.output_buffer oc buf;
	close_out oc

let _ =
  parse options add_source usage_msg;
  let rev_in_files = !sources in
  match rev_in_files, !stdout_file with
      [], None -> ()
    | [], Some file -> close_out (open_out file)
    | l, opt ->
	if !remix then
	  List.iter remix_file l
	else
	  let ml_file = List.hd l ^ ".ml" in
	  let oc = open_out ml_file in
	  camlmix_hooks oc;
	  List.iter (process_file oc) (List.rev rev_in_files);
	  close_out oc;
	  if !parse_only then
	    exit 0
	  else
	    exec_ocaml opt ml_file
