#use "topfind"
#require "pcre"
#require "str"

let f res s =
  let rex = Pcre.regexp res in
  Pcre.get_substrings (Pcre.exec ~rex s)

let x = f "(?:(\\d+)|(?:\\d+(\\w+)))(?:\\1|\\2)" "123abab"
let y = f "(?i)a(?-i:b)(?i)c" "abC"

let g res s =
  let rex = Str.regexp res in
  Str.string_match rex s 0

let y =
  let s = "123123" in
  if g "\\(\\([0-9]+\\)\\|[0-9]+\\([a-z]+\\)\\)\\(\\2\\|\\3\\)" s then
    Str.matched_group 4 s
  else raise Not_found
