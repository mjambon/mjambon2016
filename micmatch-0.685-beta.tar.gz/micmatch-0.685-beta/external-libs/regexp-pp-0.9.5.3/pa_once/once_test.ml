(*pp camlp4o -I . *)
#load "pa_once.cma";;

type ('a, 'b) pair = 
    Cons of 'a * 'b

if false then
  once (while true do () done)

let x =
  once (1)

let x,y =
  once (1), once (2)

let (Some x, (Cons({ contents = v }, t)), [y,z; u], [| w |]) as l 
    = (Some 0, Cons(ref 0, 5), [once 2, 5; 3, 4], [| 4 |])
and a, b, _, 'c', (d : int) = once 2, 5, 3, 'c', once 15

let rec f x =
  if x < 1 then once (5) else once (1 + 3) * f (x - 1)

let rec odd x = if x = once 0 then false else even (x - 1)
and even x = if x = once 0 then true else even (x - 1)
