(*pp camlp4o *)
(************************************************************
 *
 * A part of Regexp/OCaml module.
 * 
 * (c) 2002-2003 Yutaka Oiwa. All Rights Reserved.
 *
 * This file is distributed under the terms of the Q Public
 * License version 1.0.
 *
 ************************************************************)
(* $Id: once_construct.ml 90 2004-09-02 19:14:58Z yutaka $ *)

open Printf

open Pcaml

#load "pa_extend.cmo";;
#load "q_MLast.cmo";;

let package = "onceexpr"

let _ =
  EXTEND
    expr: LEVEL "apply"
    [[ "once";
       r = SELF ->
	 let i = Declare_once.gensym ~package in
	 Declare_once.declare ~package i (Declare_once.Expr <:expr< lazy $r$ >>);
	 <:expr< Lazy.force $lid:i$ >>
     ]]
    ;
END

