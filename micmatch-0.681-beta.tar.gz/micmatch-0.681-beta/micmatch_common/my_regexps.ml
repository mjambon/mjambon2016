RE word = ['a'-'z' 'A'-'Z' '_']+
RE digit = ['0'-'9']
