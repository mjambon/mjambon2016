(* micmatch shootout.ml 10000 < Input *)

(* Implementation of the regexp matching problem of the Great Computer 
   Language Shootout (originally implemented by Markus Mottl with
   the OCaml-PCRE library).
   See http://shootout.alioth.debian.org/bench/regexmatch *)

(* 
   Notes on the use of micmatch:
   ----------------------------
   The regular expression is implemented using several features that
   we don't find in ocamllex: predefined character sets (digit),
   compact notations for sets of characters 
   (use of identifiers [^d'('] and string-like syntax [" -"]), 
   repeats (d{3}).

   Note that we do not use any indices for referencing the subgroups or
   for extracting the corresponding substrings, and that is cool.

   The code is slightly more compact than what we would write normally because
   we want to minimize the number of lines in the context of the Shootout :-)

   Notes on optimizations:
   ----------------------
   We use the ~share option of SEARCH_FIRST, because we are sure that
   this search will not be performed in parallel. It allows the reuse
   of the array of substring indices.

   The substrings area, exchange and last are created automatically, and
   there is no way to avoid their allocation, and we don't have an access
   to the position of the first matched character, so we can't use the same
   trick as in Markus' implementation to save the allocation of the 
   3 substrings (I hope you don't want to do that in real programs anyway). 
*)

RE d = digit
RE phone = (bos | [^d'(']) ("(" (d{3} as area) ")" | (d{3} as area))
	     " " (d{3} as exchange) [" -"] (d{4} as last) (eos | _#d)

let check_phone cnt must_print line =
  let f = SEARCH_FIRST phone -> 
    if must_print then 
      (incr cnt;
       Printf.printf "%d: (%s) %s-%s\n" !cnt area exchange last) in
  try f ~share:true line with Not_found -> ()

let phones = Micmatch.Text.lines_of_channel stdin in
let n = if Array.length Sys.argv > 1 then int_of_string Sys.argv.(1) else 1 in
for i = 2 to n do
  List.iter (check_phone (ref 0) false) phones
done;
List.iter (check_phone (ref 0) true) phones
