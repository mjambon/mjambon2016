(*pp camlp4o q_MLast.cmo -loc loc *)


let _ =
  Constants.mod_runtime := "Run_micmatch_pcre";
  Constants.mod_runtime_mt := "Run_micmatch_pcre"

(* PCRE: Perl Compatible Regular Expressions *)

open Printf

open Regexp_ast

let special_regexps = 
  let loc = Constants.dummy_loc in
  [ "any",   (* any character except newline *)
    Special (loc, ".", ("any", Some 1));
    
    "bol",   (* beginning of line *)
    Special (loc, "(?:^|(?<=\n))", ("bol", Some 0));

    "eol",   (* end of line *)
    Special (loc, "(?:$|(?=\n))", ("eol", Some 0));

    "bos",   (* beginning of string *)
    Special (loc, "^", ("bos", Some 0));
    
    "eos",   (* end of string *)
    Special (loc, "$", ("eos", Some 0)); ]


let string c = String.make 1 c

let quote_char c =
  match c with 
      '\\' | '^' | '$' | '.' | '[' | ']' | '|' 
    | '(' | ')' | '?' | '*' | '+' | '{' | '}' -> 
	let s = String.create 2 in
	s.[0] <- '\\'; s.[1] <- c; s
    | c -> string c

let quote_char_in_class c =
  match c with
      '\\' -> "\\\\"
    | ']' -> "\\]"
    | '-' -> "\\-"
    | '^' -> "\\^"
    | c -> string c


let reorder_charset l =
  if l = [] then
    invalid_arg "reorder_charset";
  List.sort Char.compare l

let compact l =
  let finish first last =
    match Char.code last - Char.code first with
	0 -> quote_char_in_class first
      | 1 -> (quote_char_in_class first) ^ (quote_char_in_class last)
      | _ -> (quote_char_in_class first) ^ "-" ^ (quote_char_in_class last) in

  let rec extend first last = 
    function 
	[] -> [finish first last]
      | c :: rest -> 
	  if Char.code c = Char.code last + 1 then 
	    extend first c rest
	  else
	    finish first last :: extend c c rest in

  match l with
      [] -> []
    | hd :: tl -> extend hd hd tl


let compact_charset loc l =
  let sorted = List.sort Char.compare l in
  let (zero, nozero) =
    match sorted with
	'\000' :: rest -> ("\\000", rest)
      | l -> ("", l) in
  String.concat "" (zero :: compact nozero)


let rec rm_closed = function Closed ast -> rm_closed ast | ast -> ast

let rec to_string ?(top = false) ((last_group, named_groups) as groups) buf = 
  function
      Epsilon loc -> groups
    | Special (loc, s, _) -> Buffer.add_string buf s; groups
    | Characters (loc, set) -> 
	let l = Charset.list set in
	(match l with
	     [] -> groups
	   | [c] ->
	       Buffer.add_string buf (quote_char c); 
	       groups
	   | _ ->
	       bprintf buf "[%s]" (compact_charset loc l);
	       groups)
	  
    | Sequence (loc, re1, re2) ->
	let groups = to_string groups buf re1 in
	to_string groups buf re2
	  
    | Alternative (loc, re, Epsilon _, _, _) ->

	let must_group = 
	  not top && 
	  match rm_closed re with
	      Characters _ | Special _ | Bind _ | Alternative _ -> false
	    | _ -> true in
	if must_group then Buffer.add_string buf "(?:";
	let (last_group, named_groups) as groups = 
	  to_string (last_group, named_groups) buf re in
	if must_group then Buffer.add_string buf ")";
	Buffer.add_string buf "?";
	groups

    | Alternative (loc, re1, re2, _, _) ->

	let must_group = not top in
	if must_group then Buffer.add_string buf "(?:";
	let (last_group, named_groups1) = 
	  to_string (last_group, named_groups) buf re1 in
	Buffer.add_string buf "|";

	let (last_group, named_groups2) = 
	  to_string (last_group, named_groups) buf re2 in
	if must_group then Buffer.add_string buf ")";

	let check_balance set1 set2 =
	  if not (Named_groups.equal set1 set2) then
	    (let missing = 
	       S.diff 
		 (Named_groups.union set1 set2) 
		 (Named_groups.inter set1 set2) in
	     Messages.unbalanced_bindings loc (list_named_groups missing)) in

	let (groups1, positions1) = named_groups1
	and (groups2, positions2) = named_groups2 in
	check_balance groups1 groups2;
	check_balance positions1 positions2;
	  
	(last_group, (merge groups1 groups2, merge positions1 positions2))
	  
    | Repetition (loc, (kind, greedy), re) ->
	let must_group =
	  not top && 
	  match rm_closed re with
	      Characters _ | Special _ | Bind _ 
	    | Alternative _ | Possessive _ -> false
	    | _ -> true in
	if must_group then
	  Buffer.add_string buf "(?:";
	let groups = to_string (last_group, named_groups) buf re in
	if must_group then
	  Buffer.add_string buf ")";
	let base_op =
	  match kind with
	      Star -> "*"
	    | Plus -> "+"
	    | Option -> "?"
	    | Range (m, None) -> sprintf "{%i}" m
	    | Range (m, Some None) -> sprintf "{%i,}" m
	    | Range (m, Some (Some n)) -> sprintf "{%i,%i}" m n in
	Buffer.add_string buf base_op;
	if not greedy then 
	  Buffer.add_string buf "?";
	groups
	  
    | Possessive (loc, re) ->
	Buffer.add_string buf "(?>";
	let groups = to_string groups buf re in
	Buffer.add_string buf ")";
	groups

    | Lookahead (loc, positive, re) ->
	let start = if positive then "(?=" else "(?!" in
	Buffer.add_string buf start;
	let groups = to_string groups buf re in
	Buffer.add_string buf ")";
	groups

    | Lookbehind (loc, positive, re) ->
	let start = if positive then "(?<=" else "(?<!" in
	Buffer.add_string buf start;
	let groups = to_string groups buf re in
	Buffer.add_string buf ")";
	groups

    | Bind (loc, re, name, conv) -> 
	let last_group = succ last_group in
	let named_groups = 
	  add_new_group loc name conv last_group named_groups in
	Buffer.add_string buf "(";
	let groups = to_string (last_group, named_groups) buf re in
	Buffer.add_string buf ")";
	groups

    | Bind_pos (loc, name) -> 
	let last_group = succ last_group in
	let named_groups = add_new_pos loc name last_group named_groups in
	Buffer.add_string buf "()";
	(last_group, named_groups)

    | Backref (loc, name) ->
	(try
	   match Named_groups.find name (fst named_groups) with
	       [] -> Messages.invalid_backref loc name
	     | [(_, n, conv)] -> bprintf buf "\\%i" n; groups
	     | l -> 
		 bprintf buf "(?:%s)" 
		   (String.concat "|"
		      (List.map (fun (_, n, conv) -> sprintf "\\%d" n) l));
		 groups
	 with Not_found -> Messages.invalid_backref loc name)
	    
    | Closed ast -> 
	let saved_named_groups = named_groups in
	let (last_group, named_groups) = to_string groups buf ast in
	(last_group, saved_named_groups)


(* Syntax expanders *)

open Constants

let process_regexp loc re re_name =
  let buf = Buffer.create 1000 in
  let (last_group, named_groups) = 
    to_string ~top:true (0, (Named_groups.empty, Named_groups.empty)) buf re in
  let re_string = Buffer.contents buf in
  let shared_id = shared re_name in
  let postbindings =
    [ shared_id, <:expr< Pcre.make_ovector $lid:re_name$ >>;
      subgroups2 re_name, <:expr< fst $lid:shared_id$ >>;
      shared_ovector re_name, <:expr< snd $lid:shared_id$ >> ] in
  (re_string, named_groups, postbindings)


let raises_exn = function
    <:expr< raise $exn$ >> -> true
  | _ -> false

let string_match loc re target substrings pos success failure =
  let match_it = 
    <:expr< Pcre.exec ~rex:$lid:re$ ~pos:$int:string_of_int pos$ $target$ >> in

  if raises_exn failure then (* shortcut *)
    <:expr< 
    let $lid:substrings$ = 
      try $match_it$
      with [ Not_found -> $failure$ ] in 
    $success$
    >>

  else
    <:expr<
    try
      let $lid:substrings$ = 
	try $match_it$
	with [ Not_found -> $raise_exit loc$ ] in 
      $success$
    with
	[ $patt_exit loc$ -> $failure$ ] >>


let matched_group loc substrings n =
  <:expr< Pcre.get_substring $lid:substrings$ $int:string_of_int n$ >>

let matched_position loc substrings n =
  <:expr< 
  Pervasives.fst 
    (Pcre.get_substring_ofs $lid:substrings$ $int:string_of_int n$) 
  >>

let compile_regexp_general ~anchored loc re_string =
  let default_flags = <:expr< [`DOLLAR_ENDONLY] >> in
  let anchored_flags = <:expr< [`ANCHORED; `DOLLAR_ENDONLY] >> in
  let flags = if anchored then anchored_flags else default_flags in
  <:expr<
  Pcre.regexp ~flags:$flags$
    $str:String.escaped re_string$ >>

let compile_regexp_match = compile_regexp_general ~anchored:true
let compile_regexp_search = compile_regexp_general ~anchored:false

let convert loc conv e =
  match conv with
      None -> e
    | Some f ->
	match f with
	    `Int -> <:expr< Pervasives.int_of_string $e$ >>
	  | `Float -> <:expr< Pervasives.float_of_string $e$ >>
	  | `Option -> <:expr< let s = $e$ in 
	                       if s = "" then None 
			       else Some s >>
	  | `Custom f -> <:expr< $f$ $e$ >>
	  | `Value e' -> <:expr< $e'$ >>
    
let insert_bindings_poly 
  ?(skip_empty_captures = false) (* for compatibility with 
				    old versions of Pcre (before 2004-04-29) *)
  make_expr loc substrings set e =
  Named_groups.fold
    (fun name l e -> 
       match l with
	   [] -> assert false
	 | (loc, _, _) :: _ ->
	     let find_it =
	       List.fold_right 
		 (fun (loc, n, conv) accu ->
		    let expr = make_expr loc substrings n in
		    match accu with
			None -> Some (convert loc conv expr)
		      | Some e ->
			  let result =
			    if skip_empty_captures then
			      <:expr<
			      try
				match $expr$ with 
				    [ "" -> raise Not_found
				    | s -> $convert loc conv <:expr< s >>$ ]
			      with [ Not_found -> $e$ ] >>
			    else
			      <:expr< 
			      try $convert loc conv expr$
			      with [ Not_found -> $e$ ] >> in
			  Some result)
		 l
		 None in
	     let result =
	       match find_it with
		   None -> assert false 
		 | Some e -> e in
	     <:expr< let $lid:name$ = $result$ in $e$ >>)
    set
    e
    
let insert_group_bindings = 
  insert_bindings_poly ~skip_empty_captures:true matched_group
let insert_position_bindings = insert_bindings_poly matched_position

let insert_bindings loc substrings (group_bindings, position_bindings) e =
  insert_group_bindings loc substrings group_bindings 
    (insert_position_bindings loc substrings position_bindings e)


let substrings_of_target target =
  match target with
      <:expr< $lid:s$ >> -> s ^ "_result"
    | _ -> assert false

let match_and_bind loc re_name target named_groups success failure =
  let substrings = substrings_of_target target in
  string_match loc re_name target substrings 0 
    (insert_bindings loc substrings named_groups success)
    failure

let macro_replace_generic f loc re_name target_name named_groups expr =
  let target = <:expr< $lid:target_name$ >> in
  let substrings = substrings_of_target target in
  <:expr<
  fun ?pos $lid:target_name$ ->
    Pcre.$lid: f$
    ~rex:$lid:re_name$ 
    ?pos
    ~subst:(fun $lid:substrings$ -> 
	      $insert_bindings loc substrings named_groups expr$)
    $target$ >>

let macro_replace = macro_replace_generic "substitute_substrings"
let macro_replace_first = macro_replace_generic "substitute_substrings_first"

let macro_match loc re_name target_name named_groups expr =
  let target = <:expr< $lid:target_name$ >> in
  let substrings = substrings_of_target target in
  let sv = shared_ovector re_name in
  let sg2 = subgroups2 re_name in
  <:expr<
  fun ?(share = False) ?pos $lid:target_name$ ->
    let $lid:substrings$ =
      if not share then
	Pcre.exec ~rex:$lid:re_name$ ?pos $target$
      else
	(Obj.magic 
	   ($target$,
	    do { Pcre.unsafe_pcre_exec 
		   (Obj.magic 0 : Pcre.irflag) 
		   $lid:re_name$ (match pos with [ None -> 0 | Some n -> n]) 
		   $target$ $lid:sg2$
		   $lid:sv$ None;
		 $lid:sv$ }) : Pcre.substrings) in
    $insert_bindings loc substrings named_groups expr$ >>

let macro_search_first = macro_match

let macro_function fun_name loc re_name target_name named_groups expr =
  let target = <:expr< $lid:target_name$ >> in
  let substrings = substrings_of_target target in
  <:expr<
  $uid: !mod_runtime$.$lid:fun_name$
    $lid:re_name$
    (fun $lid:substrings$ -> 
       $insert_bindings loc substrings named_groups expr$)
  >>


let macro_search = macro_function "search"
let macro_map = macro_function "map"
let macro_collect = macro_function "collect"

let macro_split loc re_name target_name named_groups expr =
  <:expr< $uid: !mod_runtime$.split $lid:re_name$ >>


open Select_lib

let lib = { predefined_regexps = special_regexps;
	    unfold_range = false;
	    process_regexp = process_regexp;
	    compile_regexp_match = compile_regexp_match;
	    compile_regexp_search = compile_regexp_search;
	    match_and_bind = match_and_bind;
	    wrap_match = (fun e -> e);
	    wrap_user_case = (fun e -> e);
	    really_wrap_match = false;
	    really_wrap_user_case = false }
