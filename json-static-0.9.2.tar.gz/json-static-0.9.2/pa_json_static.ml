(*
  Conversion between OCaml types and JSON types as provided by the json-wheel
  library. 
  
  Author: Martin Jambon <martin_jambon@emailuser.net>

Copyright (c) 2007 Burnham Institute for Medical Research
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*)


open Printf

let check_unique f l =
  let tbl = Hashtbl.create 50 in
  List.iter
    (fun x -> 
       let (_loc, id) = f x in
       if Hashtbl.mem tbl id then
	 Stdpp.raise_with_loc _loc
	   (Failure "this tag or label is not unique")
       else Hashtbl.add tbl id ())
    l

let unopt default = function
    None -> default
  | Some x -> x

type type_expr =
    List of t
  | Array of t
  | Option of t
  | Object of (string * string * t * bool * MLast.expr option) list
  | Hashtbl of t
  | Assoc of t
  | Tuple of t list
  | Variant of (string * string * t option) list
  | Name of string
  | String
  | Bool
  | Int
  | Float
  | Number
  | Raw
  | Custom of string

and t = Token.flocation * type_expr

module StringMap = Map.Make (String)

let make_typedef _loc names l =
  let rec convert (_loc, def) =
    match def with
	List x -> <:ctyp< list $convert x$ >>
      | Array x -> <:ctyp< array $convert x$ >>
      | Option x -> <:ctyp< option $convert x$ >>
      | Object l -> 
	  let ml = List.map (fun (name, _, t, _, _) -> (name, convert t)) l in
	  <:ctyp< < $list:ml$ > >>
      | Hashtbl x -> <:ctyp< Hashtbl.t string $convert x$ >>
      | Assoc x -> <:ctyp< list (string * $convert x$) >>
      | Tuple l -> 
	  let tl = List.map convert l in
	  <:ctyp< ( $list:tl$ ) >>
      | Variant l -> 
	  let rfl = 
	    List.map (fun (name, _, o) ->
			match o with
			    None -> MLast.RfTag (name, true, [])
			  | Some x -> MLast.RfTag (name, false, [convert x]))
	      l in
	  <:ctyp< [ = $list:rfl$ ] >>
      | Name x -> 
	  if StringMap.mem x names then <:ctyp< $lid:x$ >>
	  else
	    Stdpp.raise_with_loc _loc 
	      (Failure ("type name " ^ x ^ 
			" is undefined or not defined in the same \
                         'type ... and ...' block"))
      | String -> <:ctyp< string >>
      | Bool -> <:ctyp< bool >>
      | Int -> <:ctyp< int >>
      | Float -> <:ctyp< float >>
      | Number -> <:ctyp< float >>
      | Raw -> <:ctyp< Json_type.t >>
      | Custom s -> <:ctyp< $uid:s$ . t >> in

  let tdl = 
    List.map 
      (fun (name, def) ->
	 let ctyp = convert def in
	 (name, [], ctyp, []))
      l in
  <:str_item< type $list:tdl$ >>

let numbered_list l =
  Array.to_list
    (Array.mapi 
       (fun i x -> (x, "x" ^ string_of_int i))
       (Array.of_list l))

let make_ofjson _loc l =
  let browse _loc f = <:expr< Json_type.Browse.$lid:f$ >> in

  let rec convert (_loc, def) =
    match def with
	List x -> <:expr< $browse _loc "list"$ $convert x$ >>
      | Array x -> 
	  <:expr< fun x -> 
	    Array.of_list (($browse _loc "list"$ $convert x$) x) >>
      | Option x -> 
	  <:expr< $browse _loc "optional"$ $convert x$ >>
      | Object l ->
	  let eval =
	    List.map 
	      (fun (name, json_name, x, optional, default) ->
		 let e1 = 
		   let f = if optional then "fieldx" else "field" in
		   <:expr< 
		   (Json_type.Browse.$lid:f$ tbl $str:json_name$) >> in
		 let e2 =
		   match default with
		       Some e -> 
			 (<:expr< 
			  match $e1$ with 
			      [ Json_type.Null -> $e$
			      | x -> $convert x$ x ] >>)
		     | None -> <:expr< $convert x$ $e1$ >> in
		 
		 (<:patt< $lid:name$ >>, e2))
	      l in
	  let ml = 
	    List.map 
	      (fun (name, _, _, _, _) -> 
		 <:class_str_item< method $name$ = $lid:name$ >>)
	      l in
	  let obj = 
	    (* <:expr< object $list:ml$ end >> *)
	    MLast.ExObj (_loc, None, ml)
	  in
	  <:expr< 
	  fun x ->
	    let tbl = 
	      Json_type.Browse.make_table (Json_type.Browse.objekt x) in
	    let $list:eval$ in
	    $obj$ >>
      | Hashtbl x -> 
	  <:expr< 
	     fun x -> 
	       let l = $browse _loc "objekt"$ x in
	       let tbl = Hashtbl.create (List.length l) in
               do { List.iter (fun (s, x) -> 
				 Hashtbl.add tbl s ($convert x$ x)) l;
		    tbl } >>
      | Assoc x -> 
	  <:expr< fun x ->
	            List.map (fun (key, data) -> (key, $convert x$ data))
	              ($browse _loc "objekt"$ x) >>
      | Tuple l ->
	  let nl = numbered_list l in
	  let pl = 
	    List.fold_right 
	      (fun ((_loc, _), name) tl -> <:patt< [ $lid:name$ :: $tl$ ] >>) 
	      nl <:patt< [] >> in
	  let el = 
	    List.map (fun ((_loc, _) as x, name) ->
			<:expr< $convert x$ $lid:name$ >>)
	      nl in
	  <:expr< fun [ Json_type.Array [ $list:pl$ ] -> ( $list:el$ )
		      | Json_type.Array _ as x ->
			  __json_static_error x
			    "wrong number of elements in JSON array"
		      | x ->
			  __json_static_error x
			    "not a JSON array" ] >>
      | Variant l -> 
	  let pwel =
	    List.map
	      (fun (name, json_name, o) ->
		 match o with
		     None -> 
		       (<:patt< ( $str:json_name$, None ) >>, 
			None,
			<:expr< ` $name$ >>)
		   | Some arg ->
		       (<:patt< ( $str:json_name$, Some x ) >>, None, 
			<:expr< ` $name$ ($convert arg$ x) >>))
	      l in
	  let full_pwel =
	    pwel @ [ <:patt< _ >>, None, 
		     <:expr< __json_static_error x
                        "invalid variant name or wrong number of arguments" >>]
	  in
	  <:expr< 
	  fun x ->
	    let (name, arg) = 
	      match x with
		  [ Json_type.String s -> (s, None)
		  | Json_type.Array [ Json_type.String s; arg ] -> 
		      (s, Some arg)
		  | x -> __json_static_error x
		           "not able to read this as a variant" ] in
	    match (name, arg) with [ $list:full_pwel$ ] 
          >>
      | Name x -> <:expr< $lid: x ^ "_of_json"$ >>
      | String -> browse _loc "string"
      | Bool -> browse _loc "bool"
      | Int -> browse _loc "int"
      | Float -> browse _loc "float"
      | Number -> browse _loc "number"
      | Raw -> <:expr< fun x -> x >>
      | Custom modul -> <:expr< $uid:modul$ . of_json >> in

  let error =
    <:str_item< 
    value __json_static_error obj msg =
      let m = 400 in
      let s = Json_io.string_of_json obj in
      let obj_string =
	if String.length s > m then String.sub s 0 (m - 4) ^ " ..."
	else s in
      Json_type.json_error (msg ^ ":\n" ^ obj_string) >> in

  let defs = 
    List.map
      (fun ((_loc, name), x) -> 
	 let fname = name ^ "_of_json" in
	 (<:patt< ( $lid:fname$ : Json_type.t -> $lid:name$ ) >>, 
	  convert x)) l in
  <:str_item< declare $error$; value rec $list:defs$; end >>


let make_tojson _loc l =
  let build _loc s = <:expr< Json_type.Build. $lid:s$ >> in

  let rec convert (_loc, def) =
    match def with
	List x -> <:expr< Json_type.Build.list $convert x$ >>
      | Array x -> 
	  <:expr< fun x -> 
                    Json_type.Build.list $convert x$ (Array.to_list x) >>
      | Option x -> <:expr< Json_type.Build.optional $convert x$ >>
      | Object l -> 
	  let pairs = 
	    List.fold_right
	      (fun (name, json_name, x, _, _) tl ->
		 <:expr< [ ( $str:json_name$, $convert x$ x#$lid:name$ )
			   :: $tl$ ] >>)
	      l <:expr< [] >> in
	  <:expr< fun x -> Json_type.Object $pairs$ >>
      | Hashtbl x ->
	  <:expr< fun tbl -> 
	    Json_type.Object 
	      (Hashtbl.fold (fun key data tl -> 
			       [ (key, $convert x$ data) :: tl ])
		 tbl []) >>
      | Assoc x ->
	  <:expr< 
	    fun x ->
	      Json_type.Object
	        ((List.map (fun (key, data) -> (key, $convert x$ data))) x) >>
      | Tuple l ->
	  let nl = numbered_list l in
	  let pl = List.map (fun (_, name) -> <:patt< $lid:name$ >>) nl in
	  let a = List.fold_right 
		    (fun (x, name) tl -> 
		       <:expr< [ $convert x$ $lid:name$ :: $tl$ ] >>)
		    nl <:expr< [] >> in
	  <:expr< fun [ ( $list:pl$ ) -> Json_type.Array $a$ ] >>
      | Variant l -> 
	  let pwel =
	    List.map
	      (fun (name, json_name, o) ->
		 match o with
		     None -> 
		       (<:patt< ` $name$ >>, 
			None,
			<:expr< Json_type.String $str:json_name$ >>)
		   | Some x ->
		       (<:patt< ` $name$ arg >>, 
			None, 
			<:expr<
			Json_type.Array 
			  [ Json_type.String $str:json_name$;
			    $convert x$ arg ] >>))
	      l in
	  <:expr< fun [ $list:pwel$ ] >>
      | Name x -> <:expr< $lid: "json_of_" ^ x$ >>
      | String -> build _loc "string"
      | Bool -> build _loc "bool"
      | Int -> build _loc "int"
      | Float -> build _loc "float"
      | Number -> build _loc "float" (* yeah *)
      | Raw -> <:expr< fun x -> x >>
      | Custom modul -> <:expr< $uid:modul$ . to_json >> in

  let defs = 
    List.map
      (fun ((_loc, name), x) -> 
	 let fname = "json_of_" ^ name in
	 (<:patt< ( $lid:fname$ : $lid:name$ -> Json_type.t ) >>, 
	  convert x))
      l in
  <:str_item< value rec $list:defs$ >>


let expand_typedefs _loc l =
  check_unique (fun (name, x) -> name) l;
  let names = 
    List.fold_left 
      (fun m (((_loc, name), x) as data) -> StringMap.add name data m)
      StringMap.empty l in
  let typedef = make_typedef _loc names l in
  let ofjson = make_ofjson _loc l in
  let tojson = make_tojson _loc l in
  <:str_item< declare $typedef$; $ofjson$; $tojson$; end >>

let o2b = function None -> false | _ -> true

let is_reserved =
  let l = [ "json"; "json_type";
	    "string"; "bool"; "int"; "float"; 
	    "number"; "assoc" ] in
  let tbl = Hashtbl.create 20 in
  List.iter (fun s -> Hashtbl.add tbl s ()) l;
  Hashtbl.mem tbl

open Pcaml

EXTEND
  GLOBAL: str_item;
  str_item: LEVEL "top" [
    [ "type"; LIDENT "json"; 
      l = LIST1 type_binding SEP "and" -> expand_typedefs _loc l ]
  ];

  type_binding: [
    [ name = [ s = LIDENT -> 
		 if is_reserved s then
		   Stdpp.raise_with_loc _loc 
		     (Failure ("you can't use '" ^ s ^ "' as a type name"))
		 else (_loc, s) ]; "="; x = type_expr -> (name, x) ]
  ];

  type_expr: [
    "top" [
      x = type_expr; "*"; l = LIST1 type_expr LEVEL "simple" SEP "*" ->
	(_loc, Tuple (x :: l)) 
    ]
		
  | "simple" [
      x = type_expr; LIDENT "list" -> (_loc, List x)
    | x = type_expr; LIDENT "array" -> (_loc, Array x)
    | x = type_expr; LIDENT "option" -> (_loc, Option x)
    | "<"; l = methods; ">" -> (_loc, Object l)
    | "["; l = variants; "]" -> (_loc, Variant l)
    | "("; x = type_expr; ")" -> x
    | "("; LIDENT "string"; ","; x = type_expr; ")"; 
      UIDENT "Hashtbl"; "."; LIDENT "t" -> 
	(_loc, Hashtbl x)
    | "("; LIDENT "string"; "*"; x = type_expr; ")"; 
      LIDENT "assoc" ->
	(_loc, Assoc x)
    | name = LIDENT -> (_loc, Name name)
    | LIDENT "string" -> (_loc, String)
    | LIDENT "bool" -> (_loc, Bool)
    | LIDENT "int" -> (_loc, Int)
    | LIDENT "float" -> (_loc, Float)
    | LIDENT "number" -> (_loc, Number)
    | [ UIDENT "Json_type"; "."; LIDENT "json_type"
      | LIDENT "json_type" ] -> (_loc, Raw)
    | module_name = UIDENT; "."; LIDENT "t" -> 
	if module_name = "Json_type" then (_loc, Raw)
	else (_loc, Custom module_name) ]
  ];

  variants: [
    [ l = 
	LIST1 [ "`"; id = [ id = [ LIDENT | UIDENT ] -> (_loc, id) ]; 
		label = OPT [ s = STRING -> 
				(_loc, Token.eval_string _loc s) ];
		typ = OPT [ "of"; x = type_expr -> x ] -> 
		  (id, unopt id label, typ) ] 
	  SEP "|" -> 
	check_unique (fun (x, _, _) -> x) l;
        check_unique (fun (_, x, _) -> x) l;
	List.map (fun ((_, a), (_, b), c) -> (a, b, c)) l ]
  ];

  methods: [
    [ l = LIST0 
	    [ lab = method_label; x = type_expr; 
	      default = OPT [ "="; e = expr LEVEL "apply" -> e ] -> 
		let ((id, optional), label) = lab in
		(id, unopt id label, x, optional, default) ] 
	    SEP ";" ->
	check_unique (fun (x, _, _, _, _) -> x) l;
        check_unique (fun (_, x, _, _, _) -> x) l;
	List.map (fun ((_, a), (_, b), c, d, e) -> (a, b, c, d, e)) l ]
  ];

  method_label: [
    [ id_opt = [ id = LIDENT -> ((_loc, id), false)
	       | id = QUESTIONIDENT -> ((_loc, id), true) ]; 
      label = OPT [ s = STRING -> 
		      (_loc, Token.eval_string _loc s) ];
      ":" -> (id_opt, label)
    | id = OPTLABEL -> (((_loc, id), true), None) ]
  ];

END
