
let args = 
  match Sys.argv with
      [| |] | [| _ |] -> [| |]
    | ar -> Array.sub ar 1 (Array.length ar - 1) in
Unix.execvp "micmatch_str.top" 
  (Array.append 
    [| "micmatch_str.top"; 
       "-I"; "/home/martin/ocaml-cvs/lib/ocaml/site-lib/micmatch_str" |] 
    args)
