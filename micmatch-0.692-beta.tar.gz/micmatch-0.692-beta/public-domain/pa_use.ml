(*pp camlp4o pa_extend.cmo q_MLast.cmo -loc loc *)

(* Created by Martin Jambon, 2004 *)
(* No copyright, no guarantee *)

let parse_stream s = 
  let f = !Pcaml.parse_implem in
  let rec loop () =
    match f s with
	l, true -> List.map fst l @ loop ()
      | l, false -> List.map fst l in
  loop ()

let parse_file file =
  let ic = open_in file in
  let stream = Stream.of_channel ic in
  let current_file = !Pcaml.input_file in
  Pcaml.input_file := file; (* it doesn't work *)
  let l = parse_stream stream in
  close_in ic;
  Pcaml.input_file := current_file;
  l

EXTEND
  Pcaml.str_item: [
    [ "USE"; file = STRING -> 
	let l = parse_file file in
	<:str_item< declare $list:l$ end >> ]
  ];
END
