open Printf

let read_chan f ic =
  try
    while true do
      f (input_char ic)
    done
  with End_of_file -> ()

let string_of_file file =
  let ic = open_in_bin file in
  let b = Buffer.create 1024 in
  read_chan (Buffer.add_char b) ic;
  close_in ic;
  Buffer.contents b

let html_verbatim file =
  let ic = open_in_bin file in
  let b = Buffer.create 1024 in
  bprintf b "<pre>\n";
  read_chan 
    (function
	 '<' -> bprintf b "&lt;"
       | '>' -> bprintf b "&gt;"
       | '&' -> bprintf b "&amp;"
       | c -> Buffer.add_char b c)
    ic;
  bprintf b "</pre>\n";
  close_in ic;
  Buffer.contents b

let string_of_tpl_file l file =
  let s = string_of_file file in
  let b = Buffer.create 1024 in
  let h = Hashtbl.create 20 in
  List.iter (fun (ident, s) -> Hashtbl.add h ident s) l;
  let assoc ident =
    try Hashtbl.find h ident
    with Not_found -> "$" ^ ident in
  Buffer.add_substitute b assoc s;
  Buffer.contents b


let command s =
  if Sys.command s = 0 then ()
  else invalid_arg ("command: " ^ s)

let camlremix file = command ("camlremix " ^ file)

let read_command_output f s =
  let ic = Unix.open_process_in s in
  (try
     while true do
       f (input_char ic)
     done
   with End_of_file -> ());
  match Unix.close_process_in ic with
      Unix.WEXITED 0 -> ()
    | _ -> invalid_arg ("read_command_output: " ^ s)

let string_of_process s =
  let buf = Buffer.create 100 in
  read_command_output (Buffer.add_char buf) s;
  Buffer.contents buf
