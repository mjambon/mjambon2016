  type str = int * int * string
  type text = [ `str of str | `codetop of code | `codestr of code ] list
  and code = [ `str of str | `escstr of embstr ] list
  and embstr = [ `str of str | `esccode of code ] list
