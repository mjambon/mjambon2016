let extra_args = ref ([]  : string list)
(** all arguments which are not valid options for ocamlscript 
  but are not arguments of the script either go here. 
  Typically, unix.cmxa in 
    #!/usr/bin/ocamlscript unix.cmxa
  It is the responsibility of the "compile" function to handle these
  arguments. The default "compile" command (Ocamlscript.Ocamlopt.compile)
  simply passes these arguments to ocamlopt. 
*)

let trash = ref ([]  : string list)
(** runtime trash which may contain the name of the executable itself, 
  for self-removal, in case it is a temporary file (e.g. generated from
  standard input). *)

let verbose = ref false
(** prints some info to stdout *)

let compile : (string -> string -> int) ref = 
  ref (fun source result -> failwith "Compile.compile is unset")
(** the function which is used to compile the program.
  [compile source result] reads the source code from file [source] and
  writes the executable to file [result]. This function
  should return 0 if it succeeds, and 1 or another code otherwise.
*)
