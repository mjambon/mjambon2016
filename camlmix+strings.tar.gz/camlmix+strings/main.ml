open Printf
open Arg

let sources = ref []
let parse_only = ref false
let ocaml = ref "ocaml"
let stdout_file = ref None

let options = [
  "-c",
  Set parse_only,
  " only generate .ml file";
  
  "-e",
  Set_string ocaml,
  "<ocaml>  specify ocaml executable";

  "-o",
  String (fun s -> stdout_file := Some s),
  "<file>  specify an output file"
]

let add_source s = sources := s :: !sources

let usage_msg = "Usage: camlmix [options] file1 file2 ..."

let process_file in_file out_file =
  let ic = open_in_bin in_file in
  Lexer.init ();
  let lexbuf = Lexing.from_channel ic in
  let list = Lexer.text lexbuf in

  let oc = open_out_bin out_file in
  List.iter 
    (function
	 `Text s -> 
	   fprintf oc "let _ =\n  print_string %S;\n  flush stdout;;\n" s
       | `Code s ->
	   fprintf oc "%s\n" s
       | `Codeprint s ->
	   fprintf oc "let _ =\n  print_string (%s);\n  flush stdout;;\n" s
       | `Location (line, char) ->
	   fprintf oc "# %i %S\n%s" line in_file (String.make (char - 1) ' '))
    list;
  close_out oc


let exec_ocaml files =
  let buf = Buffer.create 1000 in
  let exec file =
    let ic = Unix.open_process_in (sprintf "%s %s" !ocaml file) in
    try
      while true do
	Buffer.add_char buf (input_char ic)
      done
    with End_of_file ->
      (match Unix.close_process_in ic with
	   Unix.WEXITED 0 -> ()
	 | Unix.WEXITED n -> exit n
	 | _ -> exit 2) in
  List.iter exec files;
  match !stdout_file with
      None -> Buffer.output_buffer stdout buf
    | Some file -> 
	let oc = open_out_bin file in
	Buffer.output_buffer oc buf;
	close_out oc

let _ =
  parse options add_source usage_msg;
  let in_files = !sources in
  let out_files = List.map (fun file -> file ^ ".ml") in_files in
  List.iter2 process_file in_files out_files;
  if !parse_only then
    exit 0
  else
    exec_ocaml out_files
