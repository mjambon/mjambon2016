open Printf

let read_chan f ic =
  try
    while true do
      f (input_char ic)
    done
  with End_of_file -> ()

let html_include file =
  let ic = open_in_bin file in
  let b = Buffer.create 1024 in
  read_chan (Buffer.add_char b) ic;
  close_in ic;
  Buffer.contents b

let html_verbatim file =
  let ic = open_in_bin file in
  let b = Buffer.create 1024 in
  bprintf b "<pre>\n";
  read_chan 
    (function
	 '<' -> bprintf b "&lt;"
       | '>' -> bprintf b "&gt;"
       | '&' -> bprintf b "&amp;"
       | c -> Buffer.add_char b c)
    ic;
  bprintf b "</pre>\n";
  close_in ic;
  Buffer.contents b

let author = "Martin"
