module Text =
struct

exception Internal_exit

let iter_lines_of_channel f ic =
  try
    while true do
      let line =
	try input_line ic
	with End_of_file -> raise Internal_exit in
      f line
    done
  with Internal_exit -> ()


let iter_lines_of_file f file =
  let ic = open_in file in
  try 
    iter_lines_of_channel f ic;
    close_in ic
  with exn ->
    close_in_noerr ic;
    raise exn


let lines_of_channel ic =
  let l = ref [] in
  iter_lines_of_channel (fun line -> l := line :: !l) ic;
  List.rev !l

let lines_of_file file =
  let l = ref [] in
  iter_lines_of_file (fun line -> l := line :: !l) file;
  List.rev !l

let channel_contents ic =
  let len = 2048 in
  let buf = String.create len in
  let rec loop size accu =
    match input ic buf 0 len with
	0 -> (accu, size)
      | n when n = len -> loop (size + n) (String.copy buf :: accu)
      | n -> loop (size + n) (String.sub buf 0 n :: accu) in

  let accu, size = loop 0 [] in
  let result = String.create size in
  let rec loop2 last_pos = function
      [] -> assert (last_pos = 0)
    | s :: rest ->
	let len = String.length s in
	let pos = last_pos - len in
	String.blit s 0 result pos len;
	loop2 pos rest in
  loop2 size accu;
  result


let file_contents ?(bin = false) file =
  let ic = open_in file in
  let s = 
    try channel_contents ic
    with exn ->
      close_in_noerr ic; 
      raise exn in
  close_in ic;
  s

let save file data =
  let oc = open_out_bin file in
  (try
     output_string oc data;
   with exn -> 
     close_out_noerr oc;
     raise exn);
  close_out oc

let save_lines file lines =
  let oc = open_out_bin file in
  (try
     List.iter (fun s -> output_string oc s; output_char oc '\n') lines;
   with exn -> 
     close_out_noerr oc;
     raise exn);
  close_out oc


exception Skip

let rev_map f l =
  let rec loop f accu = function
      [] -> accu
    | hd :: tl -> 
	let accu' = 
	  try f hd :: accu
	  with Skip -> accu in
	loop f accu' tl in
  loop f [] l

let map f l =
  List.rev (rev_map f l)

let rec fold_left f accu l =
  match l with
      [] -> accu
    | hd :: tl -> 
	let accu' = 
	  try f accu hd
	  with Skip -> accu in
	fold_left f accu' tl

let rec rev_fold_right f l accu =
  match l with
      [] -> accu
    | hd :: tl -> 
	let accu' = 
	  try f hd accu
	  with Skip -> accu in
	rev_fold_right f tl accu'

let rec fold_right f l accu = 
  rev_fold_right f (List.rev l) accu

let map_lines_of_channel f ic =
  let l = ref [] in
  iter_lines_of_channel (fun line -> 
			   try l := f line :: !l
			   with Skip -> ()) ic;
  List.rev !l

let map_lines_of_file f file =
  let l = ref [] in
  iter_lines_of_file (fun line ->
			try l := f line :: !l
			with Skip -> ()) file;
  List.rev !l

end

module Fixed =
struct

let chop_spaces str =
  let len = String.length str in
  let rec getfirst n =
    if n = len then len
    else
      if String.unsafe_get str n = ' '
      then getfirst (n+1)
      else n
  and getlast n =
    if String.unsafe_get str n = ' '
    then getlast (n-1)
    else n in
  let first = getfirst 0 in
  if first = len then ""
  else 
    let last = getlast (len - 1) in
    String.sub str first (last-first+1)

let int s = int_of_string (chop_spaces s)
let float s = float_of_string (chop_spaces s)

end

module Directory =
struct

let list ?(absolute = false) ?path dir =
  let names =  Sys.readdir dir in
  Array.sort String.compare names;

  let make_path, path_maker =
    match absolute, path with
	false, None 
      | false, Some false -> false, (fun s -> s)
      |	false, Some true -> true, Filename.concat dir
      | true, Some true 
      | true, None -> 
	  let f =
	    if Filename.is_relative dir then
	      let cwd = Sys.getcwd () in
	      Filename.concat (Filename.concat cwd dir)
	    else Filename.concat dir in
	  true, f
      | true, Some false -> invalid_arg "Directory.list" in

  let paths = 
    if make_path then Array.map path_maker names
    else names in
  Array.to_list paths

end
