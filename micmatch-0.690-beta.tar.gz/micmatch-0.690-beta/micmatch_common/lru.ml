type ('a, 'b) node =
    { mutable prev : ('a, 'b) delist;
      mutable next : ('a, 'b) delist;
      key : 'a;
      mutable data : 'b }

and ('a, 'b) delist = ('a, 'b) node option

let remove_node node =
  match node.prev, node.next with
      None, None -> None
    | None, (Some next as n) -> 
	next.prev <- None;
	n
    | (Some prev as p), None ->
	prev.next <- None;
	p
    | (Some prev as p), (Some next as n) -> 
	prev.next <- n;
	next.prev <- p;
	p

let add_node l key data =
  match l with
      Some node -> 
	assert (node.prev = None);
	let l' = Some { prev = None;
			next = l;
			key = key;
			data = data } in
	node.prev <- l';
	l'
    | None ->
	Some { prev = None;
	       next = None;
	       key = key;
	       data = data }

let get_some = function 
    Some node -> node
  | None -> invalid_arg "get_some"

type ('a, 'b) cache = { max_size : int;
			mutable size : int;
			mutable youngest : ('a, 'b) delist;
			mutable oldest : ('a, 'b) delist;
			tbl : ('a, ('a, 'b) node) Hashtbl.t }

let create max_size =
  if max_size < 0 then
    invalid_arg "Lru.create";
  { max_size = max_size;
    size = 0;
    youngest = None;
    oldest = None;
    tbl = Hashtbl.create (2 * max_size) }

let get_node cache key =
  let tbl = cache.tbl in
  let node = Hashtbl.find tbl key in
  let prev = node.prev in
  if prev = None then ()
  else
    (let next = node.next in
     let l = remove_node node in
     node.prev <- None;
     node.next <- cache.youngest;
     let l2 = Some node in
     (get_some cache.youngest).prev <- l2;
     cache.youngest <- l2;
     if node.next = None then (* only one element in the cache *)
       cache.oldest <- l2
     else if next = None then (* we moved the last element *)
       cache.oldest <- prev);
  node


let get cache key = (get_node cache key).data


let force_add cache key data =
  match cache.youngest with
      None -> 
	let l = add_node None key data in
	cache.youngest <- l;
	cache.oldest <- l;
	Hashtbl.add cache.tbl key (get_some l);
	cache.size <- cache.size + 1;
    | Some _ ->
	let tbl = cache.tbl in
	try
	  let node = get_node cache key in
	  node.data <- data
	with Not_found ->
	  let l = add_node cache.youngest key data in
	  cache.youngest <- l;
	  Hashtbl.add tbl key (get_some l);
	  cache.size <- cache.size + 1

let add cache key data =
  let max_size = cache.max_size in
  if cache.size < max_size then
    force_add cache key data
  else
    let oldest = cache.oldest in
    match oldest with
	None -> ()
      | Some oldest_node ->
	  let oldest_key = oldest_node.key in
	  force_add cache key data;
	  if cache.size = max_size then ()
	  else 
	    let l = remove_node oldest_node in
	    cache.oldest <- l;
	    Hashtbl.remove cache.tbl oldest_key;
	    cache.size <- cache.size - 1

let iter_left f cache =
  let rec iter = function
      None -> ()
    | Some node -> 
	f node.key node.data;
	iter node.next in
  iter cache.youngest

let iter_right f cache =
  let rec iter = function
      None -> ()
    | Some node -> 
	f node.key node.data;
	iter node.prev in
  iter cache.oldest


open Printf
let print cache =
  iter_left (fun i j -> printf "%i %i, " i j) cache;
  printf "\n";
  iter_right (fun i j -> printf "%i %i, " i j) cache;
  printf "\n"

let cache = create 3;;
print cache;;
List.iter 
  (fun key -> 
     add cache key key;
     printf "adding %i\n" key;
     print cache)
  [1;2;3;4;5;6];;
get cache 4;;
print cache;;
get cache 6;;
print cache;;
add cache 7 7;;
print cache;;
get cache 5;; (* Not_found *)
print cache;;
