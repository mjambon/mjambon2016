open Language.Types
open Shortcuts
open Lib

let ant = [
  "start", l_switch [ (move, f2 turn_left);
		      (move, f2 turn_right); 
		      (move, flip 2) ] "start" "end";
  "end", Continue
]
