open Printf

open Simulator

let translate_cell c =
  match c with
    '#' -> RockyCell
  | '.' -> ClearCell
  | '+' -> RedHomeCell
  | '-' -> BlackHomeCell
  | '1'..'9' -> FoodCell (Char.code c - Char.code '0')
  | _ -> invalid_arg "translate_cell"

let create_ant (ants, p) last_id  (c : color) =
  let id = incr last_id; !last_id in
  Hashtbl.add ants id p;
  { id = id;
    color = c;
    state = 0;
    resting = 0;
    direction = 0;
    has_food = false }

let create_cell ants_pos last_id total_food cell_type =
  let ant, food = 
    match cell_type with
	RedHomeCell -> Some (create_ant ants_pos last_id Red), 0
      | BlackHomeCell -> Some (create_ant ants_pos last_id Black), 0
      | RockyCell | ClearCell -> None, 0
      | FoodCell i -> 
	  total_food := !total_food + i;
	  None, i in

  { cell_type = cell_type;
    cell_contents = { cell_ant = ant;
		      cell_food = food;
		      cell_red_marker = Array.make 6 0;
		      cell_black_marker = Array.make 6 0 } }


let input_this c ic =
  if input_char ic <> c then 
    failwith ("expected char " ^ String.make 1 c)
  else ()

let input_space = input_this ' '

let input file =
  let ic = open_in file in
  let width = int_of_string (input_line ic) in
  let height = int_of_string (input_line ic) in
  let world = Array.make height [| |] in
  let last_id = ref (-1) in
  let total_food = ref 0 in
  let ants = Hashtbl.create 100 in

  for i = 0 to height - 1 do
    if i mod 2 = 1 then input_space ic;
    world.(i) <- Array.init width
      (fun j ->
	 let c = translate_cell (input_char ic) in
	 let cell = create_cell (ants, (j,i)) last_id total_food c in
	 if j < width - 1 then input_space ic;
	 cell);
    ignore (input_line ic);
  done;
  close_in ic;
  (world, ants, !last_id, !total_food)

let cint i = char_of_int (i + int_of_char '0')

let std_cell cell =
  match cell.cell_type with
      RockyCell -> '#'
    | ClearCell -> '.'
    | RedHomeCell -> '+'
    | BlackHomeCell -> '-'
    | FoodCell i -> cint i

let ( !* ) cell = cell.cell_type
let ( !$ ) cell = cell.cell_contents

let markers012 f cell =
  match !*cell with
      RockyCell -> '#'
    | _ ->
	let m = f !$cell in
	let n = 2 * ((2 * m.(0)) + m.(1)) + m.(2) in
	if n > 0 then cint n
	else ' '

exception Found of int
let markers f cell =
  match !*cell with
      RockyCell -> '#'
    | _ ->
	let m = f !$cell in
	try
	  Array.iteri (fun i b -> if b = 1 then raise (Found i)) m;
	  ' '
	with Found i -> cint i
	 

let red_markers012 = markers012 (fun c -> c.cell_red_marker)
let black_markers012 = markers012 (fun c -> c.cell_black_marker)

let red_markers = markers (fun c -> c.cell_red_marker)
let black_markers = markers (fun c -> c.cell_black_marker)

let food cell =
  match !*cell with
      RockyCell -> '#'
    | _ ->
	let food = !$cell.cell_food in
	if food = 0 then ' '
	else if food <= 9 then cint food
	else '*'
	
let ants cell =
  if !*cell = RockyCell then '#'
  else
    match !$cell.cell_ant with
	None -> ' '
      | Some a ->
	  match a.color with
	      Red -> '+'
	    | Black -> '-'
      

let default_maps =
  (".copy", None) ::
    List.map (fun (s, x) -> (s, Some x)) 
    [ ".mred", red_markers;
      ".mblack", black_markers;
      ".mred012", red_markers012;
      ".mblack012", black_markers012;
      ".food", food;
      ".ants", ants ]
    

let output ?(f = std_cell) oc world =
  let height = Array.length world in
  let width = Array.length world.(0) in
  fprintf oc "%i\n" width;
  fprintf oc "%i\n" height;
  for i = 0 to height - 1 do
    if i mod 2 = 1 then
      output_char oc ' ';
    for j = 0 to width - 1 do
      output_char oc (f world.(i).(j));
      output_char oc ' ';
    done;
    output_char oc '\n'
  done

let export ?(maps = default_maps) prefix world =
  List.iter
    (fun (suf, f) ->
       let oc = open_out (prefix ^ suf) in
       output ?f oc world;
       close_out oc)
    maps
