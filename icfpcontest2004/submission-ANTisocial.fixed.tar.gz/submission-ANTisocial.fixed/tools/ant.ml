open Language.Types
open Shortcuts
open Lib

let find_next_mark n = [
  "sense-marker", sense Ahead return "sense-left" (Marker n);
  "sense-left", sense LeftAhead "turn-left" "sense-right" (Marker n);
  "sense-right", sense RightAhead "turn-right" fail (Marker n);
  "turn-left", turn Left return;
  "turn-right", turn Right return;
]

let move_to_next_mark n = [
  "find", sub (find_next_mark n) "move" fail;
  "move", move return fail;
]

let food_follow = [
  "find-next0", sub (find_next_mark 0) "find-next1" fail;
  "find-next1", sub (find_next_mark 1) "find-next2" fail;
  "find-next2", sub (find_next_mark 2) "find-next0" fail;
]

let home_follow = [
  "find-next3", sub (find_next_mark 3) "find-next4" fail;
  "find-next4", sub (find_next_mark 4) "find-next5" fail;
  "find-next5", sub (find_next_mark 5) "find-next3" fail;
]

let clear_next_mark n = [
  "move", sub (find_next_mark n) "clear" fail;
  "clear", unmark n return;
]

let clear_food = [
  "find-next0", sub (clear_next_mark 0) "find-next2" fail;
  "find-next2", sub (clear_next_mark 2) "find-next1" fail;
  "find-next1", sub (clear_next_mark 1) "find-next0" fail;
]

let clear_home = [
  "find-next3", sub (find_next_mark 3) "find-next5" fail;
  "find-next5", sub (find_next_mark 5) "find-next4" fail;
  "find-next4", sub (find_next_mark 4) "find-next3" fail;
]



let random_walk = [
  "choose-dir", flip 3 "turn-left" "choose-again";
  "choose-again", flip 2 "turn-right" "move";
  "turn-left", turn Left "move";
  "turn-right", turn Right "move";
  "move", move return fail;
]




let wait n =
  if n <= 0 then invalid_arg "wait"
  else [
    "do-nothing", flip n return "do-nothing"
]

let around_friend = [
  "sense-right", sense RightAhead "wait" "sense-right-empty" Foe;
  "sense-right-empty", sub (go_if_empty RightAhead) return "turn-retry";
  "turn-retry", turn Right "maybe-sense-free";
  "maybe-sense-free", flip 6 fail "sense-right-empty";
  "wait", sub (wait 2) "sense-right" fail;
]

let around_foe = [
  "sense-right", sub (go_if_empty RightAhead) return "sense-left";
  "sense-left", sub (go_if_empty LeftAhead) return "turn-retry";
  "turn-retry", flip 2 "retry-left" "retry-right";
  "retry-left", turn Left "go-if-empty";
  "retry-right", turn Right "go-if-empty";
  "go-if-empty", sub (go_if_empty Ahead) return fail;
]

let soft_obstacle = [
  "sense-foe", sense Ahead "around-foe" "sense-friend" Foe;
  "sense-friend", sense Ahead "around-friend" fail Friend;
  "around-foe", sub around_foe return fail;
  "around-friend", sub around_friend return fail;
]

let food_explore_n n = 
  if n < 0 || n > 2 then invalid_arg "food_explore"
  else [
    "sense-food", pickup "mark-return" "sense-ahead";
    "sense-ahead", sense Ahead "move" "sense-left" Food;
    "sense-left", sense LeftAhead "turn-left" "sense-right" Food;
    "sense-right", sense RightAhead "turn-right" "food-follow" Food;
    "food-follow", sub food_follow "mark-return" "mark-fail";
    "turn-left", turn Left "move";
    "turn-right", turn Right "move";
    "move", move "mark-return" "think";
    "mark-return", mark n return;
    "mark-fail", mark n fail;
    "think", sub soft_obstacle return fail;
]

let home_explore_n n = 
  if n < 3 || n > 5 then invalid_arg "home_explore"
  else [
    "sense-home", sense Here "drop" "sense-ahead" Home;
    "drop", drop "mark-return";
    "sense-ahead", sense Ahead "move" "sense-left" Home;
    "sense-left", sense LeftAhead "turn-left" "sense-right" Home;
    "sense-right", sense RightAhead "turn-right" "home-follow" Home;
    "home-follow", sub home_follow "mark-return" "mark-fail";
    "turn-left", turn Left "move";
    "turn-right", turn Right "move";
    "move", move "mark-return" "think";
    "mark-return", mark n return;
    "mark-fail", mark n fail;
    "think", sub soft_obstacle return fail;
]


let food_explore = [
  "explore0", sub (food_explore_n 0) return "explore1";
  "explore1", sub (food_explore_n 1) return "explore2";
  "explore2", sub (food_explore_n 2) return "explore0";
]

let home_explore = [
  "explore3", sub (home_explore_n 3) return "explore4";
  "explore4", sub (home_explore_n 4) return "explore5";
  "explore5", sub (home_explore_n 5) return "explore3";
]



let ant = [
  "food-explore", sub food_explore "home-explore" "random";
  "food-follow", sub food_follow "home-explore" "clear-food";
  "home-explore", sub home_explore "food-explore" "random";
  "home-follow", sub home_follow "food-explore" "clear-home";
  "random", sub random_walk "food-explore" "random";
  "clear-food", sub clear_food "food-explore" "food-explore";
  "clear-home", sub clear_home "food-explore" "food-explore";
]
