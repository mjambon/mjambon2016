open Language.Types
open Shortcuts
open Lib

let step = 
  l_while (l_not go_where_you_can) (dup turn_right)

let miam = 
  l_and [test_food; l_not test_home]
  
let ant = [
  "search-food", ign step "test-food";
  "test-food", miam "load-and-back" "search-food";
  "load-and-back", ign pickup "search-home";
  "search-home", ign step "test-home";
  "test-home", test_home "drop-and-go" "search-home";
  "drop-and-go", drop "search-food";
]
