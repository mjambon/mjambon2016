module Types =
struct
  type sense_dir = 
      Here   (* sense the ant's current cell *)
    | Ahead  (* sense the cell straight ahead in the direction ant is facing *)
    | LeftAhead  (* sense the cell that would be ahead if ant turned left *)
    | RightAhead (* sense the cell that would be ahead if ant turned right *)
	
  type marker = int

  type condition =
      Friend        (* cell contains an ant of the same color *)
    | Foe           (* cell contains an ant of the other color *)
    | FriendWithFood (* cell contains an ant of the same color carrying food *)
    | FoeWithFood   (* cell contains an ant of the other color carrying food *)
    | Food          (* cell contains food (not being carried by an ant) *)
    | Rock          (* cell is rocky *)
    | Marker of marker (* cell is marked with a marker of this ant's color *)
    | FoeMarker     (* cell is marked with *some* marker of the other color *)
    | Home          (* cell belongs to this ant's anthill *)
    | FoeHome       (* cell belongs to the other anthill *)
	
  type left_or_right = Left | Right
     
  type 'a instruction =
      Sense of sense_dir * 'a * 'a * condition  
    | Mark of int * 'a
    | Unmark of int * 'a
    | PickUp of 'a * 'a
    | Drop of 'a
    | Turn of left_or_right * 'a
    | Move of 'a * 'a
    | Flip of int * 'a * 'a
	
	
  type 'a instr = 
      Instr of 'a instruction
    | Goto of 'a
    | Continue
    | Return
    | Fail 
    | Subtask of 'a ant_states * 'a * 'a
	
  and 'a ant_states = ('a * 'a instr) list

  type state = int
  type machine = (state instruction * string) array
end

open Types
      
let goto st = Flip (1, st, st)

let subst_instr subst = function
    Sense (sense_dir, st1, st2, condition) -> 
      Sense (sense_dir, subst st1, subst st2, condition)
  | Mark (marker, st) -> Mark (marker, subst st)
  | Unmark (marker, st) -> Unmark (marker, subst st)
  | PickUp (st1, st2) -> PickUp (subst st1, subst st2)
  | Drop st -> Drop (subst st)
  | Turn (left_or_right, st) -> Turn (left_or_right, subst st)
  | Move (st1, st2) -> Move (subst st1, subst st2)
  | Flip (p, st1, st2) -> Flip (p, subst st1, subst st2)

let print s = print_string s; print_newline ()

let make_machine to_string l =
  let a = Array.of_list l in
  Array.mapi 
    (fun i (id, st, instr) -> 
       if i <> id then failwith "state id mismatch"
       else (instr, to_string st))
    a
  

let compute_ant ?comment ~return_state ~fail_state ant = 
  let string = match comment with None -> (fun x -> "??") | Some f -> f in
  let last = ref (-1) in
  let instr_tbl = Hashtbl.create 100 in

  let rec simplify subst current_id = function
      Instr instr -> subst_instr subst instr
    | Goto st -> goto (subst st)
    | Continue -> goto current_id
    | Return -> assert false
    | Fail -> assert false
    | Subtask ([], _, _) -> failwith "empty subtask"
    | Subtask (sub_ant, st1, st2) -> 
	match sub ~return: (subst st1, subst st2) sub_ant with
	    (id, _, _) :: _ -> goto id
	  | _ -> assert false
	  
  and sub ?return sub_ant =
    let sub_ant' = 
      List.map (function 
		    (x, Return) -> (x, Goto return_state)
		  | (x, Fail) -> (x, Goto fail_state)
		  | y -> y)
	sub_ant in
    let st_tbl = Hashtbl.create 100 in
    let id_tbl = Hashtbl.create 100 in
    (match return with
	 None -> ()
       | Some (id1, id2) ->
	   Hashtbl.add st_tbl return_state id1;
	   Hashtbl.add st_tbl fail_state id2);
    List.iter 
      (fun (st, instr) -> 
	 if Hashtbl.mem st_tbl st then
	   failwith ("redefinition of state " ^ string st)
	 else
	   let id = incr last; !last in
	   Hashtbl.add st_tbl st id;
	   Hashtbl.add id_tbl id (st, instr))
      sub_ant';

    let subst st =
      try Hashtbl.find st_tbl st
      with Not_found -> failwith ("unknown state " ^ string st) in
    let l = 
      Hashtbl.fold 
	(fun id (st, instr) accu ->
	   (id, st, simplify subst id instr) :: accu) id_tbl [] in
    
    let toplevel =
      List.sort (fun (a, _, _) (b, _, _) -> compare a b) l in
    List.iter (fun (id, st, instr) -> Hashtbl.add instr_tbl id (st, instr))
      toplevel;
    toplevel in

  let toplevel = sub ant in
  let l = 
    Hashtbl.fold 
      (fun id (st, instr) accu -> (id, st, instr) :: accu) instr_tbl [] in

  let result_list =
    List.sort (fun (a, _, _) (b, _, _) -> compare a b) l in

  make_machine string result_list
