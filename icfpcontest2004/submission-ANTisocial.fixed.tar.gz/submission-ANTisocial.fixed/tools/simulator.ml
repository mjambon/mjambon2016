open Printf
let print s = print_string s; flush stdout

open Language.Types


type pos = int * int
type dir = int

type color = Red | Black

type ant = {
  id : int;
  color : color;
  mutable state : int;
  mutable resting : int;
  mutable direction : dir;
  mutable has_food : bool;
}

type cell_type =
    RockyCell        (* #        rocky cell *)
  | ClearCell        (* .        clear cell (containing nothing interesting) *)
  | RedHomeCell      (* +        red anthill cell *)
  | BlackHomeCell    (* -        black anthill cell *)
  | FoodCell of int  (* 1 to 9   clear cell containing the given number of 
			food particles *)

type bit = int

type cell_contents = {
  mutable cell_ant : ant option;
  mutable cell_food : int;
  mutable cell_red_marker : bit array;
  mutable cell_black_marker : bit array;
}

type cell = {
  cell_type : cell_type;
  cell_contents : cell_contents;
}

type world = cell array array


module type Environment =
sig
  val world : world
  val red_machine : machine
  val black_machine : machine
  val ants : (int, pos) Hashtbl.t
  val max_id : int
  val initial_food : int
  val fast_random : bool
end

module Make (Env : Environment) =
struct
  open Env

  let height = Array.length world
  let width = Array.length world.(0)

  let red_stats = Array.map (fun (instr, comment) -> 0) red_machine
  let black_stats = Array.map (fun (instr, comment) -> 0) black_machine

  let red_food = ref 0
  let black_food = ref 0

  let cell (x, y) = world.(y).(x)
  let cell_type p = (cell p).cell_type
  let cell_contents p = (cell p).cell_contents

  let bit_bool = function true -> 1 | false -> 0
  let bool_bit = function 1 -> true | 0 -> false | _ -> invalid_arg "bool_bit"

  (* Geometry *)

  let bad_dir d = failwith ("invalid direction " ^ (string_of_int d))
  let check_dir d = if d < 0 || d > 5 then bad_dir d

  let even i = i mod 2 = 0

  let adjacent_cell (p : pos) (d : dir) : pos = 
    let (x,y) = p in
    match d with
      | 0 -> (x+1, y)
      | 1 -> if even y then (x, y+1) else (x+1, y+1)
      | 2 -> if even y then (x-1, y+1) else (x, y+1)
      | 3 -> (x-1, y)
      | 4 -> if even y then (x-1, y-1) else (x, y-1)
      | 5 -> if even y then (x, y-1) else (x+1, y-1)
      | _ -> bad_dir d

  let turn (lr : left_or_right) (d : dir) : dir = 
    match lr with
      | Left ->  (d+5) mod 6
      | Right -> (d+1) mod 6

  let sensed_cell (p : pos) (d : dir) (sd : sense_dir) : pos = 
    match sd with
      | Here -> p
      | Ahead -> adjacent_cell p d
      | LeftAhead -> adjacent_cell p (turn Left d)
      | RightAhead -> adjacent_cell p (turn Right d)


  (* Biology *)

  let other_color (c : color) : color = 
    match c with
      | Red -> Black
      | Black -> Red

  let state (a : ant) : int     = a.state
  let color (a : ant) : color   = a.color
  let resting (a : ant) : int   = a.resting
  let direction (a : ant) : dir = a.direction
  let has_food (a : ant) : bool = a.has_food

  let set_state (a : ant) (s : int)     = a.state <- s
  let set_resting (a : ant) (r : int)   = a.resting <- r
  let set_direction (a : ant) (d : dir) = a.direction <- d
  let set_has_food (a : ant) (b : bool) = a.has_food <- b


  (* Geography *)

  let rocky (p : pos) : bool =
    (cell_type p) = RockyCell

  let some_ant_is_at (p : pos) : bool = 
    (cell_contents p).cell_ant <> None

  let ant_at (p : pos) : ant =
    match (cell_contents p).cell_ant with
	None -> invalid_arg (sprintf "ant_at (%i, %i)" (fst p) (snd p))
      | Some a -> a

  let set_ant_at (p : pos) (a : ant) =
    assert (not (some_ant_is_at p));
    (cell_contents p).cell_ant <- Some a;
    assert (not (Hashtbl.mem ants a.id));
    Hashtbl.add ants a.id p

  let clear_ant_at (p : pos) =
    Hashtbl.remove ants (ant_at p).id;
    (cell_contents p).cell_ant <- None

  let ant_is_alive (id : int) : bool =
    Hashtbl.mem ants id

  let find_ant (id : int) : pos =
    try Hashtbl.find ants id
    with Not_found -> failwith ("no such ant " ^ string_of_int id)

  let kill_ant_at (p : pos) = clear_ant_at p

  let food_at (p : pos) : int =
    (cell_contents p).cell_food

  let set_food_at (p : pos) (f : int) =
    (cell_contents p).cell_food <- f

  let anthill_at (p : pos) (c : color) : bool =
    match cell_type p, c with
	RedHomeCell, Red | BlackHomeCell, Black -> true
      | _ -> false

  let update_home_food p n =
    match cell_type p with
	RedHomeCell -> red_food := !red_food + n
      | BlackHomeCell -> black_food := !black_food + n
      | _ -> ()
		
  (* Cartography *)


  (* Chemistry *)

  let markers (p : pos) (c : color) =
    match c with
	Red -> (cell_contents p).cell_red_marker
      | Black -> (cell_contents p).cell_black_marker

  let set_marker_at (p : pos) (c : color) (i : marker) =
    (markers p c).(i) <- bit_bool true

  let clear_marker_at (p : pos) (c : color) (i : marker) =
    (markers p c).(i) <- bit_bool false

  let check_marker_at (p : pos) (c : color) (i : marker) : bool =
    (markers p c).(i) = bit_bool true

  let check_any_marker_at (p : pos) (c : color) : bool =
    Array.fold_left (fun accu bit -> accu || bool_bit bit) false (markers p c)


  (* Phenomenology *)

  let cell_matches (p : pos) (cond : condition) (c : color) : bool = 
    if rocky p then 
      if cond = Rock then true else false
    else
      match cond with
	| Friend -> 
            some_ant_is_at p &&
            color (ant_at p) = c
	| Foe -> 
            some_ant_is_at p &&
            color (ant_at p) <> c
	| FriendWithFood ->
            some_ant_is_at p &&
            color (ant_at p) = c &&
			       has_food (ant_at p)
	| FoeWithFood -> 
            some_ant_is_at p &&
            color (ant_at p) <> c &&
            has_food (ant_at p)
	| Food -> 
            food_at p > 0
	| Rock ->
            false
	| Marker i ->
            check_marker_at p c i
	| FoeMarker ->
            check_any_marker_at p (other_color c)
	| Home ->
            anthill_at p c
	| FoeHome ->
            anthill_at p (other_color c)


  (* Neurology *)

  let get_instruction (c : color) (s : state) : state instruction =
    let machine, stats =
      match c with
	  Red -> red_machine, red_stats
	| Black -> black_machine, black_stats in
    stats.(s) <- stats.(s) + 1;
    fst machine.(s)


  (* Neuro-Cartography *)



  (* Martial Arts *)

  let adjacent_ants (p : pos) (c : color) : int =
    let n = ref 0 in
    for d = 0 to 5 do
      let cel = adjacent_cell p d in
      if some_ant_is_at cel && color (ant_at cel) = c then incr n
    done;
    !n

  let check_for_surrounded_ant_at (p : pos) =
    if some_ant_is_at p then 
      let a = ant_at p in
      if adjacent_ants p (other_color (color a)) >= 5 then begin
	kill_ant_at p;
	set_food_at p (food_at p + 3 + (if has_food a then 1 else 0));
	update_home_food p 3;
      end

  let check_for_surrounded_ants (p : pos) =
    check_for_surrounded_ant_at p;
    for d = 0 to 5 do
      check_for_surrounded_ant_at (adjacent_cell p d)
    done


  (* Number Theory *)

  module RNG = 
  struct
    open Big_int
    let big = big_int_of_int
    let int = int_of_big_int
    let k1 = big 22695477
    and k2 = big 65536
    and k3 = big 16384
    and big1 = big 1
    let ( + ) = add_big_int
    and ( / ) = div_big_int
    and ( * ) = mult_big_int
    and ( mod ) = mod_big_int
    let si si_m1 = (si_m1 * k1) + big1
    let xi si_p4 = (si_p4 / k2) mod k3
    let random_init s0 =
      let s = ref (si (si (si (big s0)))) in
      let random = 
	fun () ->
	  s := si !s;
	  xi !s in
      let srandom () = string_of_big_int (random ()) in
      let randomint n =
	int (mod_big_int (random ()) (big n)) in
      (random, srandom, randomint)
  end

  let random_seed = 12345
  let (random, srandom, official_randomint) = RNG.random_init random_seed

  let randomint = 
    if fast_random then Random.int (* This makes the program 1200 times 
				      faster! *)
    else official_randomint

  (* Kinetics *)

  let step (id : int) =
    if ant_is_alive id then
      let p = find_ant id in
      let a = ant_at p in
      if resting a > 0 then
	set_resting a (resting a - 1)
      else
	match get_instruction (color a) (state a) with
          | Sense (sensedir, st1, st2, cond) ->
              let p' = sensed_cell p (direction a) sensedir in
              let st = if cell_matches p' cond (color a) then st1 else st2 in
              set_state a st
          | Mark (i, st) ->
              set_marker_at p (color a) i;
              set_state a st
          | Unmark (i, st) ->
              clear_marker_at p (color a) i;
              set_state a st
          | PickUp (st1, st2) ->
              if has_food a || food_at p = 0 then 
		set_state a st2 
              else begin
		update_home_food p (-1);
		set_food_at p (food_at p - 1);
		set_has_food a true;
		set_state a st1
              end
          | Drop st ->
              if has_food a then begin
		update_home_food p 1;
		set_food_at p (food_at p + 1);
		set_has_food a false
              end;
              set_state a st
          | Turn (lr, st) -> 
              set_direction a (turn lr (direction a));
              set_state a st
          | Move (st1, st2) ->
	      let newp = adjacent_cell p (direction a) in
              if rocky newp || some_ant_is_at newp then
		set_state a st2
              else begin
		clear_ant_at p;
		set_ant_at newp a;
		set_state a st1;
		set_resting a 14;
		check_for_surrounded_ants newp
              end 
          | Flip (n, st1, st2) ->
              let st = if randomint n = 0 then st1 else st2 in
              set_state a st


  (* Game Play and Scoring *)
	
  let dump_food x =
    if x.cell_food > 0 then
      printf "%i food; " x.cell_food

  let dump_m s m =
    let l = ref [] in
      Array.iteri 
	(fun i bit -> if bool_bit bit then l := i :: !l else ())
	m;
    match !l with
	[] -> ()
      | l ->
	  printf "%s marks: " s;
	  List.iter print_int (List.rev l);
	  printf "; "

  let dump_marks x =
    dump_m "red" x.cell_red_marker;
    dump_m "black" x.cell_black_marker
	
  let dump_ant opt =
    match opt with
	None -> ()
      | Some a ->
	  printf "%s ant of id %i, dir %i, food %i, state %i, resting %i"
	    (if a.color = Red then "red" else "black")
	    a.id
	    a.direction
	    (if a.has_food then 1 else 0)
	    a.state
	    a.resting

  let dump_cell p =
    let cel = cell p in
    printf "cell (%i, %i): " (fst p) (snd p);
    let cell_type = cel.cell_type in
    if cell_type = RockyCell then printf "rock"
    else
      (let contents = cel.cell_contents in
       dump_food contents;
       
       (match cell_type with
	    RedHomeCell -> printf "red hill; "
	  | BlackHomeCell -> printf "black hill; "
	  | _ -> ());
       
       dump_marks contents;
       dump_ant contents.cell_ant);
    printf "\n"


  let dump n =
    printf "\nAfter round %i...\n" n;
    for y = 0 to height - 1 do
      for x = 0 to width - 1 do
	dump_cell (x,y)
      done
    done

  let cycle () =
    for id = 0 to max_id do
      if ant_is_alive id then
	step id
    done

  let export_stats file machine stats =
    let m = 
      Array.mapi
	(fun i (instr, comment) ->
	   (stats.(i), instr, sprintf "#%i [%i] %s" i stats.(i) comment))
	machine in
    Array.stable_sort (fun (a,_,_) (b,_,_) -> compare b a) m;
    let result = Array.map (fun (_, b, c) -> (b, c)) m in
    let suffix = ".stats" in
    Output.export_machine ~suffix file false result

  let trace oc n =
    let reds = ref 0 in
    let blacks = ref 0 in
    Hashtbl.iter
      (fun id p -> 
	 match color (ant_at p) with
	     Red -> incr reds
	   | Black -> incr blacks)
      ants;
    fprintf oc "%i: reds:%i food:%i, blacks:%i food:%i\n"
      n !reds !red_food !blacks !black_food

  let run ?dump:(b = false) ?(cycles = 100_000) () =
    let trace_oc = open_out "trace" in
    if b then (printf "random seed: %i\n" random_seed;
	       dump 0);
    fprintf trace_oc "Initial food: %i\n" initial_food;
    trace trace_oc 0;
    for i = 1 to cycles do
      cycle ();
      if b then dump i;
      trace trace_oc i;
    done;
    close_out trace_oc;
    export_stats "red" red_machine red_stats;
    export_stats "black" black_machine black_stats;
end
