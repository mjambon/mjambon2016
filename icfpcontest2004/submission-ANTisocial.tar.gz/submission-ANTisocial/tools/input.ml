open Str
open Scanf

open Language.Types
open Shortcuts

let lr = function
    "Left" -> Left
  | "Right" -> Right
  | s -> invalid_arg ("lr: " ^ s)

let dir = function
    "Here" -> Here
  | "Ahead" -> Ahead
  | "LeftAhead" -> LeftAhead
  | "RightAhead" -> RightAhead
  | s -> invalid_arg ("dir: " ^ s)

let cond = function
    "Friend" -> Friend
  | "Foe" -> Foe
  | "FriendWithFood" -> FriendWithFood
  | "FoeWithFood" -> FoeWithFood
  | "Food" -> Food
  | "Rock" -> Rock
  | "FoeMarker" -> FoeMarker
  | "Home" -> Home
  | "FoeHome" -> FoeHome
  | s -> invalid_arg ("cond: " ^ s)

let sense_marker_re =
  regexp "Sense [A-Za-z]+ [0-9]+ [0-9]+ Marker \\([0-5]\\)"

let marker_cond opt s =
  match opt with
      None -> cond s
    | Some i -> Marker i

let sense s =
  let marker = 
    if string_match sense_marker_re s 0 then
      Some (int_of_string (matched_group 1 s))
    else None in

  sscanf s "Sense %s %i %i %s" 
    (fun a b c d -> sense (dir a) (marker_cond marker d) b c)

let mark s = sscanf s "Mark %i %i" mark
let unmark s = sscanf s "Unmark %i %i" unmark
let pickup s = sscanf s "PickUp %i %i" pickup
let drop s = sscanf s "Drop %i" drop
let turn s = sscanf s "Turn %s %i" (fun a b -> turn (lr a) b)
let move s = sscanf s "Move %i %i" move
let flip s = sscanf s "Flip %i %i %i" flip

let choices = 
  [ "Sense", sense;
    "Mark", mark;
    "Unmark", unmark;
    "PickUp", pickup; 
    "Drop", drop;
    "Turn", turn;
    "Move", move;
    "Flip", flip ]

let tests = List.map
	      (fun (s, f) -> 
		 let re = regexp s in
		 let test x = string_match re x 0 in
		 test, f)
	      choices

exception Found of int instr

let convert_line line = 
  try
    List.iter 
      (fun (test, f) -> if test line then raise (Found (f line))) tests;
    failwith ("invalid line: " ^ line)
  with Found x -> (x, "")

let read_machine file =
  let ic = open_in file in
  let l = ref [] in
  try
    while true do
      let line = input_line ic in
      l := convert_line line :: !l
    done;
    assert false
  with End_of_file ->
    close_in ic;
    Array.map (fun (instr, s) -> 
		 match instr with 
		     Instr x -> (x, s)
		   | _ -> failwith "found high level instruction")
      (Array.of_list (List.rev !l))
