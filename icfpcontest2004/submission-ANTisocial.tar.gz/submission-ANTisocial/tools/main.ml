open Shortcuts

let default1 = ("solution-1", Work.ant)
let default2 = ("solution-2", Protector.ant)
let work = ("work", Work.ant)
let protector = ("protector", Protector.ant)
let star = ("star", Star.ant)
let stupid = ("stupid", Stupid.ant)
let test = ("test", Test.ant)
let lightning = ("lightning", Lightning.ant)

let available_machines = 
  [ default1; default2; work; stupid; test; lightning ]

let get_machine (s, ant) =
  (s, Language.compute_ant ~comment:(fun s -> s)
     ~return_state: return
     ~fail_state: fail
     ant)

let all_machines () =
  List.map get_machine available_machines

let export_all () =
  let all = all_machines () in
  List.iter 
    (fun (prefix, m) -> 
       Output.export_machine prefix false m)
    all;
  List.iter 
    (fun (prefix, m) -> 
       Output.export_graph prefix m)
    all
  

let usage () =
  prerr_string 
    "Usage: ants [ant | all | reprint <file> | run [<red> [<black>]]]\n";
  exit 1

let () =
  match Sys.argv with
      [| _ |] | [| _; "ant" |] ->
	let deco = Array.length Sys.argv = 2 in
	Output.print_machine deco (snd (get_machine default1))
    | [| _; "all" |] -> export_all ()
    | [| _; "reprint"; file |] -> 
	Output.print_machine false (Input.read_machine file)
    | [| _; "graph"; file |] -> 
	Output.print_graph (Input.read_machine file)
    | [| _; "run" |]
    | [| _; "run"; _ |]
    | [| _; "run"; _; _ |] ->
	let red_machine, black_machine =
	  if Array.length Sys.argv = 2 then
	    snd (get_machine default1), snd (get_machine default2)
	  else
	    let red_machine = Input.read_machine Sys.argv.(2) in
	    let black_machine =
	      if Array.length Sys.argv = 3 then
		snd (get_machine default1)
	      else Input.read_machine Sys.argv.(3) in
	    red_machine, black_machine in
	
	let (world, ants, max_id, initial_food) as x = World.input "world" in
	let module S = 
	  Simulator.Make 
	    (struct
	       let (world, ants, max_id, initial_food) = x
	       let red_machine = red_machine
	       let black_machine = black_machine
	       let fast_random = true
	     end) in
	S.run ~dump: false ~cycles: 100_000 ();
	World.export "world" world
	  
    | _ -> usage ()
