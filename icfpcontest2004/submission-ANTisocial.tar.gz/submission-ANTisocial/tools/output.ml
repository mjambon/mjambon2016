open Printf

open Language.Types

let string_of_sense_dir = function
    Here -> "Here"
  | Ahead -> "Ahead"
  | LeftAhead -> "LeftAhead"
  | RightAhead -> "RightAhead"

let string_of_condition = function
    Friend -> "Friend"
  | Foe -> "Foe"
  | FriendWithFood -> "FriendWithFood"
  | FoeWithFood -> "FoeWithFood"
  | Food -> "Food"
  | Rock -> "Rock"
  | Marker i  -> "Marker " ^ string_of_int i
  | FoeMarker -> "FoeMarker"
  | Home -> "Home"
  | FoeHome -> "FoeHome"


let string_of_instr = function
    Sense (sense_dir, st1, st2, condition) -> 
      sprintf "Sense %s %i %i %s" 
      (string_of_sense_dir sense_dir) st1 st2 (string_of_condition condition)
  | Mark (marker, st) -> sprintf "Mark %i %i" marker st
  | Unmark (marker, st) -> sprintf "Unmark %i %i" marker st
  | PickUp (st1, st2) -> sprintf "PickUp %i %i" st1 st2
  | Drop st -> sprintf "Drop %i" st
  | Turn (lr, st) -> 
      sprintf "Turn %s %i" (if lr = Left then "Left" else "Right") st
  | Move (st1, st2) -> sprintf "Move %i %i" st1 st2;
  | Flip (p, st1, st2) -> sprintf "Flip %i %i %i" p st1 st2


let ascii_ant =
[|
"       _,               m_gMMMF           ";
"    _a* ,              #gMMMMMF           ";
" _a*    )___     #y   #7MMMMMP            ";
"\"       MMMMMag#E 3L_gLMMMMF __,,         ";
"      ##MMMMP2HMMMMMMMF  _Lm*    L        ";
"      +F   %E,#_U  ML\"*P\" \\_      L       ";
"          ,4* y'    \"m_     \"**    \\      ";
"         gLF _'       J             t     ";
"        *_F  #       (               4    ";
"         F  g        F                L   ";
"           '        (                  \"=m";
"                    '                     ";
"                                          ";
|]


let shift k s =
  let s' = String.copy s in
  let n = String.length s in
  for i = 0 to n - 1 do
    if i < k then s'.[i] <- ' '
    else s'.[i] <- s.[i-k]
  done;
  s'
    

let foutput_machine f oc decorate =
  let keep_only = 31 in
  let rotation = ref 0 in
  let rotate () = rotation := !rotation + 4 in
  let rot s =
    let n = String.length s in
    let s' = String.make n ' ' in
    for i = 0 to n - 1 do
      s'.[i] <- s.[(i + !rotation) mod n]
    done;
    s' in
  fun machine  ->
    Array.iteri 
    (fun id (instr, comment) -> 
       let space = 8 in
       let comment =
	 if not decorate then comment
	 else
	   let n = id mod (Array.length ascii_ant) in
	   if n = 0 then 
	     rotate ();
	   let deco = 
	     String.sub (shift space (rot ascii_ant.(n))) 0 keep_only in
	   let s = comment ^ " " in
	   if String.length s >= String.length deco then s
	   else
	     let s' = String.copy deco in
	   String.blit s 0 s' 0 (String.length s);
	     s' in
       f oc instr id comment)
	 
    machine


let output_machine oc decorate m =
  foutput_machine 
    (fun oc instr id comment -> 
       fprintf oc "%-41s; %4i %s\n" 
       (string_of_instr instr) id comment)
    oc decorate m

let print_machine deco machine =
  output_machine stdout deco machine

let export_machine ?(suffix = ".ant") prefix deco machine =
  let oc = open_out (prefix ^ suffix) in
  output_machine oc deco machine;
  close_out oc


let node id comment oc instr =
  fprintf oc "state%i [label=%S];\n"
    id 
    (sprintf "#%i\n" id ^
     (string_of_instr instr ^ 
      (if comment = "" then ""
       else sprintf "\n(%s)" comment)))

let edges = function
    Sense (_, st1, st2, _)
  | Move (st1, st2)
  | Flip (_, st1, st2)
  | PickUp (st1, st2) -> `Branch (st1, st2)
  | Mark (_, st)
  | Unmark (_, st)
  | Drop st
  | Turn (_, st) -> `Jump st

let edge id oc = function
    `Branch (st1, st2) ->
      fprintf oc "  state%i -> state%i [style=solid];\n" id st1;
      fprintf oc "  state%i -> state%i [style=dashed];\n" id st2
  | `Jump st ->
      fprintf oc "  state%i -> state%i [style=bold];\n" id st


let output_graph oc m =
  fprintf oc"\
digraph G {
  size=\"10,7.5\";
  rankdir = TB;
";
  foutput_machine 
    (fun oc instr id comment ->
       fprintf oc "  %a%a" 
       (node id comment) instr (edge id) (edges instr))
    oc false m;
  fprintf oc"}\n"

let print_graph machine =
  output_graph stdout machine

let export_graph prefix machine =
  let oc = open_out (prefix ^ ".dot") in
  output_graph oc machine;
  close_out oc
