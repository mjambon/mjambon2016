open Language.Types

let sub l st1 st2 = Subtask (l, st1, st2)

let ( ^^ ) s n = s ^ (string_of_int n)

let sense a b c d = Instr (Sense (a, c, d, b))
let sense' a b c d = sense b a c d

let mark n b = 
  if n < 0 || n > 5 then invalid_arg "mark" 
  else Instr (Mark (n, b))
let unmark a b = Instr (Unmark (a, b))
let pickup a b = Instr (PickUp (a, b))
let drop a = Instr (Drop a)
let turn a b = Instr (Turn (a, b))
let move a b = Instr (Move (a, b))
let flip a b c = Instr (Flip (a, b, c))

let return = "return"
let fail = "fail"

let dir = function
    Left -> LeftAhead
  | Right -> RightAhead

let lr = function
    LeftAhead -> Left
  | RightAhead -> Right
  | _ -> invalid_arg "lr"
