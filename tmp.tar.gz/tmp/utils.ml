open Printf

let read_chan f ic =
  try
    while true do
      f (input_char ic)
    done
  with End_of_file -> ()

let include_file file =
  let ic = open_in_bin file in
  read_chan print_char ic;
  close_in ic

let html_verbatim file =
  let ic = open_in_bin file in
  print_string "<pre>\n";
  read_chan 
    (function
	 '<' -> print_string "&lt;"
       | '>' -> print_string "&gt;"
       | '&' -> print_string "&amp;"
       | c -> print_char c)
    ic;
  print_string "</pre>\n";
  close_in ic

let author () = print_string "Martin&nbsp;Jambon"

let email () = print_string "martin_jambon@emailuser.net"

let author_email () =
  author ();
  print_string " &lt;<a href=\"mailto:";
  email ();
  print_string "\">";
  email ();
  print_string "</a>&gt"

let title s = 
  printf "<title>%s</title>" s

let download file =
  printf "<a href=\"%s\">%s</a>" file file

let htmled_file file =
  printf "<a href=\"%s.html\">%s</a>" file file

let date () =
  flush stdout;
  assert (Sys.command "date -I" = 0)

let copyright () =
  print_string "&copy;&nbsp;2004&nbsp;";
  author_email ()

let camlmix_footer () =
  print_string "
<div id=footer>Processed with <a href=\"/camlmix\">Camlmix</a> ";
  date ();
  print_string "<br>\n";
  copyright ();
  print_string "</div>"


let top_menu topic =
  let topics = [| ""; ""; "" |] in
  if topic  = -1 then ()
  else (try topics.(topic) <- " class=\"current_topic\""
	with _ -> invalid_arg "top_menu");
  printf 
"<table id=top_menu cellspacing=2>
<tr>
  <td%s><a href=\"/\">Home</a></td>
  <td%s><a href=\"/ocaml.html\">OCaml</a></td>
  <td%s><a href=\"/people.html\">People</a></td>
</tr>
</table>

</td>
</tr>
<tr>
<td class=\"main_cell\">
"
    topics.(0) topics.(1) topics.(2)


let link_up s =
  try
    let upto =
      match s with
	  "cv" | "publications" -> "/people.html"
	| _ -> raise Exit in

    printf "<link rel=\"up\" href=\"%s\">\n" upto
  with Exit -> ()

let nowhere = -1
let home = 0
let ocaml = 1
let people = 2

let publications = people
let cv = people
let camlmix = ocaml
let hashtbl2 = ocaml
