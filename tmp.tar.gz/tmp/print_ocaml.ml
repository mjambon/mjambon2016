open Printf

open Caml2html
open Types

let print_class c s =
  printf "<span class=%s>%s</span>" c s

let hardspace s =
  let buf = Buffer.create (7 * String.length s) in
  for i = 0 to String.length s - 1 do
    if s.[i] = ' ' then
      Buffer.add_string buf "&nbsp;"
    else
      Buffer.add_char buf s.[i]
  done;
  Buffer.contents buf

let hardtab = String.concat "" (Array.to_list (Array.make 8 "&nbsp;"))
let softtab = String.make 8 ' '

let color true_html = function
    Tcomment s -> 
      print_class "Ccomment" (if true_html then hardspace s else s)
  | Tstring s ->
      print_class "Cstring" (if true_html then hardspace s else s)
  | Tconstruct s -> print_class "Cconstructor" s
  | Tkeyword (s, (color, css_class)) -> print_class css_class s
  | Ttoken s -> print_class "Ctoken" (if true_html then hardspace s else s)
  | Tnewline -> print_string (if true_html then "<br>\n" else "\n")
  | Ttab -> print_string (if true_html then hardtab else softtab)


let html_input_ocaml ic =
  let lexbuf = Lexing.from_channel ic in
  let l = Parser.file Lexer.token lexbuf in
  print_endline "<pre>";
  List.iter (color false) l;
  print_endline "</pre>"

let html_include_ocaml file =
  let ic = open_in file in
  html_input_ocaml ic;
  close_in ic

let html_decorate_ocaml ?(true_html = false) s =
  let lexbuf = Lexing.from_string s in
  let l = Parser.file Lexer.token lexbuf in
  List.iter (color true_html) l

let ocaml ?(true_html = true) ?wrap s =
  let start_tag, end_tag =
    match wrap with
	Some s -> sprintf "<%s>" s, sprintf "</%s>" s
      | None -> "", "" in
  print_string start_tag;
  html_decorate_ocaml ~true_html s;
  print_string end_tag

let ocamlcode = ocaml ~true_html: true ~wrap: "code"
let ocamlpre = ocaml ~true_html: false ~wrap: "pre"

let a f = fun (any_channel : out_channel) -> f

let ocamldoc ?impl_oc ?intf_oc title description intf impl =
  printf 
"<table class=ocamldoc cellspacing=\"0px\">
<tr>
<td>
<div class=descr>
<b>%s</b> %s
%s
</div>
<div class=intf>%a</div>
%a
</td>
</tr>
</table>
"
    title
    (if description <> "" then "-" else "")
    description
    (a ocamlpre) intf
    (a ocamlpre) impl;

  let export ?(add1 = ")\n") ?(add2 = "")opt s =
    match opt with
	None -> ()
      | Some oc -> 
	  fprintf oc "\n(*** %s ***%s%s\n%s\n" title add1 s add2 in
  export intf_oc intf;
  export impl_oc ~add1:(sprintf ":\n%s\n*)\n\n" intf) ~add2:";;\n" impl
