(* micmatch comments.ml < some_file *)

(* 
   Task: extract comments in a text file.
   Comments start with any occurrence of "(*" and end with
   the next occurrence of "*)".
   (This is not suitable for retrieving OCaml comments)
*)

open Micmatch

let _ =
  let parse_contents = MAP "(*" (_* Lazy as s) "*)" -> `Comment s in
  let comments =
    Text.map
      (function
           `Text _ -> raise Text.Skip
         | `Comment s -> s)
      (parse_contents (Text.channel_contents stdin)) in

  List.iter print_endline comments
