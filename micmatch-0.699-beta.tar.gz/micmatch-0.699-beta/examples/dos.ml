(* micmatch dos.ml < dos.txt *)

(* See http://www.troubleshooters.com/codecorn/littperl/perlreg.htm
   for the problem, a solution in Perl and an input file. *)

RE d = ['0'-'9']
open Printf

try
  while true do
    match read_line () with
	RE _* "<DIR>" -> ()
      | RE _{28} (d{2} as month) "-" (d{2} as day) "-" (d{2} as year)
	  _{8} (_+ as filename) eol ->
	  if year ^ month ^ day < "971222" then
	    printf "copy %s \\oldie\n" filename
      | _ -> ()
  done
with End_of_file -> ()
