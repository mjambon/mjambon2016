open Printf
open Scanf

let ( += ) r x = r := !r +. x

type normal = { field : float }

type tag x = [ `X | `Y | `Z ]

module Date = 
struct
  type t = int * int
  let of_string s =
    sscanf s "%i-%i" (fun m y -> (m, y))
  let to_string (m, y) =
    sprintf "%02i-%i" m y
  let compare = compare
end


type col testing = { id : string;
		     name;
		     date1 : Date;
		     date2 : Date;
		     setx : bool = false;
		     test : float option = None;
		     mutable score : float = 0.;
		     mutable remark "bla bla" : string option;
		     kind : [ `Apple | `Orange ] = `Apple;
		     kind2 : [ `Apple | `Banana ] = `Banana }

class mega_obj ~kind =
object
  inherit Testing.OO.t ~id:"mega" ~name:"Sponge" 
    ~date1:(2,2000) ~date2:(3,2000) 
    ~remark:(Some "this is an inherited class") 
    ~kind ()
  method hello = print_endline "Hello!"; flush stdout
end

let _ =
  let item1 = Testing.create 
		~id:"a"
		~name:"Martin"
		~date1:(1, 2006)
		~date2:(6, 2006)
		~score:1.0
		~remark:None () in
  let item2 = Testing.create
		~id:"b" 
		~date1:(10, 1977)
		~date2:(3, 1990)
		~remark:(Some "record 2")
		~name:"Joe" () in
  let l1 = [item1; item2; { item2 with id = "A" } ] in
  Testing.save_csv "test1.csv" l1;
  let l2 = Testing.load_csv "test1.csv" in
  let cmp = Testing.compare_fields [ `Custom (fun a b -> 0);
				     `Down "score";
				     `Up "name";
				     `Up "id" ] in
  Testing.save_csv "test2.csv" (List.sort cmp l2);

  let l2_obj = List.map Testing.OO.of_record l2 in
  let item3 = Testing.OO.of_record item2 in
  item3#set_score 99.;
  item3#set_remark (Some "object derived from record2");
  let item4 = new mega_obj ~kind:`Orange in
  item4#set_score (item3#score +. 1.);
  Testing.OO.save_csv ~sep:' ' ~noheader:true "test3.dat" 
    (l2_obj @ [item3; (item4 :> Testing.OO.t) ])
